package gameball.com.tw.onecupcafe.fragments.setting;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.makeramen.roundedimageview.RoundedImageView;
import com.orhanobut.hawk.Hawk;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.core.base.BaseFragment;
import gameball.com.tw.onecupcafe.items.SettingPojo.ResUpdateUserInfo;
import gameball.com.tw.onecupcafe.items.SettingPojo.UserInfoPojo;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResGetUserInfo;
import gameball.com.tw.onecupcafe.retrofit.ApiBase;
import gameball.com.tw.onecupcafe.retrofit.api.SettingApi;
import gameball.com.tw.onecupcafe.retrofit.api.UserSignInSignUpApi;
import gameball.com.tw.onecupcafe.utils.ApiErrorMsgCallback;
import gameball.com.tw.onecupcafe.utils.Constants;
import gameball.com.tw.onecupcafe.utils.EmailValidUtil;
import gameball.com.tw.onecupcafe.utils.GlideImageUtil;
import gameball.com.tw.onecupcafe.utils.MD5Util;
import gameball.com.tw.onecupcafe.utils.ProgressBarCallBack;
import gameball.com.tw.onecupcafe.utils.QrCodeGenUtil;
import gameball.com.tw.onecupcafe.utils.ResStatusReturn;
import gameball.com.tw.onecupcafe.utils.TimeStampUtil;
import gameball.com.tw.onecupcafe.utils.ToastUtil;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileFragment extends BaseFragment {

    public static ProfileFragment newInstance() {
        Bundle args = new Bundle();

        ProfileFragment fragment = new ProfileFragment();
        fragment.setArguments(args);
        return fragment;
    }

    private EditText etSettingProfileUserName;
    private TextView tvSettingProfileUserPhone, tvSettingProfileUserMail;
    private Button btnUserDataUploadComfirm;
    private ImageView ivSettingProfileUserImg;
    public static final String TAG = "Profile";
    public static final int GALLERY = 1001;
    public static final int CAMERA = 1002;
    private RoundedImageView rivSettingProfileUploadImag;
    private Bitmap bmpUserImage;
    private ProgressBarCallBack progressBarCallBack;
    private ApiErrorMsgCallback apiErrorMsgCallback;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_setting_profile, container, false);
        initView(view);
        return view;
    }

    private void initView(View v) {
        progressBarCallBack = (ProgressBarCallBack) getActivity();
        apiErrorMsgCallback = (ApiErrorMsgCallback) getActivity();

        tvSettingProfileUserPhone = (TextView) v.findViewById(R.id.tvSettingProfileUserPhone);
        etSettingProfileUserName = (EditText) v.findViewById(R.id.etSettingProfileUserName);
        tvSettingProfileUserMail = (TextView) v.findViewById(R.id.tvSettingProfileUserMail);
        btnUserDataUploadComfirm = (Button) v.findViewById(R.id.btnUserDataUploadComfirm);
        btnUserDataUploadComfirm.setOnClickListener(this);
        ivSettingProfileUserImg = (ImageView) v.findViewById(R.id.ivSettingProfileUserImg);
        rivSettingProfileUploadImag = (RoundedImageView) v.findViewById(R.id.rivSettingProfileUploadImag);
        rivSettingProfileUploadImag.setOnClickListener(this);

        try {
            String strUserPhotoUrl;
//            try {
//                strUserPhotoUrl = ((Uri) Hawk.get(Constants.USER_PHOTO_URL)).getPath();
//                strUserPhotoUrl = "http://graph.facebook.com" + strUserPhotoUrl + "?type=large";
//            } catch (Exception e) {
                strUserPhotoUrl = Hawk.get(Constants.USER_PHOTO_URL, Constants.USER_DEF_DATA);
//            }
            Log.e(TAG, "Url:" + strUserPhotoUrl);
            if (!strUserPhotoUrl.equals(Constants.USER_DEF_DATA)) {
                new GlideImageUtil(getActivity(), strUserPhotoUrl, ivSettingProfileUserImg, R.drawable.img_friend_default).LoadImageWithGlide();
            }
        } catch (Exception e) {
            Log.e(TAG, "UserImgExc:" + e.toString());
        }

        String strUserName = Hawk.get(Constants.USER_NAME, Constants.USER_DEF_DATA);
        etSettingProfileUserName.setText(strUserName);
        String strUserEmail = Hawk.get(Constants.USER_EMAIL, Constants.USER_DEF_DATA);
        tvSettingProfileUserMail.setText(strUserEmail);
        String strUserPhone = Hawk.get(Constants.USER_PHONE,Constants.USER_DEF_DATA);
        Log.e(TAG,"UserPhone:"+strUserPhone);
        tvSettingProfileUserPhone.setText(strUserPhone);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnUserDataUploadComfirm:
                boolean isDataCorrect = false;
                String strUserPhone = tvSettingProfileUserPhone.getText().toString().trim();
                String strUserName = etSettingProfileUserName.getText().toString().trim();
                String strUserMail = tvSettingProfileUserMail.getText().toString().trim();


//                if (strUserPhone.length() > 0 && strUserName.length() > 0 && EmailValidUtil.isEmailValid(strUserMail) == true) {
                Log.e(TAG, "UpdateParam-Phone:" + strUserPhone + ";Mail:" + strUserMail + ";Name:" + strUserName);
                apiUpdateUserInfo(strUserPhone, strUserName, strUserMail);
//                } else {
//                    ToastUtil.showToastMsg("請確認輸入資料是否正確");
//                }


                break;
            case R.id.rivSettingProfileUploadImag:
                showPictureDialog();
                break;
            default:
                break;
        }
    }

    //todo
    //上傳圖片待測
    //檔名：api_503.php 功能：更新會員更新
    private void apiUpdateUserInfo(String strUserPhone, String strUserName, String strUserMail) {
        progressBarCallBack.showProgressBar();

//        UserInfoPojo userInfoPojo = new UserInfoPojo();
//        userInfoPojo.setToken("testtoken123");
//        userInfoPojo.setUserEmail("sdass@gmail.com");
//        userInfoPojo.setNickName("aaa");
//        userInfoPojo.setPhotoBase64("");
//        userInfoPojo.setPhone("092929292");
//        userInfoPojo.setKeyStr("9b99da3758eda01f19a29fc2a2f4680a");
//        userInfoPojo.setTimestamp("1524639397");
        String strToken = Hawk.get(Constants.USER_ACCTOKEN);
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken, strTimeStamp);

        RequestBody requestFile = null;
        MultipartBody.Part imgPart = null;

        if (bmpUserImage != null && bmpUserImage.getByteCount() > 0) {
            File file = new File(getActivity().getCacheDir(), "userImg.jpeg");
            try {
                file.createNewFile();
                //Convert bitmap to byte array
                Bitmap bitmap = bmpUserImage;
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 60 /*ignored for PNG*/, bos);
                byte[] bitmapdata = bos.toByteArray();

                //write the bytes in file
                FileOutputStream fos = new FileOutputStream(file);
                fos.write(bitmapdata);
                fos.flush();
                fos.close();
            } catch (Exception e) {
            }
            requestFile = RequestBody.create(MediaType.parse("image/*"), file);
            imgPart =
                    MultipartBody.Part.createFormData("photo", file.getName(), requestFile);
            Log.e(TAG, "ImgFileSize:" + file.length());
        } else {
            requestFile = RequestBody.create(MultipartBody.FORM, "");
            imgPart = MultipartBody.Part.createFormData("file", "", requestFile);
        }

        Call<ResUpdateUserInfo> getUpdateUserInfo =
                ApiBase.instance().create(SettingApi.class).
                        postUpdateUserInfo(
                                strToken,
                                strUserMail,
                                strUserName,
                                strUserPhone,
                                strKeyStr,
                                strTimeStamp,
                                imgPart
                        );

//        Map<String, Object> params = new LinkedHashMap<>();
//        params.put("token", "testtoken123");
//        params.put("nickName","aaa");
//        params.put("timestamp","1524639397");
//        params.put("keyStr","9b99da3758eda01f19a29fc2a2f4680a");
//        params.put("phone","092929292");
//        params.put("userEmail","sdass@gmail.com");
//        params.put("photoBase64","");
//        Log.e(TAG,"Param:"+new JSONObject(params).toString());
//        final RequestBody requestBody = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), new JSONObject(params).toString());
//
//        Call<ResUpdateUserInfo> getUpdateUserInfo = ApiBase.instance().create(SettingApi.class).postUpdateUserInfo(requestBody);


//                ApiBase.instance().create(SettingApi.class).postUpdateUserInfo(
//                        userInfoPojo
//                );


        getUpdateUserInfo.enqueue(new Callback<ResUpdateUserInfo>() {
            @Override
            public void onResponse(Call<ResUpdateUserInfo> call, Response<ResUpdateUserInfo> response) {
                try {
                    String strApiRtnCode = response.body().getCode();
                    if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {
                        Log.e(TAG, "UploadSuccessStep1");
                        Log.e(TAG, "UploadSuccess:" + response.body().getRetnObject().getUid());
                        apiGetUserInfo();
                    } else {
                        apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                    }

                } catch (Exception e) {
                    Log.e(TAG, "ApiError:" + e.toString());
                }
            }

            @Override
            public void onFailure(Call<ResUpdateUserInfo> call, Throwable t) {
                Log.e(TAG, t.toString());
            }
        });

        progressBarCallBack.hideProgressBar();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == this.RESULT_CANCELED) {
            return;
        }
        if (requestCode == GALLERY) {
            if (data != null) {
                Uri contentURI = data.getData();
                try {
                    bmpUserImage = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), contentURI);
                    Log.e(TAG, "Size1:" + bmpUserImage.getByteCount());

                    bmpUserImage = Bitmap.createScaledBitmap(bmpUserImage, bmpUserImage.getWidth() / 3, bmpUserImage.getHeight() / 3, true);
                    Matrix matrix = new Matrix();
                    matrix.setScale(0.5f, 0.5f);
                    bmpUserImage = Bitmap.createBitmap(bmpUserImage, 0, 0, bmpUserImage.getWidth(), bmpUserImage.getHeight(), matrix, true);

                    Log.e(TAG, "Size2:" + bmpUserImage.getByteCount());
                    Glide.with(getActivity()).load(bmpUserImage).into(ivSettingProfileUserImg);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else if (requestCode == CAMERA) {
            Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
            ivSettingProfileUserImg.setImageBitmap(thumbnail);
        }
    }

    private void showPictureDialog() {
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(getActivity());
//        pictureDialog.setTitle("Select Action");
        String[] pictureDialogItems = {
                getString(R.string.setting_profile_image_from_gallery)};

//                "Select photo from gallery",
//                "Capture photo from camera"};
        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                choosePhotoFromGallary();
                                break;
                            case 1:
                                takePhotoFromCamera();
                                break;
                        }
                    }
                });
        pictureDialog.show();
    }

    public void choosePhotoFromGallary() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(galleryIntent, GALLERY);
    }

    private void takePhotoFromCamera() {
        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, CAMERA);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (bmpUserImage != null && bmpUserImage.getByteCount() > 0) {
            bmpUserImage = null;
        }
    }

    //檔名：api_007.php 功能：取得會員資料
    private void apiGetUserInfo() {
        progressBarCallBack.showProgressBar();
        String strToken = Hawk.get(Constants.USER_ACCTOKEN);
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken, strTimeStamp);
        Call<ResGetUserInfo> getGetUserInfo =
                ApiBase.instance().
                        create(UserSignInSignUpApi.class)
                        .postGetUserInfo(strToken
                                , strKeyStr
                                , strTimeStamp);

        getGetUserInfo.enqueue(new Callback<ResGetUserInfo>() {
            @Override
            public void onResponse(Call<ResGetUserInfo> call, Response<ResGetUserInfo> response) {
                try {
                    String strApiRtnCode = response.body().getCode();
                    if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {
                        ToastUtil.showToastMsg("上傳成功");
                        ResGetUserInfo.ReturnData userData = response.body().getRetnObject();
                        String userEmail = userData.getUserEmail();
                        String nickName = userData.getNickName();
                        String photoURL = userData.getPhotoURL();
                        String phone = userData.getPhone();
                        Log.e(TAG, "Email" + userEmail);
                        Log.e(TAG, "Name" + nickName);
                        Log.e(TAG, "PhotoUrl" + photoURL);
                        Log.e(TAG, "Phone" + phone);
                        Hawk.put(Constants.USER_NAME, nickName);
                        Hawk.put(Constants.USER_PHOTO_URL, photoURL);
                        new GlideImageUtil(getActivity(), photoURL, ivSettingProfileUserImg, R.drawable.img_friend_default).LoadImageWithGlide();
                        progressBarCallBack.hideProgressBar();
                    } else {
                        progressBarCallBack.hideProgressBar();
                        apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                    }

                } catch (Exception e) {
                    progressBarCallBack.hideProgressBar();
                    Log.e(TAG, "ApiError:" + e.toString());
                }
            }

            @Override
            public void onFailure(Call<ResGetUserInfo> call, Throwable t) {
                progressBarCallBack.hideProgressBar();
                Log.e(TAG, "GetUserInfo:" + t.toString());
            }
        });
    }
}
