package gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo;

import java.io.Serializable;

public class ResUserFBLogin implements Serializable {
    String code;
    String message;
    ThirdPartLogin retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ThirdPartLogin getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(ThirdPartLogin retnObject) {
        this.retnObject = retnObject;
    }


}
