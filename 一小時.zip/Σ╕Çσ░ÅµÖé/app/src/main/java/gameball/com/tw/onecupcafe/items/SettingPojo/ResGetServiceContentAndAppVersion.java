package gameball.com.tw.onecupcafe.items.SettingPojo;

import java.io.Serializable;

public class ResGetServiceContentAndAppVersion implements Serializable {
    String code;
    String message;
    ReturnData retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ReturnData getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(ReturnData retnObject) {
        this.retnObject = retnObject;
    }

    class ReturnData{
        String ServiceNote;
        String ServiceNoteEN;
        String AboutNote;
        String PrivacyNote;
        String ServeNote;
        String versionInfo;

        public String getServiceNote() {
            return ServiceNote;
        }

        public void setServiceNote(String serviceNote) {
            ServiceNote = serviceNote;
        }

        public String getServiceNoteEN() {
            return ServiceNoteEN;
        }

        public void setServiceNoteEN(String serviceNoteEN) {
            ServiceNoteEN = serviceNoteEN;
        }

        public String getAboutNote() {
            return AboutNote;
        }

        public void setAboutNote(String aboutNote) {
            AboutNote = aboutNote;
        }

        public String getPrivacyNote() {
            return PrivacyNote;
        }

        public void setPrivacyNote(String privacyNote) {
            PrivacyNote = privacyNote;
        }

        public String getServeNote() {
            return ServeNote;
        }

        public void setServeNote(String serveNote) {
            ServeNote = serveNote;
        }

        public String getVersionInfo() {
            return versionInfo;
        }

        public void setVersionInfo(String versionInfo) {
            this.versionInfo = versionInfo;
        }
    }
}
