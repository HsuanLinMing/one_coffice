package gameball.com.tw.onecupcafe.core.base;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class SampleFragment extends BaseFragment implements View.OnClickListener {
    public static final String TAG = "SignUpFragment";

    public static SampleFragment newInstance() {
        Bundle args = new Bundle();

        SampleFragment fragment = new SampleFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(0,container,false);
        initView(view);
        return view;
    }
    @Override
    public void onStart() {
        super.onStart();

    }

    private void initView(View v) {

    }


    @Override
    public void onClick(View v) {

    }

}
