package gameball.com.tw.onecupcafe.fragments.exchange;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.orhanobut.hawk.Hawk;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.activities.ExchangeActivity;
import gameball.com.tw.onecupcafe.activities.HomeActivity;
import gameball.com.tw.onecupcafe.core.base.BaseFragment;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResExchangeOrderCancel;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResExchangeOrderCheckStatus;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResExchangeOrderRedeem;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResExchangeOrderRefund;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResExchangeOrderRefundCancel;
import gameball.com.tw.onecupcafe.items.StorePojo.ResGetStoreProductCancel;
import gameball.com.tw.onecupcafe.items.StorePojo.ResGetStoreProductConfirm;
import gameball.com.tw.onecupcafe.items.StorePojo.StoreDetailData;
import gameball.com.tw.onecupcafe.retrofit.ApiBase;
import gameball.com.tw.onecupcafe.retrofit.api.PointCardApi;
import gameball.com.tw.onecupcafe.retrofit.api.StoreApi;
import gameball.com.tw.onecupcafe.utils.ApiErrorMsgCallback;
import gameball.com.tw.onecupcafe.utils.Constants;
import gameball.com.tw.onecupcafe.utils.MD5Util;
import gameball.com.tw.onecupcafe.utils.ProgressBarCallBack;
import gameball.com.tw.onecupcafe.utils.QrCodeGenUtil;
import gameball.com.tw.onecupcafe.utils.ResStatusReturn;
import gameball.com.tw.onecupcafe.utils.TimeStampUtil;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ExchangeQrCodeFragment extends BaseFragment {

    public static ExchangeQrCodeFragment newInstance() {
        Bundle args = new Bundle();
        ExchangeQrCodeFragment fragment = new ExchangeQrCodeFragment();
        fragment.setArguments(args);
        return fragment;
    }

    public static final String TAG = "ExchangeQrCode";
    public Button btnExchangeScanQrCodeCancel;
    private String strExchangeMainTag, strQrCodeType, strProdId, strTransCode;
    private TextView tvExchangeQrCodeSerial, tvExchangeValidityPeriodContent, tvExchangeQrCodeDesc2,
            tvExchangeQrCodeProdDesc, tvExchangeQrCodeProdSalesDesc, tvExchangeQrCodeProdExpDateDesc,
            tvExchangeQrCodeProdSalesTitle, tvExchangeQrCodeProdExpDateTitle, tvExchangeQrCodeDesc1,
            tvExchangeQrCodeDesc3, tvExchangeQrCodeExpireDesc,tvExchangeQrCodeTitleProdDesc;
    private ImageView ivExchangeQrCode;
    private ProgressBarCallBack progressBarCallBack;
    private CountDownTimer cdtExpireTimer , cdtCheckProdBuyStatus;
    private int intTransExpireSecond;
    private ApiErrorMsgCallback apiErrorMsgCallback;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_exchange_qrcode, container, false);
        initView(view);
        return view;
    }

    private void initView(View v) {
        progressBarCallBack = (ProgressBarCallBack) getActivity();
        apiErrorMsgCallback = (ApiErrorMsgCallback) getActivity();

        strExchangeMainTag = ((ExchangeActivity) getActivity()).strPointCardTag;
        strQrCodeType = ((ExchangeActivity) getActivity()).strQrCodeTag;
        Log.e(TAG, "ExchangeMain:" + strExchangeMainTag + ";QrCodeType:" + strQrCodeType);

        btnExchangeScanQrCodeCancel = (Button) v.findViewById(R.id.btnExchangeScanQrCodeCancel);
        btnExchangeScanQrCodeCancel.setOnClickListener(this);
        if (strQrCodeType.equals("RefundExchange")) {
            btnExchangeScanQrCodeCancel.setText("取消退貨");
        }

        tvExchangeQrCodeDesc2 = (TextView) v.findViewById(R.id.tvExchangeQrCodeDesc2);
        tvExchangeQrCodeDesc2.setText(((ExchangeActivity) getActivity()).strRedeemCount);

        tvExchangeQrCodeDesc1 = (TextView) v.findViewById(R.id.tvExchangeQrCodeDesc1);
        if (!((ExchangeActivity) getActivity()).strPordTitle.equals("")) {
            String strExchangeProdTitle = getResources().getString(R.string.prod_exchange_title) + ((ExchangeActivity) getActivity()).strPordTitle;
            tvExchangeQrCodeDesc1.setText(strExchangeProdTitle);
        }

        tvExchangeQrCodeSerial = (TextView) v.findViewById(R.id.tvExchangeQrCodeSerial);
        tvExchangeValidityPeriodContent = (TextView) v.findViewById(R.id.tvExchangeValidityPeriodContent);
        tvExchangeQrCodeSerial = (TextView) v.findViewById(R.id.tvExchangeQrCodeSerial);
        tvExchangeQrCodeProdSalesTitle = (TextView) v.findViewById(R.id.tvExchangeQrCodeProdSalesTitle);
        tvExchangeQrCodeProdExpDateTitle = (TextView) v.findViewById(R.id.tvExchangeQrCodeProdExpDateTitle);
        tvExchangeQrCodeDesc1 = (TextView) v.findViewById(R.id.tvExchangeQrCodeDesc1);
        tvExchangeQrCodeDesc3 = (TextView) v.findViewById(R.id.tvExchangeQrCodeDesc3);
        tvExchangeQrCodeTitleProdDesc = (TextView) v.findViewById(R.id.tvExchangeQrCodeTitleProdDesc);

        tvExchangeQrCodeProdDesc = (TextView) v.findViewById(R.id.tvExchangeQrCodeProdDesc);
        tvExchangeQrCodeProdSalesDesc = (TextView) v.findViewById(R.id.tvExchangeQrCodeProdSalesDesc);
        tvExchangeQrCodeProdExpDateDesc = (TextView) v.findViewById(R.id.tvExchangeQrCodeProdExpDateDesc);

        ivExchangeQrCode = (ImageView) v.findViewById(R.id.ivExchangeQrCode);

        tvExchangeQrCodeExpireDesc = (TextView) v.findViewById(R.id.tvExchangeQrCodeExpireDesc);
        switchQrCodeExchange();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnExchangeScanQrCodeCancel:
//                getActivity().onBackPressed();
                switchQrCodeCancel();
                break;
            default:
                break;
        }
    }

    private void switchQrCodeExchange() {
        switch (strExchangeMainTag) {
            case "storeOrder":
                strProdId = ((ExchangeActivity) getActivity()).strProdId;
                StoreDetailData.StoreProduct prodData = ((ExchangeActivity) getActivity()).prodData;
                tvExchangeQrCodeTitleProdDesc.setText(prodData.getProdTitle());
                tvExchangeQrCodeDesc2.setText(prodData.getQtyPerSet());

                tvExchangeQrCodeProdDesc.setText(prodData.getSubTitle());
                tvExchangeQrCodeProdSalesDesc.setText(prodData.getSalePrice());
                tvExchangeQrCodeProdExpDateDesc.setText(prodData.getExpDate());
                Log.e(TAG, "StoreOrder:" +
                        prodData.getProdTitle() + ";" +
                        prodData.getSubTitle() + ";" +
                        prodData.getQtyPerSet() + ";" +
                        prodData.getProdID()
                );
                apiGetStoreProductConfirm(strProdId, 1);
                break;
            case "redeem":
                switch (strQrCodeType) {
                    case "OrderExchange":
                        String strExchangeId = ((ExchangeActivity) getActivity()).strRedeemID;
                        Log.e(TAG, "RedeemId:" + strExchangeId);
                        tvExchangeQrCodeProdDesc.setVisibility(View.GONE);
                        tvExchangeQrCodeProdSalesDesc.setVisibility(View.GONE);
                        tvExchangeQrCodeProdExpDateDesc.setVisibility(View.GONE);
                        tvExchangeQrCodeProdSalesTitle.setVisibility(View.GONE);
                        tvExchangeQrCodeProdExpDateTitle.setVisibility(View.GONE);
                        int intRedeemCount = Integer.parseInt(((ExchangeActivity) getActivity()).strRedeemCount);
                        Log.e(TAG, "RedeemCount:" + intRedeemCount);
                        apiExchangeOrderRedeem(strExchangeId, intRedeemCount);
                        break;
                    case "RefundExchange":
                        String strRefundId = ((ExchangeActivity) getActivity()).orderData.getOrderID();
                        String strRemianQty = ((ExchangeActivity) getActivity()).strRemianQty;
                        Log.e(TAG, "RefundId:" + strRefundId);

                        tvExchangeQrCodeProdDesc.setVisibility(View.GONE);
                        tvExchangeQrCodeProdSalesDesc.setVisibility(View.GONE);
                        tvExchangeQrCodeProdExpDateDesc.setVisibility(View.GONE);
                        tvExchangeQrCodeProdSalesTitle.setVisibility(View.GONE);
                        tvExchangeQrCodeProdExpDateTitle.setVisibility(View.GONE);
                        String strExchangeProdTitle = getResources().getString(R.string.prod_refund_title) + ((ExchangeActivity) getActivity()).strPordTitle;
                        tvExchangeQrCodeDesc1.setText(strExchangeProdTitle);
                        tvExchangeQrCodeDesc2.setText(strRemianQty);
                        apiExchangeOrderRefund(strRefundId);
                        break;
                }
                break;
            case "HistoryBuy":
                strProdId = ((ExchangeActivity) getActivity()).strOrderId;

                tvExchangeQrCodeProdDesc.setVisibility(View.GONE);
                tvExchangeQrCodeProdSalesDesc.setVisibility(View.GONE);
                tvExchangeQrCodeProdExpDateDesc.setVisibility(View.GONE);
                tvExchangeQrCodeProdSalesTitle.setVisibility(View.GONE);
                tvExchangeQrCodeProdExpDateTitle.setVisibility(View.GONE);
                tvExchangeQrCodeDesc1.setVisibility(View.GONE);
                tvExchangeQrCodeDesc2.setVisibility(View.GONE);
                tvExchangeQrCodeDesc3.setVisibility(View.GONE);

                apiGetStoreProductConfirm(strProdId, 1);
                break;
            case "free":
                Log.e(TAG, "MainTag:" + strExchangeMainTag);
                String strExchangeFreeId = ((ExchangeActivity) getActivity()).strRedeemID;
                Log.e(TAG, "RedeemId:" + strExchangeFreeId);
                tvExchangeQrCodeProdDesc.setVisibility(View.GONE);
                tvExchangeQrCodeProdSalesDesc.setVisibility(View.GONE);
                tvExchangeQrCodeProdExpDateDesc.setVisibility(View.GONE);
                tvExchangeQrCodeProdSalesTitle.setVisibility(View.GONE);
                tvExchangeQrCodeProdExpDateTitle.setVisibility(View.GONE);
                int intRedeemCountFree = Integer.parseInt(((ExchangeActivity) getActivity()).strRedeemCount);
                Log.e(TAG, "RedeemCount:" + intRedeemCountFree);
                apiExchangeOrderRedeem(strExchangeFreeId, intRedeemCountFree);
                break;
            case "gift":
                Log.e(TAG, "MainTag:" + strExchangeMainTag);
                String strExchangeGiftId = ((ExchangeActivity) getActivity()).strRedeemID;
                Log.e(TAG, "RedeemId:" + strExchangeGiftId);
                tvExchangeQrCodeProdDesc.setVisibility(View.GONE);
                tvExchangeQrCodeProdSalesDesc.setVisibility(View.GONE);
                tvExchangeQrCodeProdExpDateDesc.setVisibility(View.GONE);
                tvExchangeQrCodeProdSalesTitle.setVisibility(View.GONE);
                tvExchangeQrCodeProdExpDateTitle.setVisibility(View.GONE);
                int intRedeemCountGift = Integer.parseInt(((ExchangeActivity) getActivity()).strRedeemCount);
                Log.e(TAG, "RedeemCount:" + intRedeemCountGift);
                apiExchangeOrderRedeem(strExchangeGiftId, intRedeemCountGift);
                break;
            default:
                break;
        }

    }

    private void switchQrCodeCancel() {
        switch (strExchangeMainTag) {
            case "storeOrder":
                apiGetStoreProductCancel();
                break;
            case "redeem":
                switch (strQrCodeType) {
                    case "OrderExchange":
                        apiExchangeOrderCancel();
                        break;
                    case "RefundExchange":
                        apiExchangeOrderRefundCancel();
                        break;
                }
                break;
            case "HistoryBuy":
                apiExchangeOrderCancel();
                break;
            case "free":
                apiExchangeOrderCancel();
                break;
            case "gift":
                apiExchangeOrderCancel();
                break;
            default:
                break;
        }
    }

    //todo
    //檔名：api_105.php 功能：提出商品寄杯需求(申請付款QRcode)
    private void apiGetStoreProductConfirm(String strProdId, final int intQuantity) {
        Log.e(TAG, strExchangeMainTag);
        progressBarCallBack.showProgressBar();
        String strToken = Hawk.get(Constants.USER_ACCTOKEN, "");
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken + strProdId + intQuantity, strTimeStamp);
        Call<ResGetStoreProductConfirm> getStoreProductConfirm =
                ApiBase.instance().create(StoreApi.class).
                        postGetStoreProductConfirm(
                                strToken,
                                strProdId,
                                intQuantity,
                                strKeyStr,
                                strTimeStamp);

        Log.e(TAG, "RedeemID:" + strProdId);
        Log.e(TAG, "TimeStamp:" + strTimeStamp);
        Log.e(TAG, "Token:" + strToken);
        Log.e(TAG, "KeyStr:" + strKeyStr);

        getStoreProductConfirm.enqueue(new Callback<ResGetStoreProductConfirm>() {
            @Override
            public void onResponse(Call<ResGetStoreProductConfirm> call, Response<ResGetStoreProductConfirm> response) {

                String strApiRtnCode = response.body().getCode();
                if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {
                    strTransCode = response.body().getRetnObject().getTransCode();
                    tvExchangeQrCodeSerial.setText(strTransCode);
                    String strQrCodeString = Constants.TRANS_TYPE_BUY + "|" + strTransCode + "|" + MD5Util.MD5(
                            Constants.TRANS_TYPE_BUY, strTransCode, Constants.QRCODE_SALT
                    );
                    tvExchangeValidityPeriodContent.setText(response.body().getRetnObject().getTransExpireDate());
                    intTransExpireSecond = response.body().getRetnObject().getTransExpireSecond();

                    Glide.with(getActivity())
                            .load(QrCodeGenUtil.createQrCodeBitmap(strQrCodeString))
//                        .apply(new RequestOptions().centerInside())
                            .into(ivExchangeQrCode);
                    initTransExpireCountDown();
                    orderCheckHandler.postDelayed(orderCheckRunnable, 10000);
                } else {
                    Log.e(TAG,"QrCodePdError:"+response.body().getCode()+";"+response.body().getMessage());
                    apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                }

            }

            @Override
            public void onFailure(Call<ResGetStoreProductConfirm> call, Throwable t) {
            }
        });

        progressBarCallBack.hideProgressBar();
    }

    //todo
    //檔名：api_202.php 功能：提出寄杯商品兌換需求(申請兌換QRcode)
    private void apiExchangeOrderRedeem(String strRedeemID, int intQuantiy) {

        progressBarCallBack.showProgressBar();

        String strToken = Hawk.get(Constants.USER_ACCTOKEN, "");
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken + strRedeemID + intQuantiy, strTimeStamp);
        Log.e(TAG, "RedeemID:" + strRedeemID);
        Log.e(TAG, "TimeStamp:" + strTimeStamp);
        Log.e(TAG, "Token:" + strToken);
        Log.e(TAG, "KeyStr:" + strKeyStr);
        Call<ResExchangeOrderRedeem> getExchangeOrderRedeem =
                ApiBase.instance().create(PointCardApi.class).
                        postExchangeOrderRedeem(
                                strToken,
                                strRedeemID,
                                intQuantiy,
                                strKeyStr,
                                strTimeStamp);


        getExchangeOrderRedeem.enqueue(new Callback<ResExchangeOrderRedeem>() {
            @Override
            public void onResponse(Call<ResExchangeOrderRedeem> call, Response<ResExchangeOrderRedeem> response) {

                String strApiRtnCode = response.body().getCode();
                if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {

//                    "redeemID": 173273195,
//                            "transCode": "F2CB3EF3-21A2-EA85-074C-ADA9D47162E9",
//                            "quantity": 1,
//                            "transExpireDate": "2018-05-15 17:52:59",
//                            "transExpireSecond": 10800
                    strTransCode = response.body().getRetnObject().getTransCode();
                    tvExchangeQrCodeSerial.setText(strTransCode);
                    String strQrCodeString = Constants.TRANS_TYPE_REDEEM + "|" + strTransCode + "|" + MD5Util.MD5(
                            Constants.TRANS_TYPE_REDEEM, strTransCode, Constants.QRCODE_SALT
                    );
                    tvExchangeValidityPeriodContent.setText(response.body().getRetnObject().getTransExpireDate());
                    intTransExpireSecond = response.body().getRetnObject().getTransExpireSecond();
                    Glide.with(getActivity())
                            .load(QrCodeGenUtil.createQrCodeBitmap(strQrCodeString))
//                        .apply(new RequestOptions().centerInside())
                            .into(ivExchangeQrCode);
                    initTransExpireCountDown();
                    orderCheckHandler.postDelayed(orderCheckRunnable, 10000);
                } else {
                    apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                    Log.e(TAG, "ApiError: " + response.body().getCode() + "-" + response.body().getMessage());
                }

//                tvExchangeValidityPeriodContent.setText(response.body().getRetnObject().getTransExpireDate());
//                tvExchangeQrCodeSerial.setText(response.body().getRetnObject().getTransCode());
//                String srtrTranscCode = response.body().getRetnObject().getTransCode();
//                String[] strSpilteTransCode = (srtrTranscCode).split("\\|");
//                Glide.with(getActivity())
//                        .load(QrCodeGenUtil.createQrCodeBitmap(srtrTranscCode))
////                        .apply(new RequestOptions().centerInside())
//                        .into(ivExchangeQrCode);
            }

            @Override
            public void onFailure(Call<ResExchangeOrderRedeem> call, Throwable t) {
            }
        });

        progressBarCallBack.hideProgressBar();
    }

    //todo
    //檔名：api_106.php 功能：取消商品寄杯需求(取消付款QRcode)
    private void apiGetStoreProductCancel() {
        progressBarCallBack.showProgressBar();

        String strToken = Hawk.get(Constants.USER_ACCTOKEN, "");
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken + strTransCode, strTimeStamp);
        Log.e(TAG, "TimeStamp:" + strTimeStamp);
        Log.e(TAG, "Token:" + strToken);
        Log.e(TAG, "KeyStr:" + strKeyStr);
        Call<ResGetStoreProductCancel> getStoreProductCancel =
                ApiBase.instance().create(StoreApi.class).
                        postGetStoreProductCancel(
                                strToken,
                                strTransCode,
                                strKeyStr,
                                strTimeStamp);


        getStoreProductCancel.enqueue(new Callback<ResGetStoreProductCancel>() {
            @Override
            public void onResponse(Call<ResGetStoreProductCancel> call, Response<ResGetStoreProductCancel> response) {
                try {
                    String strApiRtnCode = response.body().getCode();
                    if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {
                        getActivity().onBackPressed();
                    } else {
                        apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                        Log.e(TAG, "ERROR");
                    }
                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call<ResGetStoreProductCancel> call, Throwable t) {
            }
        });

        progressBarCallBack.hideProgressBar();
    }

    //todo
    //檔名：api_203.php 功能：取消商品兌換需求(取消兌換QRcode)
    private void apiExchangeOrderCancel() {
        progressBarCallBack.showProgressBar();
        String strToken = Hawk.get(Constants.USER_ACCTOKEN, "");
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken + strTransCode, strTimeStamp);

        Call<ResExchangeOrderCancel> getExchangeOrderCancel =
                ApiBase.instance().create(PointCardApi.class).
                        postExchangeOrderCancel(
                                strToken,
                                strTransCode,
                                strKeyStr,
                                strTimeStamp);


        getExchangeOrderCancel.enqueue(new Callback<ResExchangeOrderCancel>() {
            @Override
            public void onResponse(Call<ResExchangeOrderCancel> call, Response<ResExchangeOrderCancel> response) {
                try {
                    String strApiRtnCode = response.body().getCode();
                    if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {
                        getActivity().onBackPressed();
                    } else {
                        apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                        Log.e(TAG, "ERROR");
                    }
                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call<ResExchangeOrderCancel> call, Throwable t) {
            }
        });

        progressBarCallBack.hideProgressBar();
    }

    //todo
    //檔名：api_205.php 功能：寄杯商品退貨（申請退貨QRcode）
    private void apiExchangeOrderRefund(String strOrderId) {
//        介面存取驗證字串md5(salt + accToken + orderID + timestamp)
        String strToken = Hawk.get(Constants.USER_ACCTOKEN, "");
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken + strOrderId, strTimeStamp);

        Call<ResExchangeOrderRefund> getExchangeOrderRefund =
                ApiBase.instance().create(PointCardApi.class).
                        postExchangeOrderRefund(
                                strToken,
                                strOrderId,
                                strKeyStr,
                                strTimeStamp);

        Log.e(TAG, "RefundToken:" + strToken);
        Log.e(TAG, "RefundOrderId:" + strOrderId);
        Log.e(TAG, "RefundTimeStamp:" + strTimeStamp);
        Log.e(TAG, "RefundKeyStr:" + strKeyStr);

        getExchangeOrderRefund.enqueue(new Callback<ResExchangeOrderRefund>() {
            @Override
            public void onResponse(Call<ResExchangeOrderRefund> call, Response<ResExchangeOrderRefund> response) {
                String strApiRtnCode = response.body().getCode();
                if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {
                    tvExchangeValidityPeriodContent.setText(response.body().getRetnObject().getTransExpireDate());
                    tvExchangeQrCodeSerial.setText(response.body().getRetnObject().getTransCode());

                    strTransCode = response.body().getRetnObject().getTransCode();

                    String strQrCodeString = Constants.TRANS_TYPE_REFUND + "|" + strTransCode + "|" + MD5Util.MD5(
                            Constants.TRANS_TYPE_REFUND, strTransCode, Constants.QRCODE_SALT
                    );
                    tvExchangeValidityPeriodContent.setText(response.body().getRetnObject().getTransExpireDate());
                    intTransExpireSecond = response.body().getRetnObject().getTransExpireSecond();
                    Glide.with(getActivity())
                            .load(QrCodeGenUtil.createQrCodeBitmap(strQrCodeString))
//                        .apply(new RequestOptions().centerInside())
                            .into(ivExchangeQrCode);
                    initTransExpireCountDown();
                    orderCheckHandler.postDelayed(orderCheckRunnable, 10000);

                } else {
                    apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                }

            }

            @Override
            public void onFailure(Call<ResExchangeOrderRefund> call, Throwable t) {
            }
        });

        progressBarCallBack.hideProgressBar();
    }

    //檔名：api_206.php 功能：取消商品退貨（取消退貨QRcode）
    private void apiExchangeOrderRefundCancel() {
//        介面存取驗證字串md5(salt + accToken + transCode + timestamp)
        String strToken = Hawk.get(Constants.USER_ACCTOKEN);
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken + strTransCode, strTimeStamp);


        Call<ResExchangeOrderRefundCancel> getExchangeOrderRefundCancel =
                ApiBase.instance().
                        create(PointCardApi.class).
                        postExchangeOrderRefundCancel(
                                strToken,
                                strTransCode,
                                strTimeStamp,
                                strKeyStr
                        );

        Log.e(TAG, "RefundCancelToken:" + strToken);
        Log.e(TAG, "RefundCancelOrderId:" + strTransCode);
        Log.e(TAG, "RefundCancelTimeStamp:" + strTimeStamp);
        Log.e(TAG, "RefundCancelKeyStr:" + strKeyStr);

        getExchangeOrderRefundCancel.enqueue(new Callback<ResExchangeOrderRefundCancel>() {
            @Override
            public void onResponse(Call<ResExchangeOrderRefundCancel> call, Response<ResExchangeOrderRefundCancel> response) {
                try {
                    String strApiRtnCode = response.body().getCode();
                    if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {
                        getActivity().onBackPressed();
                    } else {
                        Log.e(TAG, "ERROR");
                        apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                    }
                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call<ResExchangeOrderRefundCancel> call, Throwable t) {
            }
        });
    }

    //狀態確認[api_207]
    private void apiExchangeOrderCheckStatus() {
        String strToken = Hawk.get(Constants.USER_ACCTOKEN);
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        //介面存取驗證字串md5(salt + accToken + transCode +timestamp)
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken + strTransCode, strTimeStamp);

        Call<ResExchangeOrderCheckStatus> getExchangeOrderCheckStatus =
                ApiBase.instance().
                        create(PointCardApi.class).
                        postExchangeOrderCheckStatus(
                                strToken,
                                strTransCode,
                                strTimeStamp,
                                strKeyStr
                        );

        Log.e(TAG, "CheckStatusToken:" + strToken);
        Log.e(TAG, "CheckStatusTransId:" + strTransCode);
        Log.e(TAG, "CheckStatusTimeStamp:" + strTimeStamp);
        Log.e(TAG, "CheckStatusKeyStr:" + strKeyStr);

        getExchangeOrderCheckStatus.enqueue(new Callback<ResExchangeOrderCheckStatus>() {
            @Override
            public void onResponse(Call<ResExchangeOrderCheckStatus> call, Response<ResExchangeOrderCheckStatus> response) {
                try {
                    String strApiRtnCode = response.body().getCode();
                    if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {
                        if (response.body().getRetnObject().getTransStatus().equals("Y")) {
                            getActivity().finish();
                        } else {
                            Log.e(TAG, "CheckStatusNoReady");
                        }
                    } else {
                        Log.e(TAG, "Check ERROR-"+response.body().getMessage());
//                        apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                    }
                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call<ResExchangeOrderCheckStatus> call, Throwable t) {
                Log.e(TAG, "CheckOnFailure: "+t.toString());
            }
        });
    }

    int intCountDownExpire;

    private void initTransExpireCountDown() {
        intCountDownExpire = intTransExpireSecond;
        cdtExpireTimer = new CountDownTimer(intTransExpireSecond * 1000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
//                Log.e(TAG, "ExpireCountDown:" + millisUntilFinished+":"+getCountDownTime(intCountDownExpire));
                tvExchangeQrCodeExpireDesc.setText(getCountDownTime(intCountDownExpire));
                intCountDownExpire = intCountDownExpire - 1;
            }

            @Override
            public void onFinish() {
                getActivity().finish();
            }
        }.start();
    }

    @Override
    public void onStop() {
        super.onStop();
        if (cdtExpireTimer != null) {
            cdtExpireTimer.cancel();
        }
    }

    private Handler orderCheckHandler = new Handler();
    private Runnable orderCheckRunnable = new Runnable() {
        @Override
        public void run() {
            apiExchangeOrderCheckStatus();
            Log.e(TAG, "Check Status Runnable");
            orderCheckHandler.postDelayed(orderCheckRunnable, 10000);
        }
    };

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            orderCheckHandler.removeCallbacks(orderCheckRunnable);
            orderCheckHandler = null;
            orderCheckRunnable = null;
        } catch (Exception e) {
            Log.e(TAG, "RemoveHandlerError");
        }
    }

    private String getCountDownTime(int intExpireCountDown) {
        String strRealTime = "";
        int numSec = 0;
        int numMin = 0;
        int numHour = 0;
        int numDay = 0;
        if (intExpireCountDown > 60) {
            numMin = intExpireCountDown / 60;
            numSec = intExpireCountDown % 60;
        }

        if (numMin > 60) {
            numHour = numMin / 60;
            numMin = numMin % 60;
        }

        if (numHour > 24) {
            numDay = numHour / 24;
            numHour = numHour = numHour % 24;
        }
        if (numDay > 0) {
            strRealTime = strRealTime + numDay + "日";
        }

        if (numHour > 0) {
            strRealTime = strRealTime + numHour + "小時";
        }

        if (numMin > 0) {
            strRealTime = strRealTime + numMin + "分";
        }
        strRealTime = strRealTime + numSec + "秒";

        return strRealTime;
    }
}
