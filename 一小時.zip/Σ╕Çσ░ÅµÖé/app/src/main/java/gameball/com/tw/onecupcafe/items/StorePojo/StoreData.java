package gameball.com.tw.onecupcafe.items.StorePojo;

import java.io.Serializable;

public class StoreData implements Serializable {
    String storePK;
    String storeID;
    String storeName;
    String storePhoto1;
    String storePhoto2;
    String storePhoto3;
    String storeAddr;
    String storeAddr1;
    String storeDist;
    String storeTel;
    String storeLike;
    double longitude;
    double latitude;
    double distance;

    public String getStorePK() {
        return storePK;
    }

    public void setStorePK(String storePK) {
        this.storePK = storePK;
    }

    public String getStoreID() {
        return storeID;
    }

    public void setStoreID(String storeID) {
        this.storeID = storeID;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getStorePhoto1() {
        return storePhoto1;
    }

    public void setStorePhoto1(String storePhoto1) {
        this.storePhoto1 = storePhoto1;
    }

    public String getStorePhoto2() {
        return storePhoto2;
    }

    public void setStorePhoto2(String storePhoto2) {
        this.storePhoto2 = storePhoto2;
    }

    public String getStorePhoto3() {
        return storePhoto3;
    }

    public void setStorePhoto3(String storePhoto3) {
        this.storePhoto3 = storePhoto3;
    }

    public String getStoreAddr() {
        return storeAddr;
    }

    public void setStoreAddr(String storeAddr) {
        this.storeAddr = storeAddr;
    }

    public String getStoreAddr1() {
        return storeAddr1;
    }

    public void setStoreAddr1(String storeAddr1) {
        this.storeAddr1 = storeAddr1;
    }

    public String getStoreDist() {
        return storeDist;
    }

    public void setStoreDist(String storeDist) {
        this.storeDist = storeDist;
    }

    public String getStoreTel() {
        return storeTel;
    }

    public void setStoreTel(String storeTel) {
        this.storeTel = storeTel;
    }

    public String getStoreLike() {
        return storeLike;
    }

    public void setStoreLike(String storeLike) {
        this.storeLike = storeLike;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }
}