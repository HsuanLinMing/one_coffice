package gameball.com.tw.onecupcafe.utils;

import com.google.firebase.iid.FirebaseInstanceId;

import gameball.com.tw.onecupcafe.App;
import gameball.com.tw.onecupcafe.R;

/**
 * Created by sofasoso on 2018/3/31.
 */

public class Constants {
    //正式
//        public static final String BASE_URL = "https://api.1cup.cafe/appApi/v1.0/";
    //測試
    public static final String BASE_URL = "https://1cupapi1804.gameball.com.tw/appApi/v1.1/";

    public static final String SALT = "pjfq02d1=qwdc4";

    public static final String ERRORMSG101 = App.getInstance().getString(R.string.error_msg_101);
    public static final String ERRORMSG102 = App.getInstance().getString(R.string.error_msg_102);
    public static final String ERRORMSG103 = App.getInstance().getString(R.string.error_msg_103);
    public static final String ERRORMSG104 = App.getInstance().getString(R.string.error_msg_104);
    public static final String ERRORMSG105 = App.getInstance().getString(R.string.error_msg_105);
    public static final String ERRORMSG106 = App.getInstance().getString(R.string.error_msg_106);
    public static final String ERRORMSG107 = App.getInstance().getString(R.string.error_msg_107);
    public static final String ERRORMSG109 = App.getInstance().getString(R.string.error_msg_109);

    //UserData
    public static final String USER_EMAIL = "UserEmail";
    public static final String USER_PHONE = "UserPhone";
    public static final String USER_ID = "UserId";
    public static final String USER_NAME = "UserName";
    public static final String USER_ACCTOKEN = "UserAccToken";
    public static final String USER_FB_ACCTOKEN = "UserFbAccToken";
    public static final String USER_DEF_DATA = "Default";
    public static final String USER_LOGIN_TYPE = "LoginType";
    public static final String USER_TOKEN_EXPIRE_TIME = "expireTime";
    public static final String USER_PHOTO_URL = "PhotoUrl";
    public static String strSenderId;

    //QR Code
    public static final String QRCODE_SALT = "gameball201805071604";
    public static final String TRANS_TYPE_BUY = "100001";
    public static final String TRANS_TYPE_REDEEM = "100002";
    public static final String TRANS_TYPE_REFUND = "100003";

    public static final String PRIVACY_URL = "https://www.1cup.cafe/privacy.php";
//    public static final String PRIVACY_URL = BASE_URL + "privacy.php";
}
