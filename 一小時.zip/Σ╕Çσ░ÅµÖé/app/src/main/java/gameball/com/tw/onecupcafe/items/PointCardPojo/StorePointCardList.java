package gameball.com.tw.onecupcafe.items.PointCardPojo;

import android.os.Parcelable;

import java.io.Serializable;
import java.util.ArrayList;

public class StorePointCardList implements Serializable{
    public String storePK;
    public String storeID;
    public  String storeName;
    public String storePhoto1;
    public String storePhoto2;
    public String storePhoto3;
    public String storeAddr;
    public String storeDist;
    public String storeTel;
    public String storeLike;
    public String longitude;
    public String latitude;
    public String remianingTotal;
    public ArrayList<StoreOrder> orderList;

    public String getStorePK() {
        return storePK;
    }

    public void setStorePK(String storePK) {
        this.storePK = storePK;
    }

    public String getStoreID() {
        return storeID;
    }

    public void setStoreID(String storeID) {
        this.storeID = storeID;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getStorePhoto1() {
        return storePhoto1;
    }

    public void setStorePhoto1(String storePhoto1) {
        this.storePhoto1 = storePhoto1;
    }

    public String getStorePhoto2() {
        return storePhoto2;
    }

    public void setStorePhoto2(String storePhoto2) {
        this.storePhoto2 = storePhoto2;
    }

    public String getStorePhoto3() {
        return storePhoto3;
    }

    public void setStorePhoto3(String storePhoto3) {
        this.storePhoto3 = storePhoto3;
    }

    public String getStoreAddr() {
        return storeAddr;
    }

    public void setStoreAddr(String storeAddr) {
        this.storeAddr = storeAddr;
    }

    public String getStoreDist() {
        return storeDist;
    }

    public void setStoreDist(String storeDist) {
        this.storeDist = storeDist;
    }

    public String getStoreTel() {
        return storeTel;
    }

    public void setStoreTel(String storeTel) {
        this.storeTel = storeTel;
    }

    public String getStoreLike() {
        return storeLike;
    }

    public void setStoreLike(String storeLike) {
        this.storeLike = storeLike;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getRemianingTotal() {
        return remianingTotal;
    }

    public void setRemianingTotal(String remianingTotal) {
        this.remianingTotal = remianingTotal;
    }

    public ArrayList<StoreOrder> getOrderList() {
        return orderList;
    }

    public void setOrderList(ArrayList<StoreOrder> orderList) {
        this.orderList = orderList;
    }

    public static class StoreOrder implements Serializable{
        public String redeemID;
        public String orderID;
        public String prodID;
        public String prodTitle;
        public String subTitle;
        public String prodImage1;
        public String prodImage2;
        public String friendID;
        public String friendName;
        public String friendImage;
        public String expireDate;
        public String allowRefund;
        public String allowShared;
        public String totalQty;
        public String redeemQty;
        public String sharedQty;
        public String remianingQty;
        public String redeemNote;
        public String refundNote;

        public String getRedeemID() {
            return redeemID;
        }

        public void setRedeemID(String redeemID) {
            this.redeemID = redeemID;
        }

        public String getOrderID() {
            return orderID;
        }

        public void setOrderID(String orderID) {
            this.orderID = orderID;
        }

        public String getProdID() {
            return prodID;
        }

        public void setProdID(String prodID) {
            this.prodID = prodID;
        }

        public String getProdTitle() {
            return prodTitle;
        }

        public void setProdTitle(String prodTitle) {
            this.prodTitle = prodTitle;
        }

        public String getSubTitle() {
            return subTitle;
        }

        public void setSubTitle(String subTitle) {
            this.subTitle = subTitle;
        }

        public String getProdImage1() {
            return prodImage1;
        }

        public void setProdImage1(String prodImage1) {
            this.prodImage1 = prodImage1;
        }

        public String getProdImage2() {
            return prodImage2;
        }

        public void setProdImage2(String prodImage2) {
            this.prodImage2 = prodImage2;
        }

        public String getFriendID() {
            return friendID;
        }

        public void setFriendID(String friendID) {
            this.friendID = friendID;
        }

        public String getFriendName() {
            return friendName;
        }

        public void setFriendName(String friendName) {
            this.friendName = friendName;
        }

        public String getFriendImage() {
            return friendImage;
        }

        public void setFriendImage(String friendImage) {
            this.friendImage = friendImage;
        }

        public String getExpireDate() {
            return expireDate;
        }

        public void setExpireDate(String expireDate) {
            this.expireDate = expireDate;
        }

        public String getAllowRefund() {
            return allowRefund;
        }

        public void setAllowRefund(String allowRefund) {
            this.allowRefund = allowRefund;
        }

        public String getAllowShared() {
            return allowShared;
        }

        public void setAllowShared(String allowShared) {
            this.allowShared = allowShared;
        }

        public String getTotalQty() {
            return totalQty;
        }

        public void setTotalQty(String totalQty) {
            this.totalQty = totalQty;
        }

        public String getRedeemQty() {
            return redeemQty;
        }

        public void setRedeemQty(String redeemQty) {
            this.redeemQty = redeemQty;
        }

        public String getSharedQty() {
            return sharedQty;
        }

        public void setSharedQty(String sharedQty) {
            this.sharedQty = sharedQty;
        }

        public String getRemianingQty() {
            return remianingQty;
        }

        public void setRemianingQty(String remianingQty) {
            this.remianingQty = remianingQty;
        }

        public String getRedeemNote() {
            return redeemNote;
        }

        public void setRedeemNote(String redeemNote) {
            this.redeemNote = redeemNote;
        }

        public String getRefundNote() {
            return refundNote;
        }

        public void setRefundNote(String refundNote) {
            this.refundNote = refundNote;
        }
    }
}
