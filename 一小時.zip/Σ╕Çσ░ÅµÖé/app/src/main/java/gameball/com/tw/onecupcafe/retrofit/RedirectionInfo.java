package gameball.com.tw.onecupcafe.retrofit;

import java.util.Map;

import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResUserFBLogin;

public class RedirectionInfo {
    private String code;
    private String message;
    private Map<String, String> retnObject;
    
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Map<String, String> getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(Map<String, String> retnObject) {
        this.retnObject = retnObject;
    }
}
