package gameball.com.tw.onecupcafe.items.StorePojo;

import java.io.Serializable;
import java.util.ArrayList;

public class ResGetStoreMoreArticles implements Serializable {
    String code;
    String message;
    ReturnData retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ReturnData getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(ReturnData retnObject) {
        this.retnObject = retnObject;
    }

    class ReturnData{
        String storePK;
        ArrayList<Story> storyList;

        public String getStorePK() {
            return storePK;
        }

        public void setStorePK(String storePK) {
            this.storePK = storePK;
        }

        public ArrayList<Story> getStoryList() {
            return storyList;
        }

        public void setStoryList(ArrayList<Story> storyList) {
            this.storyList = storyList;
        }

        class Story{
            String storyID;
            String storyDate;
            String storyTitle;
            String storyImage;
            String storyMessage;
            String storyURL;

            public String getStoryID() {
                return storyID;
            }

            public void setStoryID(String storyID) {
                this.storyID = storyID;
            }

            public String getStoryDate() {
                return storyDate;
            }

            public void setStoryDate(String storyDate) {
                this.storyDate = storyDate;
            }

            public String getStoryTitle() {
                return storyTitle;
            }

            public void setStoryTitle(String storyTitle) {
                this.storyTitle = storyTitle;
            }

            public String getStoryImage() {
                return storyImage;
            }

            public void setStoryImage(String storyImage) {
                this.storyImage = storyImage;
            }

            public String getStoryMessage() {
                return storyMessage;
            }

            public void setStoryMessage(String storyMessage) {
                this.storyMessage = storyMessage;
            }

            public String getStoryURL() {
                return storyURL;
            }

            public void setStoryURL(String storyURL) {
                this.storyURL = storyURL;
            }
        }
    }
}
