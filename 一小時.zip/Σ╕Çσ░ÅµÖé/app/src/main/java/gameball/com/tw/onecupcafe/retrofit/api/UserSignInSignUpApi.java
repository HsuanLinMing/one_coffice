package gameball.com.tw.onecupcafe.retrofit.api;

import org.json.JSONObject;

import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResCleanMainBubble;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResGetUserInfo;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResUserCertified;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResUserEmailBind;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResUserFBLogin;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResUserInputInfo;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResUserTokenRenew;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Created by sofasoso on 2018/3/31.
 */

public interface UserSignInSignUpApi {
    //會員登入註冊 Step1
    //1. country: string, 國家代碼（不帶+, 例如台灣：886）。
    //2. lang: string, 語系(ex: zh-TW, en-US)
    //3. timezone: string, 時區(+/- n.n, ex: +8 , +8.5)
    //4. method: string, 發送方式（sms=簡訊, ivr=語音, 不帶值一律是sms）
    //5. phone: string, 手機號碼（不帶0, 例如：912345678）
    //6. keyStr: string, 介面存取驗證字串md5(salt + phone + timestamp)
    //7. timestamp: long, 呼叫API當下 timestamp
    @POST("api_001.php")
    Call<ResUserInputInfo> postUserInputInfo(
            @Query("country") String country,
            @Query("lang") String lang,
            @Query("timezone") String timezone,
            @Query("method") String method,
            @Query("phone") String phone,
            @Query("timestamp") String timestamp,
            @Query("keyStr") String keyStr
    );

    //會員登入註冊 Step2
    //1. token: string, api_001回傳的regToken。
    //2. lang: string, 語系(ex: zh-TW, en-US)
    //3. timezone: string, 時區(+/- n.n, ex: +8 , +8.5)
    //4. verifyCode: string, 簡訊認證碼（例如：1234）
    //5. senderID: string, 手機識別碼（APP推播功能需有此代碼）
    //6. senderOS:string, 手機作業系統（ios 或 android）
    //7. keyStr: string, 介面存取驗證字串md5(salt + regToken + timestamp)
    //8. timestamp: long, 呼叫API當下 timestamp
    @POST("api_002.php")
    Call<ResUserCertified> postUserCertified(
            @Query("token") String token,
            @Query("lang") String lang,
            @Query("timezone") String timezone,
            @Query("verifyCode") String verifyCode,
            @Query("senderID") String senderID,
            @Query("senderOS") String senderOS,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    //會員登入註冊 Step3
    // 1. token: string, api_002回傳的accToken。
    // 2. email: string, 使用者的Email帳號。
    // 3. keyStr: string, 介面存取驗證字串md5(salt + accToken + timestamp)
    // 4. timestamp: long, 呼叫API當下 timestamp
    @POST("api_003.php")
    Call<ResUserEmailBind> postUserEmailBind(
            @Query("token") String token,
            @Query("email") String email,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    //第三方註冊(FB)
    //1. regType: string, 註冊第三方(FB,GOOGLE,TWITTER,LINE)。
    //2. reg3rdPartyID: string, 註冊第三方ID。
    //3. lang: string, 語系(ex: zh-TW, en-US)。
    //4. timezone: string, 時區(+/- n.n, ex: +8 , +8.5)
    //5. reg3rdPartyToken: string, 註冊第三方註冊完畢之後的token。(如果第三方有則需回填)
    //6. email: string, 使用者的Email帳號。(非必填欄位)
    //7. country: string, 國家代碼（非必填欄位，不帶+, 例如台灣：886）。
    //8. phone: string, 手機號碼（非必填欄位，不帶0, 例如：912345678）
    //9. senderID: string, 手機識別碼（APP推播功能需有此代碼）
    //10. senderOS:string, 手機作業系統（ios 或 android）
    //11. keyStr: string, 介面存取驗證字串md5(salt + regType + reg3rdPartyID +timestamp)
    //12. timestamp: long, 呼叫API當下 timestamp
    @POST("api_004.php")
    Call<ResUserFBLogin> postUserFBLogin(
            @Query("regType") String regType,
            @Query("reg3rdPartyID") String reg3rdPartyID,
            @Query("lang") String lang,
            @Query("timezone") String timezone,
            @Query("reg3rdPartyToken") String reg3rdPartyToken,
            @Query("email") String email,
            @Query("country") String country,
            @Query("phone") String phone,
            @Query("senderID") String senderID,
            @Query("senderOS") String senderOS,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    //會員Token更新
    //1. token: string, api_002回傳的accToken。
    //2. lang: string, 語系(ex: zh-TW, en-US)
    //3. timezone: string, 時區(+/- n.n, ex: +8 , +8.5)
    //4. keyStr: string, 介面存取驗證字串md5(salt + accToken + timestamp)
    //5. timestamp: long, 呼叫API當下 timestamp
    //6. app_version: string, 版本代號
    //7. senderOS: string, 作業系統
    //8. senderID: string, token
    @POST("api_005.php")
    Call<ResUserTokenRenew> postUserTokenRenew(
            @Query("token") String token,
            @Query("lang") String lang,
            @Query("timezone") String timezone,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp,
            @Query("app_version") String app_version,
            @Query("senderOS") String senderOS,
            @Query("senderID") String senderID
    );

    //消除主選單泡泡提示(v1無此功能)
    //1. token: string, api_002回傳的accToken。
    //2. type: string 主選單項目（storeList:找咖啡, myOrderList:喝咖啡, photoList: 看故事, notify:動態消息, more:更多服務）
    //3. keyStr: string, 介面存取驗證字串 md5(salt + token + timestamp)
    //4. timestamp: long, 呼叫API當下 timestamp
    @POST("api_006.php")
    Call<ResCleanMainBubble> postCleanMainBubble(
            @Query("token") String token,
            @Query("type") String type,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    //取得會員資料
    //1. token: string, api_002回傳的accToken。
    //2. keyStr: string, 介面存取驗證字串md5(salt + accToken + timestamp)
    //3. timestamp: long, 呼叫API當下 timestamp
    @POST("api_007.php")
    Call<ResGetUserInfo> postGetUserInfo(
            @Query("token") String token,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

}
