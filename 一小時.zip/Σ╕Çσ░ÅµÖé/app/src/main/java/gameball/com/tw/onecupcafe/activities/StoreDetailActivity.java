package gameball.com.tw.onecupcafe.activities;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.constraint.Group;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.orhanobut.hawk.Hawk;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.adapters.StoreEventListAdatper;
import gameball.com.tw.onecupcafe.adapters.StoreProductsListAdatper;
import gameball.com.tw.onecupcafe.adapters.StoreStoryListAdatper;
import gameball.com.tw.onecupcafe.core.etc.RecycleViewLayoutManager;
import gameball.com.tw.onecupcafe.items.StorePojo.ResGetStoreDetail;
import gameball.com.tw.onecupcafe.items.StorePojo.StoreDetailData;
import gameball.com.tw.onecupcafe.retrofit.ApiBase;
import gameball.com.tw.onecupcafe.retrofit.api.StoreApi;
import gameball.com.tw.onecupcafe.utils.Constants;
import gameball.com.tw.onecupcafe.utils.GlideImageUtil;
import gameball.com.tw.onecupcafe.utils.IntentActionUtil;
import gameball.com.tw.onecupcafe.utils.MD5Util;
import gameball.com.tw.onecupcafe.utils.ProgressBarUtil;
import gameball.com.tw.onecupcafe.utils.TimeStampUtil;
import gameball.com.tw.onecupcafe.utils.ToastUtil;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

//店家詳細內容

public class StoreDetailActivity extends AppCompatActivity implements View.OnClickListener {
    public static final String TAG = "StoreDetail";
    private ImageView ivStoreDetailTopImg, ivStoreDetailPhone, ivStoreNavi, ivStoreDetailFavo;
    private TextView tvStoreDetailBack, tvStoreDetailMainName, tvStoreDetailAddressContent,
            tvStoreDetailBussinessIsOn, tvStoreDetailBusinessHourContent, tvStoreDetailDistance;
    private RecyclerView rvStoreDetailNews, rvStoreDetailProducts, rvStoreDetailStory;

    private StoreEventListAdatper storeEventListAdatper;
    private StoreProductsListAdatper storeProductsListAdatper;
    private StoreStoryListAdatper storeStoryListAdatper;

    private ArrayList<StoreDetailData.BussinessTime> bizHour = new ArrayList<>();
    private ArrayList<StoreDetailData.StoreProduct> productList = new ArrayList<>();
    private ArrayList<StoreDetailData.StoreEvent> eventList = new ArrayList<>();
    private ArrayList<StoreDetailData.StoreStory> storyList = new ArrayList<>();

    public Group groupStoreDetailEvent, groupStoreDetailProduct, groupStoreDetailStory, groupStoreDetailMain;
//    private ScrollView svStoreDetailMain;

    private String strStorePhoneNum = "";

    public String strStoreName, strStoreId;
    private String strStoreLat, strStoreLng;
    private ProgressBarUtil progressBar;
    private TextView tvStoreDetailBusinessMonday, tvStoreDetailBusinessTuesday, tvStoreDetailBusinessWednesday,
            tvStoreDetailBusinessThursday, tvStoreDetailBusinessFriday, tvStoreDetailBusinessSaturday, tvStoreDetailBusinessSunday;
    public View viewPlzLogin;
    private Button btnGoToSignUp, btnGoToSignUpLater;
    public String strStoreImgUrl = "";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store_detail);
        initView();
    }

    private void initView() {
//        svStoreDetailMain = (ScrollView) findViewById(R.id.svStoreDetailMain);

        groupStoreDetailEvent = (Group) findViewById(R.id.groupStoreDetailEvent);
        groupStoreDetailProduct = (Group) findViewById(R.id.groupStoreDetailProduct);
        groupStoreDetailStory = (Group) findViewById(R.id.groupStoreDetailStory);
        groupStoreDetailMain = (Group) findViewById(R.id.groupStoreDetailMain);

        tvStoreDetailBack = (TextView) findViewById(R.id.tvStoreDetailBack);
        tvStoreDetailBack.setOnClickListener(this);
        tvStoreDetailMainName = (TextView) findViewById(R.id.tvStoreDetailMainName);
        tvStoreDetailAddressContent = (TextView) findViewById(R.id.tvStoreDetailAddressContent);
        tvStoreDetailBusinessHourContent = (TextView) findViewById(R.id.tvStoreDetailBusinessHourContent);
        tvStoreDetailBussinessIsOn = (TextView) findViewById(R.id.tvStoreDetailBussinessIsOn);
        tvStoreDetailDistance = (TextView) findViewById(R.id.tvStoreDetailDistance);

        ivStoreDetailTopImg = (ImageView) findViewById(R.id.ivStoreDetailTopImg);
        ivStoreDetailPhone = (ImageView) findViewById(R.id.ivStoreDetailPhone);
        ivStoreDetailPhone.setOnClickListener(this);
        ivStoreNavi = (ImageView) findViewById(R.id.ivStoreNavi);
        ivStoreNavi.setOnClickListener(this);
        ivStoreDetailFavo = (ImageView) findViewById(R.id.ivStoreDetailFavo);

        rvStoreDetailNews = (RecyclerView) findViewById(R.id.rvStoreDetailEvent);
        rvStoreDetailNews.setFocusable(false);
        rvStoreDetailProducts = (RecyclerView) findViewById(R.id.rvStoreDetailProducts);
        rvStoreDetailProducts.setFocusable(false);
        rvStoreDetailStory = (RecyclerView) findViewById(R.id.rvStoreDetailStory);
        rvStoreDetailStory.setFocusable(false);
        new RecycleViewLayoutManager(this, LinearLayoutManager.VERTICAL, rvStoreDetailNews);
        new RecycleViewLayoutManager(this, LinearLayoutManager.VERTICAL, rvStoreDetailProducts);
        new RecycleViewLayoutManager(this, LinearLayoutManager.VERTICAL, rvStoreDetailStory);

        tvStoreDetailBusinessMonday = (TextView) findViewById(R.id.tvStoreDetailBusinessMonday);
        tvStoreDetailBusinessTuesday = (TextView) findViewById(R.id.tvStoreDetailBusinessTuesday);
        tvStoreDetailBusinessWednesday = (TextView) findViewById(R.id.tvStoreDetailBusinessWednesday);
        tvStoreDetailBusinessThursday = (TextView) findViewById(R.id.tvStoreDetailBusinessThursday);
        tvStoreDetailBusinessFriday = (TextView) findViewById(R.id.tvStoreDetailBusinessFriday);
        tvStoreDetailBusinessSaturday = (TextView) findViewById(R.id.tvStoreDetailBusinessSaturday);
        tvStoreDetailBusinessSunday = (TextView) findViewById(R.id.tvStoreDetailBusinessSunday);

        progressBar = new ProgressBarUtil(StoreDetailActivity.this);
        progressBar.show();

        viewPlzLogin = (View) findViewById(R.id.viewPlzLogin);
        btnGoToSignUp = (Button) findViewById(R.id.btnGoToSignUp);
        btnGoToSignUp.setOnClickListener(this);
        btnGoToSignUpLater = (Button) findViewById(R.id.btnGoToSignUpLater);
        btnGoToSignUpLater.setOnClickListener(this);
        apiStoreDetail();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnGoToSignUp:
                startActivity(new Intent(StoreDetailActivity.this, SettingPageActivity.class)
                        .putExtra("ServiceCategory", "PhoneCertified"));
                break;
            case R.id.btnGoToSignUpLater:
                viewPlzLogin.setVisibility(View.GONE);
                groupStoreDetailMain.setVisibility(View.VISIBLE);
                groupStoreDetailProduct.setVisibility(View.VISIBLE);
                break;
            case R.id.tvStoreDetailBack:
                StoreDetailActivity.this.finish();
                break;
            case R.id.ivStoreDetailPhone:
                if (!strStorePhoneNum.equals("")) {
                    IntentActionUtil.phoneCall(strStorePhoneNum);
                }
                break;
            //導向GoogleMap
            case R.id.ivStoreNavi:
                String strStoreGeo = "http://maps.google.com/maps?q=loc:" + strStoreLat + "," + strStoreLng + " (" + strStoreName + ")";
                Uri gmmIntentUri = Uri.parse(strStoreGeo);
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                if (mapIntent.resolveActivity(getPackageManager()) != null) {
                    startActivity(mapIntent);
                }
                break;
            default:
                break;
        }
    }

    private void apiStoreDetail() {
        String strStoreId = getIntent().getExtras().getString("StoreId");

        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strToken = Hawk.get(Constants.USER_ACCTOKEN,"");
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken, strTimeStamp);
        Call<ResGetStoreDetail> getStoreDetail =
                ApiBase.instance().create(StoreApi.class).
                        postGetStoreDetail(
                                strToken,
                                strStoreId,
                                strKeyStr,
                                strTimeStamp);
        Log.e(TAG, "Params-Token:" + "" + ";StoreId:" + strStoreId + ";KeyStr:" + strKeyStr + ";TimeStamp:" + strTimeStamp);
        getStoreDetail.enqueue(new Callback<ResGetStoreDetail>() {
            @Override
            public void onResponse(Call<ResGetStoreDetail> call, Response<ResGetStoreDetail> response) {
                Log.e(TAG, "res:" + response.body().getCode());
                progressBar.hide();
                if (response.body().getCode().equals("000")) {
                    bizHour = response.body().getRetnObject().getBizHour();

                    setStoreDataView(response.body().getRetnObject());
                } else {
                    ToastUtil.showToastMsg(response.body().getMessage());
                }
            }

            @Override
            public void onFailure(Call<ResGetStoreDetail> call, Throwable t) {
                Log.e(TAG, "exc:" + t.toString());
            }
        });
    }

    //設定店家詳細資料內容
    private void setStoreDataView(StoreDetailData storeDetailData) {
        strStoreImgUrl = storeDetailData.getStorePhoto1();
        Log.e(TAG, "StoreMainImage:" + strStoreImgUrl);
        new GlideImageUtil(this,
                strStoreImgUrl,
                ivStoreDetailTopImg, R.drawable.img_store_mid_default).LoadImageWithGlide();


        int numStoreDistance = getIntent().getExtras().getInt("StoreDistance");
        double numUserLat = getIntent().getExtras().getDouble("UserLat");
        String strStoreDistance = "";
        Log.e(TAG, "Distance:" + numStoreDistance);

        if (numUserLat != 0) {
            if (numStoreDistance > 1000) {
                double numStoreDistanceKM = numStoreDistance / 1000.00;
                DecimalFormat df = new DecimalFormat("#.#");
                strStoreDistance = df.format(numStoreDistanceKM);
                tvStoreDetailDistance.setText(strStoreDistance + getString(R.string.store_distance_km));
            } else {
                tvStoreDetailDistance.setText(numStoreDistance + getString(R.string.store_distance_meter));
            }
        } else {
            tvStoreDetailDistance.setVisibility(View.GONE);
        }

        strStoreLat = storeDetailData.getLatitude();
        strStoreLng = storeDetailData.getLongitude();

        strStoreName = storeDetailData.getStoreName();
        strStoreId = storeDetailData.getStoreID();
        tvStoreDetailMainName.setText(strStoreName);
        tvStoreDetailAddressContent.setText(storeDetailData.getStoreAddr());

        strStorePhoneNum = storeDetailData.getStoreTel();

        String strIsLike = storeDetailData.getStoreLike();
        Log.e(TAG,"IsLike"+strIsLike);
        if (strIsLike.equals("1")) {
            ivStoreDetailFavo.setImageResource(R.drawable.ico_base_heart);
        } else {
            ivStoreDetailFavo.setImageResource(R.drawable.ico_base_heart_o);
        }

        productList = storeDetailData.getProductList();
        eventList = storeDetailData.getEventList();
        storyList = storeDetailData.getStoryList();
        if (eventList != null && eventList.size() > 0) {
            storeEventListAdatper = new StoreEventListAdatper(this, eventList);
            rvStoreDetailNews.setAdapter(storeEventListAdatper);
        } else {
            groupStoreDetailEvent.setVisibility(View.GONE);
        }


        if (productList != null && productList.size() > 0) {
            storeProductsListAdatper = new StoreProductsListAdatper(this, productList);
            rvStoreDetailProducts.setAdapter(storeProductsListAdatper);
        } else {
            groupStoreDetailProduct.setVisibility(View.GONE);
        }

        if (storyList != null && storyList.size() > 0) {
            storeStoryListAdatper = new StoreStoryListAdatper(this, storyList);
            rvStoreDetailStory.setAdapter(storeStoryListAdatper);
        } else {
            groupStoreDetailStory.setVisibility(View.GONE);
        }

        switchBusinessTime(storeDetailData.getBizHour());
    }

    private void switchBusinessTime(ArrayList<StoreDetailData.BussinessTime> bizHour) {
//        ArrayList<StoreDetailData.BussinessTime> separateDay = bizHour;
//        ArrayList<StoreDetailData.BussinessTime> weekDay = new ArrayList<>();
//        for (int i = 0; i < bizHour.size(); i++) {
//            StoreDetailData.BussinessTime day1 = bizHour.get(i);
//            String day1Time = day1.getBeginTime() + "-" + day1.getEndTime();
//            for (int j = 0; j < bizHour.size(); j++) {
//                StoreDetailData.BussinessTime day2 = bizHour.get(j);
//                String day2Time = day2.getBeginTime() + "-" + day2.getEndTime();
//                if (i != j) {
//                    if (!day1Time.equals(day2Time)) {
//                        weekDay.add(day1);
//                        bizHour.remove(i);
//                        break;
//                    }
//                }
//            }
//        }

//        HashSet hs = new HashSet();
//        hs.addAll(weekDay);
//        weekDay.clear();
//        weekDay.addAll(hs);

//        String showBusinessHour = "";
//        for (int k = 0; k < weekDay.size(); k++) {
//            switch (weekDay.get(k).getW()) {
        for (int k = 0; k < bizHour.size(); k++) {
            switch (bizHour.get(k).getW()) {
                case 0:
//                    showBusinessHour = showBusinessHour + "星期日 " + weekDay.get(k).getBeginTime() + "~" + weekDay.get(k).getEndTime() + "\n";
                    tvStoreDetailBusinessSunday.setText("星期日 " + bizHour.get(k).getBeginTime() + "~" + bizHour.get(k).getEndTime());
                    break;
                case 1:
//                    showBusinessHour = showBusinessHour + "星期一 " + weekDay.get(k).getBeginTime() + "~" + weekDay.get(k).getEndTime() + "\n";
                    tvStoreDetailBusinessMonday.setText("星期一 " + bizHour.get(k).getBeginTime() + "~" + bizHour.get(k).getEndTime());
                    break;
                case 2:
//                    showBusinessHour = showBusinessHour + "星期二 " + weekDay.get(k).getBeginTime() + "~" + weekDay.get(k).getEndTime() + "\n";
                    tvStoreDetailBusinessTuesday.setText("星期二 " + bizHour.get(k).getBeginTime() + "~" + bizHour.get(k).getEndTime());
                    break;
                case 3:
//                    showBusinessHour = showBusinessHour + "星期三 " + weekDay.get(k).getBeginTime() + "~" + weekDay.get(k).getEndTime() + "\n";
                    tvStoreDetailBusinessWednesday.setText("星期三 " + bizHour.get(k).getBeginTime() + "~" + bizHour.get(k).getEndTime());
                    break;
                case 4:
//                    showBusinessHour = showBusinessHour + "星期四 " + weekDay.get(k).getBeginTime() + "~" + weekDay.get(k).getEndTime() + "\n";
                    tvStoreDetailBusinessThursday.setText("星期四 " + bizHour.get(k).getBeginTime() + "~" + bizHour.get(k).getEndTime());
                    break;
                case 5:
//                    showBusinessHour = showBusinessHour + "星期五 " + weekDay.get(k).getBeginTime() + "~" + weekDay.get(k).getEndTime() + "\n";
                    tvStoreDetailBusinessFriday.setText("星期五 " + bizHour.get(k).getBeginTime() + "~" + bizHour.get(k).getEndTime());
                    break;
                case 6:
//                    showBusinessHour = showBusinessHour + "星期六 " + weekDay.get(k).getBeginTime() + "~" + weekDay.get(k).getEndTime() + "\n";
                    tvStoreDetailBusinessSaturday.setText("星期六 " + bizHour.get(k).getBeginTime() + "~" + bizHour.get(k).getEndTime());
                    break;
            }
        }

//        for (int l = 0; l < weekDay.size(); l++) {
//            Log.e(TAG, "WeekDay" + l + ":" + weekDay.get(l).getW() + "::" + weekDay.get(l).getBeginTime() + "-" + weekDay.get(l).getEndTime());
//        }
//
//        for (int m = 0; m < separateDay.size(); m++) {
//            Log.e(TAG, "Separateday" + m + ":" + separateDay.get(m).getW() + "::" + separateDay.get(m).getBeginTime() + "-" + separateDay.get(m).getEndTime());
//        }
//        String startDay = getDay(separateDay.get(0).getW());
//
//        String endDay = getDay(separateDay.get(separateDay.size() - 1).getW());
//        tvStoreDetailBusinessHourContent.setText(showBusinessHour + startDay + "到" + endDay + " " + separateDay.get(0).getBeginTime() + "-" + separateDay.get(0).getEndTime());
//        Log.e(TAG, "WeekDay:" + weekDay.size()+"Separateday:"+separateDay.size());

        Calendar calendar = Calendar.getInstance();
        int day = calendar.get(Calendar.DAY_OF_WEEK);
        Log.e(TAG, "day:" + day);
        setDayHighLight(day - 1);
        try {
            String format = "HH:mm";
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
            String getPhoneNow = sdf.format(calendar.getTime());
            Date nowTime = new SimpleDateFormat(format).parse(getPhoneNow);
            Date startTime = new SimpleDateFormat(format).parse(bizHour.get(day - 1).getBeginTime());
            Date endTime = new SimpleDateFormat(format).parse(bizHour.get(day - 1).getEndTime());
            if (isEffectiveDate(nowTime, startTime, endTime) == true) {
                tvStoreDetailBussinessIsOn.setText("營業中");
            } else {
                tvStoreDetailBussinessIsOn.setText("休息中");
            }
        } catch (Exception e) {
            Log.e(TAG, e.toString());
        }
    }

    private String getDay(int dayCode) {
        String returnDay = "";
        switch (dayCode) {
            case 0:
                returnDay = "週日";
                break;
            case 1:
                returnDay = "週一";
                break;
            case 2:
                returnDay = "週二";
                break;
            case 3:
                returnDay = "週三";
                break;
            case 4:
                returnDay = "週四";
                break;
            case 5:
                returnDay = "週五";
                break;
            case 6:
                returnDay = "週六";
                break;
        }
        return returnDay;
    }

    private void setDayHighLight(int dayCode) {
        switch (dayCode) {
            case 0:
                tvStoreDetailBusinessSunday.setTextColor(Color.parseColor("#000000"));
                break;
            case 1:
                tvStoreDetailBusinessMonday.setTextColor(Color.parseColor("#000000"));
                break;
            case 2:
                tvStoreDetailBusinessTuesday.setTextColor(Color.parseColor("#000000"));
                break;
            case 3:
                tvStoreDetailBusinessWednesday.setTextColor(Color.parseColor("#000000"));
                break;
            case 4:
                tvStoreDetailBusinessThursday.setTextColor(Color.parseColor("#000000"));
                break;
            case 5:
                tvStoreDetailBusinessFriday.setTextColor(Color.parseColor("#000000"));
                break;
            case 6:
                tvStoreDetailBusinessSaturday.setTextColor(Color.parseColor("#000000"));
                break;
        }
    }

    public boolean isEffectiveDate(Date nowTime, Date startTime, Date endTime) {
        if (nowTime.getTime() == startTime.getTime()
                || nowTime.getTime() == endTime.getTime()) {
            return true;
        }

        Calendar date = Calendar.getInstance();
        date.setTime(nowTime);

        Calendar begin = Calendar.getInstance();
        begin.setTime(startTime);

        Calendar end = Calendar.getInstance();
        end.setTime(endTime);

        if (date.after(begin) && date.before(end)) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    protected void onPostResume() {
        if (!Hawk.get(Constants.USER_ACCTOKEN, Constants.USER_DEF_DATA).equals(Constants.USER_DEF_DATA)
                && viewPlzLogin.getVisibility() == View.VISIBLE) {
            viewPlzLogin.setVisibility(View.GONE);
            groupStoreDetailMain.setVisibility(View.VISIBLE);
            groupStoreDetailProduct.setVisibility(View.VISIBLE);
        }
        super.onPostResume();
    }
}
