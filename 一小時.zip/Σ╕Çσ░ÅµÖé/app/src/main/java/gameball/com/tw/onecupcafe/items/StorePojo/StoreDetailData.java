package gameball.com.tw.onecupcafe.items.StorePojo;

import java.io.Serializable;
import java.util.ArrayList;

public class StoreDetailData {
    String storePK;
    String storeID;
    String storeName;
    String storePhoto1;
    String storePhoto2;
    String storePhoto3;
    String storeAddr;
    String storeDist;
    String storeTel;
    String storeRank;
    String storeLike;
    String storeType;
    String storeRewardType;
    String longitude;
    String latitude;
    ArrayList<BussinessTime> bizHour;
    String socialFB;
    String socialLine;
    String socialTwitter;
    String socialInstagram;
    String socialWebSite;
    ArrayList<StoreProduct> productList;
    ArrayList<StoreEvent> eventList;
    ArrayList<StoreStory> storyList;

    public class BussinessTime {
        int w;
        String beginTime;
        String endTime;

        public int getW() {
            return w;
        }

        public void setW(int w) {
            this.w = w;
        }

        public String getBeginTime() {
            return beginTime;
        }

        public void setBeginTime(String beginTime) {
            this.beginTime = beginTime;
        }

        public String getEndTime() {
            return endTime;
        }

        public void setEndTime(String endTime) {
            this.endTime = endTime;
        }
    }

    public class StoreProduct implements Serializable {
        String prodID;
        String prodTitle;
        String subTitle;
        String prodImage;
        String qtyPerSet;
        String salePrice;
        String expDate;
        String productURL;

        public String getProdID() {
            return prodID;
        }

        public void setProdID(String prodID) {
            this.prodID = prodID;
        }

        public String getProdTitle() {
            return prodTitle;
        }

        public void setProdTitle(String prodTitle) {
            this.prodTitle = prodTitle;
        }

        public String getSubTitle() {
            return subTitle;
        }

        public void setSubTitle(String subTitle) {
            this.subTitle = subTitle;
        }

        public String getProdImage() {
            return prodImage;
        }

        public void setProdImage(String prodImage) {
            this.prodImage = prodImage;
        }

        public String getQtyPerSet() {
            return qtyPerSet;
        }

        public void setQtyPerSet(String qtyPerSet) {
            this.qtyPerSet = qtyPerSet;
        }

        public String getSalePrice() {
            return salePrice;
        }

        public void setSalePrice(String salePrice) {
            this.salePrice = salePrice;
        }

        public String getExpDate() {
            return expDate;
        }

        public void setExpDate(String expDate) {
            this.expDate = expDate;
        }

        public String getProductURL() {
            return productURL;
        }

        public void setProductURL(String productURL) {
            this.productURL = productURL;
        }
    }

    public class StoreEvent {
        String eventID;
        int eventType;
        String eventDate;
        String eventMessage;
        String eventURL;

        public String getEventID() {
            return eventID;
        }

        public void setEventID(String eventID) {
            this.eventID = eventID;
        }

        public int getEventType() {
            return eventType;
        }

        public void setEventType(int eventType) {
            this.eventType = eventType;
        }

        public String getEventDate() {
            return eventDate;
        }

        public void setEventDate(String eventDate) {
            this.eventDate = eventDate;
        }

        public String getEventMessage() {
            return eventMessage;
        }

        public void setEventMessage(String eventMessage) {
            this.eventMessage = eventMessage;
        }

        public String getEventURL() {
            return eventURL;
        }

        public void setEventURL(String eventURL) {
            this.eventURL = eventURL;
        }
    }

    public class StoreStory {
        String storyID;
        String storyDate;
        String storyTitle;
        String storyImage;
        String storyMessage;
        String storyURL;

        public String getStoryID() {
            return storyID;
        }

        public void setStoryID(String storyID) {
            this.storyID = storyID;
        }

        public String getStoryDate() {
            return storyDate;
        }

        public void setStoryDate(String storyDate) {
            this.storyDate = storyDate;
        }

        public String getStoryTitle() {
            return storyTitle;
        }

        public void setStoryTitle(String storyTitle) {
            this.storyTitle = storyTitle;
        }

        public String getStoryImage() {
            return storyImage;
        }

        public void setStoryImage(String storyImage) {
            this.storyImage = storyImage;
        }

        public String getStoryMessage() {
            return storyMessage;
        }

        public void setStoryMessage(String storyMessage) {
            this.storyMessage = storyMessage;
        }

        public String getStoryURL() {
            return storyURL;
        }

        public void setStoryURL(String storyURL) {
            this.storyURL = storyURL;
        }
    }

    public String getStoreRank() {
        return storeRank;
    }

    public void setStoreRank(String storeRank) {
        this.storeRank = storeRank;
    }

    public String getStorePK() {
        return storePK;
    }

    public void setStorePK(String storePK) {
        this.storePK = storePK;
    }

    public String getStoreID() {
        return storeID;
    }

    public void setStoreID(String storeID) {
        this.storeID = storeID;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getStorePhoto1() {
        return storePhoto1;
    }

    public void setStorePhoto1(String storePhoto1) {
        this.storePhoto1 = storePhoto1;
    }

    public String getStorePhoto2() {
        return storePhoto2;
    }

    public void setStorePhoto2(String storePhoto2) {
        this.storePhoto2 = storePhoto2;
    }

    public String getStorePhoto3() {
        return storePhoto3;
    }

    public void setStorePhoto3(String storePhoto3) {
        this.storePhoto3 = storePhoto3;
    }

    public String getStoreAddr() {
        return storeAddr;
    }

    public void setStoreAddr(String storeAddr) {
        this.storeAddr = storeAddr;
    }

    public String getStoreDist() {
        return storeDist;
    }

    public void setStoreDist(String storeDist) {
        this.storeDist = storeDist;
    }

    public String getStoreRewardType() {
        return storeRewardType;
    }

    public void setStoreRewardType(String storeRewardType) {
        this.storeRewardType = storeRewardType;
    }

    public String getStoreTel() {
        return storeTel;
    }

    public void setStoreTel(String storeTel) {
        this.storeTel = storeTel;
    }

    public String getStoreLike() {
        return storeLike;
    }

    public void setStoreLike(String storeLike) {
        this.storeLike = storeLike;
    }

    public String getStoreType() {
        return storeType;
    }

    public void setStoreType(String storeType) {
        this.storeType = storeType;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public ArrayList<BussinessTime> getBizHour() {
        return bizHour;
    }

    public void setBizHour(ArrayList<BussinessTime> bizHour) {
        this.bizHour = bizHour;
    }

    public String getSocialFB() {
        return socialFB;
    }

    public void setSocialFB(String socialFB) {
        this.socialFB = socialFB;
    }

    public String getSocialLine() {
        return socialLine;
    }

    public void setSocialLine(String socialLine) {
        this.socialLine = socialLine;
    }

    public String getSocialTwitter() {
        return socialTwitter;
    }

    public void setSocialTwitter(String socialTwitter) {
        this.socialTwitter = socialTwitter;
    }

    public String getSocialInstagram() {
        return socialInstagram;
    }

    public void setSocialInstagram(String socialInstagram) {
        this.socialInstagram = socialInstagram;
    }

    public String getSocialWebSite() {
        return socialWebSite;
    }

    public void setSocialWebSite(String socialWebSite) {
        this.socialWebSite = socialWebSite;
    }

    public ArrayList<StoreProduct> getProductList() {
        return productList;
    }

    public void setProductList(ArrayList<StoreProduct> productList) {
        this.productList = productList;
    }

    public ArrayList<StoreEvent> getEventList() {
        return eventList;
    }

    public void setEventList(ArrayList<StoreEvent> eventList) {
        this.eventList = eventList;
    }

    public ArrayList<StoreStory> getStoryList() {
        return storyList;
    }

    public void setStoryList(ArrayList<StoreStory> storyList) {
        this.storyList = storyList;
    }
}
