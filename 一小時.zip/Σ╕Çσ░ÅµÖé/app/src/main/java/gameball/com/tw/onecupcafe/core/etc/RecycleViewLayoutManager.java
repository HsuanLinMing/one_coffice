package gameball.com.tw.onecupcafe.core.etc;


import android.content.Context;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import jp.wasabeef.recyclerview.animators.SlideInUpAnimator;

public class RecycleViewLayoutManager{
    private Context mContext;
    private int layoutOrientation;
    private RecyclerView recyclerView;

    public RecycleViewLayoutManager(Context mContext, int layoutOrientation,RecyclerView recyclerView) {
        this.mContext = mContext;
        this.layoutOrientation = layoutOrientation;
        this.recyclerView = recyclerView;
        setLayoutOrientation();
    }

    void setLayoutOrientation(){
        LinearLayoutManager layoutManager = new LinearLayoutManager(mContext);
        layoutManager.setOrientation(layoutOrientation);
        recyclerView.setLayoutManager(layoutManager);
        //以下可不要
        recyclerView.addItemDecoration(new DividerItemDecoration(mContext,
                DividerItemDecoration.VERTICAL_LIST));
        recyclerView.setItemAnimator(new SlideInUpAnimator());
    }

}
