package gameball.com.tw.onecupcafe.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.items.StorePojo.StoreDetailData;

/**
 * Created by sofasoso on 2018/4/1.
 */

public class StoreEventListAdatper extends RecyclerView.Adapter<StoreEventListAdatper.ViewHoler> {
    private Context context;
    private ArrayList<StoreDetailData.StoreEvent> data;

    public StoreEventListAdatper(Context context, ArrayList<StoreDetailData.StoreEvent> data) {
        this.context = context;
        this.data = data;
    }

    public class ViewHoler extends RecyclerView.ViewHolder {
        private TextView tvStoreDetailUpdateTime,tvStoreDetailActivityContent;
        private ImageView ivStoreDetailActivitiesCategory;
        public ViewHoler(View v) {
            super(v);
            tvStoreDetailUpdateTime = (TextView) v.findViewById(R.id.tvStoreDetailUpdateTime);
            tvStoreDetailActivityContent = (TextView) v.findViewById(R.id.tvStoreDetailActivityContent);
            ivStoreDetailActivitiesCategory = (ImageView) v.findViewById(R.id.ivStoreDetailActivitiesCategory);
        }
    }

    @NonNull
    @Override
    public ViewHoler onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_store_detail_new_activities, parent, false);
        ViewHoler viewHoler = new ViewHoler(v);
        return viewHoler;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHoler holder, int position) {
        StoreDetailData.StoreEvent eventData = data.get(position);
        holder.tvStoreDetailUpdateTime.setText(eventData.getEventDate());
        holder.tvStoreDetailActivityContent.setText(eventData.getEventID());
        holder.tvStoreDetailActivityContent.setText(eventData.getEventMessage());
    }

    @Override
    public int getItemCount() {
        return data.size();
    }
}
