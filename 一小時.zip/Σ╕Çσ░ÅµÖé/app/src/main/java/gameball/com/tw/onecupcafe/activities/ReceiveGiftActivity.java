package gameball.com.tw.onecupcafe.activities;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.makeramen.roundedimageview.RoundedImageView;
import com.orhanobut.hawk.Hawk;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResExchangeOrderCancel;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResReceiveRejectGift;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResShareGiftWithFriend;
import gameball.com.tw.onecupcafe.retrofit.ApiBase;
import gameball.com.tw.onecupcafe.retrofit.api.PointCardApi;
import gameball.com.tw.onecupcafe.utils.Constants;
import gameball.com.tw.onecupcafe.utils.GlideImageUtil;
import gameball.com.tw.onecupcafe.utils.MD5Util;
import gameball.com.tw.onecupcafe.utils.ProgressBarUtil;
import gameball.com.tw.onecupcafe.utils.ResStatusReturn;
import gameball.com.tw.onecupcafe.utils.TimeStampUtil;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ReceiveGiftActivity extends AppCompatActivity implements View.OnClickListener {
    public static final String TAG = "ReceiveGift";
    private ImageView ivReceiveGiftStoreImage;
    private TextView tvReceiveGiftStoreName, tvReceiveGiftOwnerName, tvReceiveGiftProdName,
            tvReceiveGiftMessage, tvReceiveGiftTermDate;
    private RoundedImageView rivReceiveGiftProdImage, rivReceiveGiftOwnerImage;
    private Button btnReceiveGiftReject, btnReceiveGiftConfirm;
    private ProgressBarUtil progressBar;

    private String strGiftTransCode;
    private String strReceRetnTransToken;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_gift);
        initView();
    }

    private void initView() {
        progressBar = new ProgressBarUtil(ReceiveGiftActivity.this);

        strGiftTransCode = getIntent().getExtras().getString("GiftTransCode");

        Log.e(TAG, "GiftCode:" + strGiftTransCode);

        ivReceiveGiftStoreImage = (ImageView) findViewById(R.id.ivReceiveGiftStoreImage);

        tvReceiveGiftStoreName = (TextView) findViewById(R.id.tvReceiveGiftStoreName);
        tvReceiveGiftOwnerName = (TextView) findViewById(R.id.tvReceiveGiftOwnerName);
        tvReceiveGiftProdName = (TextView) findViewById(R.id.tvReceiveGiftProdName);
        tvReceiveGiftMessage = (TextView) findViewById(R.id.tvReceiveGiftMessage);
        tvReceiveGiftTermDate = (TextView) findViewById(R.id.tvReceiveGiftTermDate);

        rivReceiveGiftProdImage = (RoundedImageView) findViewById(R.id.rivReceiveGiftProdImage);
        rivReceiveGiftOwnerImage = (RoundedImageView) findViewById(R.id.rivReceiveGiftOwnerImage);

        btnReceiveGiftReject = (Button) findViewById(R.id.btnReceiveGiftReject);
        btnReceiveGiftReject.setOnClickListener(this);
        btnReceiveGiftConfirm = (Button) findViewById(R.id.btnReceiveGiftConfirm);
        btnReceiveGiftConfirm.setOnClickListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Hawk.get(Constants.USER_ACCTOKEN, Constants.USER_DEF_DATA).equals(Constants.USER_DEF_DATA)) {
            Bundle bundle = new Bundle();
            bundle.putString("ServiceCategory", "PhoneCertified");
            bundle.putString("From", "RecieveGift");
            startActivity(new Intent(ReceiveGiftActivity.this, SettingPageActivity.class).
                    putExtras(bundle));
        } else {
            apiShareGiftWithFriend(strGiftTransCode);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnReceiveGiftReject:
                apiReceiveRejectGift("return");
                break;
            case R.id.btnReceiveGiftConfirm:
                apiReceiveRejectGift("recive");
                break;
        }
    }

    //todo
    //好友分享，分享序號確認[api_208]
    private void apiShareGiftWithFriend(String strGiftCode) {
        progressBar.show();
        String strToken = Hawk.get(Constants.USER_ACCTOKEN, "");
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken + strGiftCode, strTimeStamp);

        Call<ResShareGiftWithFriend> postShareGiftWithFriend =
                ApiBase.instance().create(PointCardApi.class).
                        postShareGiftWithFriend(
                                strToken,
                                strGiftCode,
                                strKeyStr,
                                strTimeStamp
                        );


        postShareGiftWithFriend.enqueue(new Callback<ResShareGiftWithFriend>() {
            @Override
            public void onResponse(Call<ResShareGiftWithFriend> call, Response<ResShareGiftWithFriend> response) {
                try {
                    String strApiRtnCode = response.body().getCode();
                    if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {
                        initDataView(response.body().retnObject);
                    } else {
                        showErrorMsg(strApiRtnCode);
                        Log.e(TAG, "208ERROR:");
                    }
                    progressBar.hide();
                } catch (Exception e) {
                    progressBar.hide();
                }
            }

            @Override
            public void onFailure(Call<ResShareGiftWithFriend> call, Throwable t) {
                progressBar.hide();
            }
        });

    }

    //todo
    //檔名：好友分享，接收or婉拒 [api_209]
    private void apiReceiveRejectGift(String strAction) {
        Log.e(TAG,"apiReceiveRejectGift");
        progressBar.show();
        String strToken = Hawk.get(Constants.USER_ACCTOKEN, "");
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken, strTimeStamp);

        Call<ResReceiveRejectGift> postReceiveRejectGift =
                ApiBase.instance().create(PointCardApi.class).
                        postReceiveRejectGift(
                                strToken,
                                strAction,
                                strReceRetnTransToken,
                                strKeyStr,
                                strTimeStamp
                        );

        Log.e(TAG,strToken);
        Log.e(TAG,strAction);
        Log.e(TAG,strReceRetnTransToken);
        Log.e(TAG,strKeyStr);
        Log.e(TAG,strTimeStamp);

        postReceiveRejectGift.enqueue(new Callback<ResReceiveRejectGift>() {
            @Override
            public void onResponse(Call<ResReceiveRejectGift> call, Response<ResReceiveRejectGift> response) {
                try {
                    String strApiRtnCode = response.body().getCode();
                    Log.e(TAG,"ReciRetnCode:"+strApiRtnCode);
                    if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {
                        Log.e(TAG, "Api209 Succenss");
                        startActivity(new Intent(ReceiveGiftActivity.this, HomeActivity.class));
                        ReceiveGiftActivity.this.finish();
                    } else {
                        showErrorMsg(strApiRtnCode);
                        Log.e(TAG, "ERROR"+strApiRtnCode);
                    }
                    progressBar.hide();
                } catch (Exception e) {
                    progressBar.hide();
                    Log.e(TAG,"Error2:"+e.toString());
                }
            }

            @Override
            public void onFailure(Call<ResReceiveRejectGift> call, Throwable t) {
                progressBar.hide();
                Log.e(TAG,"Error3:"+t.toString());
            }
        });

    }

    public void showErrorMsg(String strErrorCode) {
//        String strErrorMsg = "";
//        switch (strErrorCode) {
//            case "101":
//                strErrorMsg = getString(R.string.error_msg_101);
//                break;
//            case "102":
//                strErrorMsg = getString(R.string.error_msg_102);
//                break;
//            case "103":
//                strErrorMsg = getString(R.string.error_msg_103);
//                break;
//            case "104":
//                strErrorMsg = getString(R.string.error_msg_104);
//                break;
//            case "105":
//                strErrorMsg = getString(R.string.error_msg_105);
//                break;
//            case "106":
//                strErrorMsg = getString(R.string.error_msg_106);
//                break;
//            case "107":
//                strErrorMsg = getString(R.string.error_msg_107);
//                break;
//            case "109":
//                strErrorMsg = getString(R.string.error_msg_109);
//                break;
//        }
        showErrorAlertDialog(strErrorCode);
    }

    private AlertDialog.Builder builder;
    private void showErrorAlertDialog(String strMsgInfo) {
        Log.e("API ERROR", "MSG:" + strMsgInfo);
        if (builder == null) {
            builder = new AlertDialog.Builder(ReceiveGiftActivity.this);
            builder.setTitle("發生錯誤");
            builder.setMessage(strMsgInfo);
            builder.setCancelable(false);
            builder.setPositiveButton("確認", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    builder = null;
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }

    private void initDataView(ResShareGiftWithFriend.ShareGiftWithFriendReturn dataObj) {
        strReceRetnTransToken = dataObj.getTransToken();
        Context context = ReceiveGiftActivity.this;
        /* Header店家圖片
        new GlideImageUtil(
                context,
                dataObj.getGift().getGiftImage(),
                ivReceiveGiftStoreImage,
                R.drawable.img_store_sml_default
        ).LoadImageWithGlide();
        */
        new GlideImageUtil(
                context,
                dataObj.getGift().getGiftImage(),
                rivReceiveGiftProdImage,
                R.drawable.img_product_sml_default
        ).LoadImageWithGlide();

        //贈送者照片
//        new GlideImageUtil(
//                context,
//                dataObj.getGift(),
//                rivReceiveGiftOwnerImage,
//                R.drawable.img_friend_default
//        ).LoadImageWithGlide();

        tvReceiveGiftOwnerName.setText(dataObj.getOwner());
        tvReceiveGiftMessage.setText(dataObj.getMessage());
        tvReceiveGiftProdName.setText(
                dataObj.getGift().getQuantity() +
                        dataObj.getGift().getGiftUnit() +
                        dataObj.getGift().getGiftName());
        tvReceiveGiftTermDate.setText(dataObj.getGift().getRedeemExpire());
    }

}
