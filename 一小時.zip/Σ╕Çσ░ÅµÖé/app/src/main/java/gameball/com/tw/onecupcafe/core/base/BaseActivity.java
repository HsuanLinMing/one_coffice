package gameball.com.tw.onecupcafe.core.base;

import android.view.KeyEvent;
import android.view.View;

import me.yokeyword.fragmentation.SupportActivity;

public class BaseActivity extends SupportActivity implements View.OnClickListener {

    @Override
    public void onClick(View v) {

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == event.KEYCODE_BACK) {
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
