package gameball.com.tw.onecupcafe.core.base;


import android.app.Application;
import android.arch.lifecycle.Lifecycle;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.squareup.leakcanary.RefWatcher;

import gameball.com.tw.onecupcafe.App;
import gameball.com.tw.onecupcafe.R;
import me.yokeyword.fragmentation.SupportFragment;

/**
 * Created by sofasoso on 2018/3/31.
 */

public class BaseFragment extends SupportFragment implements View.OnClickListener  {

    @Override
    public void onClick(View v) {

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
//        RefWatcher refWatcher = App.getRefWatcher(getActivity());
//        refWatcher.watch(this);
    }
}
