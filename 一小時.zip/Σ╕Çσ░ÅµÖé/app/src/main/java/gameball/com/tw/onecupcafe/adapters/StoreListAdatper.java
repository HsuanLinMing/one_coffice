package gameball.com.tw.onecupcafe.adapters;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.orhanobut.hawk.Hawk;

import java.text.DecimalFormat;
import java.util.ArrayList;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.activities.HomeActivity;
import gameball.com.tw.onecupcafe.activities.StoreDetailActivity;
import gameball.com.tw.onecupcafe.items.StorePojo.ResAddRemoveStoreBookMark;
import gameball.com.tw.onecupcafe.items.StorePojo.StoreData;
import gameball.com.tw.onecupcafe.retrofit.ApiBase;
import gameball.com.tw.onecupcafe.retrofit.api.StoreApi;
import gameball.com.tw.onecupcafe.utils.ApiErrorMsgCallback;
import gameball.com.tw.onecupcafe.utils.Constants;
import gameball.com.tw.onecupcafe.utils.GlideImageUtil;
import gameball.com.tw.onecupcafe.utils.MD5Util;
import gameball.com.tw.onecupcafe.utils.ProgressBarCallBack;
import gameball.com.tw.onecupcafe.utils.ResStatusReturn;
import gameball.com.tw.onecupcafe.utils.TimeStampUtil;
import gameball.com.tw.onecupcafe.utils.ToastUtil;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by sofasoso on 2018/4/1.
 */

public class StoreListAdatper extends RecyclerView.Adapter<StoreListAdatper.ViewHoler> {
    private Context context;
    private ArrayList<StoreData> arrStoreData;
    private ApiErrorMsgCallback apiErrorMsgCallback;
    private ProgressBarCallBack progressBarCallBack;

    public StoreListAdatper(Context context, ArrayList<StoreData> arrStoreData) {
        this.context = context;
        this.arrStoreData = arrStoreData;
        apiErrorMsgCallback = (ApiErrorMsgCallback) context;
        progressBarCallBack = (ProgressBarCallBack) context;
    }

    public class ViewHoler extends RecyclerView.ViewHolder {
        private TextView tvStoreListAddress, tvStoreListName, tvStoreListDistance, tvStoreListDistanceMeter;
        private ImageView ivStoreListMainPic, ivStoreListSetMyFavo;

        public ViewHoler(View v) {
            super(v);
            tvStoreListDistance = (TextView) v.findViewById(R.id.tvStoreListDistance);
            tvStoreListAddress = (TextView) v.findViewById(R.id.tvStoreListAddress);
            tvStoreListName = (TextView) v.findViewById(R.id.tvStoreListName);
            ivStoreListMainPic = (ImageView) v.findViewById(R.id.ivStoreListMainPic);
            tvStoreListDistanceMeter = (TextView) v.findViewById(R.id.tvStoreListDistanceMeter);
            ivStoreListSetMyFavo = (ImageView) v.findViewById(R.id.ivStoreListSetMyFavo);
        }
    }

    @NonNull
    @Override
    public ViewHoler onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_store_list, parent, false);
        ViewHoler viewHoler = new ViewHoler(v);
        return viewHoler;
    }


    @Override
    public void onBindViewHolder(@NonNull final ViewHoler holder, int position) {
        final StoreData storeData = arrStoreData.get(position);
        holder.tvStoreListName.setText(storeData.getStoreName());
        holder.tvStoreListAddress.setText(storeData.getStoreAddr1());
        final int storeDistance = new Double(storeData.getDistance()).intValue();

        if (storeData.getStoreLike().equals("0")) {
            isAddSuccess = false;
            holder.ivStoreListSetMyFavo.setImageResource(R.drawable.ico_base_heart_o);
        } else {
            isAddSuccess = true;
            holder.ivStoreListSetMyFavo.setImageResource(R.drawable.ico_base_heart);
        }


        holder.ivStoreListSetMyFavo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strStorePk = storeData.getStorePK();
                if (!Hawk.get(Constants.USER_ACCTOKEN, Constants.USER_DEF_DATA).equals(Constants.USER_DEF_DATA)) {
                    apiAddRemoveStoreBookMark(strStorePk, holder.ivStoreListSetMyFavo);
                } else {
                    Toast.makeText(context, context.getString(R.string.plz_login_msg), Toast.LENGTH_SHORT).show();
                }
            }
        });

        String strStoreDistance = "";

        if (((HomeActivity) context).numUserLng != 0 && ((HomeActivity) context).numUserLat != 0) {
            if (storeDistance > 1000) {
                double numStoreDistanceKM = storeDistance / 1000.00;
                DecimalFormat df = new DecimalFormat("#.#");
                strStoreDistance = df.format(numStoreDistanceKM);
                holder.tvStoreListDistanceMeter.setText(R.string.store_distance_km);
            } else {
                strStoreDistance = "" + storeDistance;
            }
            holder.tvStoreListDistance.setText(strStoreDistance);
        } else {
            holder.tvStoreListDistance.setVisibility(View.INVISIBLE);
            holder.tvStoreListDistanceMeter.setVisibility(View.INVISIBLE);
        }
        new GlideImageUtil(context, storeData.getStorePhoto1(), holder.ivStoreListMainPic, R.drawable.img_store_mid_default).LoadImageWithGlide();


        holder.ivStoreListMainPic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Activity activity = (Activity) context;
                Bundle bundle = new Bundle();
                bundle.putString("StoreId", storeData.getStorePK());
                bundle.putInt("StoreDistance", storeDistance);
                Log.e("StoreList", "Distance:" + storeDistance);
                bundle.putDouble("UserLat", ((HomeActivity) context).numUserLng);
                activity.startActivity(new Intent(context, StoreDetailActivity.class).putExtras(bundle));
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrStoreData.size();
    }

    //todo
    //檔名：api_107.php 功能：將店家加入/移除我的最愛

    private boolean isAddSuccess;

    private boolean apiAddRemoveStoreBookMark(String strStorePk, final ImageView ivMyFavoStore) {
        Log.e("StoreListAdapter", "apiAddRemoveStoreBookMark: " + strStorePk);
        progressBarCallBack.showProgressBar();
        String strToken = Hawk.get(Constants.USER_ACCTOKEN, "");
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken, strTimeStamp);
        Call<ResAddRemoveStoreBookMark> getStoreMoreArticles =
                ApiBase.instance().create(StoreApi.class).
                        postAddRemoveStoreBookMark(
                                strToken,
                                strStorePk,
                                strKeyStr,
                                strTimeStamp);


        getStoreMoreArticles.enqueue(new Callback<ResAddRemoveStoreBookMark>() {
            @Override
            public void onResponse(Call<ResAddRemoveStoreBookMark> call, Response<ResAddRemoveStoreBookMark> response) {
                String strApiRtnCode = response.body().getCode();
                if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {
                    ResAddRemoveStoreBookMark.ReturnData returnData = response.body().getRetnObject();
                    int isAddRemove = returnData.getStoreLike();
                    String isSuccess = "";
                    if (isAddRemove == 0) {
                        isAddSuccess = false;
                        isSuccess = "移除成功";
                        ivMyFavoStore.setImageResource(R.drawable.ico_base_heart_o);
                    } else {
                        isAddSuccess = true;
                        isSuccess = "加入成功";
                        ivMyFavoStore.setImageResource(R.drawable.ico_base_heart);
                    }
                    Toast.makeText(context, isSuccess, Toast.LENGTH_SHORT).show();
//                    ToastUtil.showToastMsg("加入成功");
                } else {
                    apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                    Log.e("StoreListAdapter", "apiAddRemoveStoreBookMark: " + response.body().getCode() + "-" + response.body().getMessage());
                }
            }

            @Override
            public void onFailure(Call<ResAddRemoveStoreBookMark> call, Throwable t) {
                Log.e("StoreListAdapter", t.toString());
            }
        });
        progressBarCallBack.hideProgressBar();
        return isAddSuccess;
    }
}
