package gameball.com.tw.onecupcafe.utils;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import gameball.com.tw.onecupcafe.App;
import gameball.com.tw.onecupcafe.R;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class IntentActionUtil {

    public static void phoneCall(String strPhoneNum) {
        Intent intentDial = new Intent("android.intent.action.CALL", Uri.parse("tel:" + strPhoneNum));
        intentDial.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        App.getInstance().startActivity(intentDial);
    }

    public static void facebookFansPage(String strFbFansId, String strFacebookUrl) {
        String strFacebookPageURL = "";
        try {
            boolean isFacebookEnabled = App.getInstance().getPackageManager().getApplicationInfo("com.facebook.katana", 0).enabled;
            if (isFacebookEnabled) {
                strFacebookPageURL = "fb://page/" + strFbFansId;

            } else {
                strFacebookPageURL = strFacebookUrl;
            }
        } catch (PackageManager.NameNotFoundException e) {
            strFacebookPageURL = strFacebookUrl;
        }

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(strFacebookPageURL));
        App.getInstance().startActivity(intent);
    }

    public static void instagramPage(String strInstagramId) {
        Uri uri = Uri.parse("http://instagram.com/_u/" + strInstagramId);
        Intent likeIng = new Intent(Intent.ACTION_VIEW, uri);

        likeIng.setPackage("com.instagram.android");

        try {
            App.getInstance().startActivity(likeIng);
        } catch (ActivityNotFoundException e) {
            App.getInstance().startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://instagram.com/" + strInstagramId)));
        }
    }

    public static void twitterPage(String strUserId){
        Intent intent = null;
        try {
            // get the Twitter app if possible
            App.getInstance().getPackageManager().getPackageInfo("com.twitter.android", 0);
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("twitter://user?user_id="+strUserId));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        } catch (Exception e) {
            // no Twitter app, revert to browser
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/"+strUserId));
        }
        App.getInstance().startActivity(intent);
    }

    public static void lineChanel(String strLineChanelId){
        boolean isLineInstaill = false;
        String PACKAGE_NAME = "jp.naver.line.android";
        PackageManager pm = App.getInstance().getPackageManager();
        List<ApplicationInfo> m_appList = pm.getInstalledApplications(0);
        for (ApplicationInfo ai : m_appList) {
            if (ai.packageName.equals(PACKAGE_NAME)) {
                isLineInstaill = true;
                break;
            }
        }

            if (isLineInstaill == true) {
                String url = "line://ti/p/"+strLineChanelId;
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                App.getInstance().startActivity(i);
            } else {
                ToastUtil.showToastMsg(App.getInstance().getString(R.string.coumser_service_noninstall_line));
            }


    }

}
