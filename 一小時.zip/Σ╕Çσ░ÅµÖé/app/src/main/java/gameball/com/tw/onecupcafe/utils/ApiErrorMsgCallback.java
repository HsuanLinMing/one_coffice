package gameball.com.tw.onecupcafe.utils;

public interface ApiErrorMsgCallback {
    void showErrorMsg(String strErrorCode);
}
