package gameball.com.tw.onecupcafe.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.constraint.Group;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.fragments.mainpage.PointCardFragment;

import gameball.com.tw.onecupcafe.items.PointCardPojo.StorePointCardList;
import gameball.com.tw.onecupcafe.utils.GlideImageUtil;
import me.zhanghai.android.materialratingbar.MaterialRatingBar;

public class PointCardAdapter extends RecyclerView.Adapter<PointCardAdapter.ViewHoler> {
    Context context;
    List list;

    public PointCardAdapter(Context context, List list) {
        this.context = context;
        this.list = list;
    }

    public interface OnItemClickListener {
        void onItemClick(View view, int position);

    }

    private OnItemClickListener onItemClickListener;

    public void setOnItemClickLitener(OnItemClickListener itemClickListener) {
        this.onItemClickListener = itemClickListener;
    }


    public class ViewHoler extends RecyclerView.ViewHolder {
        private Group groupPointCardStore,
                groupPointCardMainItem,
                groupPointCardFreeItem,
                groupPointCardGiftItem,
                groupPointCardRedeemItem;

        private TextView tvPointCardStoreName, tvPointCardProductName,tvPointCardFreeRemainingDesc;
        private MaterialRatingBar rbPointCardFreeRatingBar;
        private ImageView ivPointCardStoreMainImg,rivPointCardStoreProductImg,rivPointCardGiftOwnerImg;

        //Redeem
        private TextView tvPointCardRedeemExchangeSum, tvPointCardRedeemShareSum, tvPointCardRedeemRemainingSum;

        //gift
        private TextView tvPointCardGiftLimitTimeDesc,tvPointCardGiftExchangeDesc,tvPointCardGiftRemainingDesc;

        public ViewHoler(View v) {
            super(v);
            groupPointCardStore = v.findViewById(R.id.groupPointCardStore);
            tvPointCardStoreName = v.findViewById(R.id.tvPointCardStoreName);
            tvPointCardProductName = v.findViewById(R.id.tvPointCardProductName);

            groupPointCardMainItem = v.findViewById(R.id.groupPointCardMainItem);
            groupPointCardFreeItem = v.findViewById(R.id.groupPointCardFreeItem);
            groupPointCardGiftItem = v.findViewById(R.id.groupPointCardGiftItem);
            groupPointCardRedeemItem = v.findViewById(R.id.groupPointCardRedeemItem);
            rbPointCardFreeRatingBar = v.findViewById(R.id.rbPointCardFreeRatingBar);

            tvPointCardRedeemExchangeSum = v.findViewById(R.id.tvPointCardRedeemExchangeSum);
            tvPointCardRedeemShareSum = v.findViewById(R.id.tvPointCardRedeemShareSum);
            tvPointCardRedeemRemainingSum = v.findViewById(R.id.tvPointCardRedeemRemainingSum);

            ivPointCardStoreMainImg = v.findViewById(R.id.ivPointCardStoreMainImg);
            rivPointCardStoreProductImg = v.findViewById(R.id.rivPointCardStoreProductImg);

            rivPointCardGiftOwnerImg = v.findViewById(R.id.rivPointCardGiftOwnerImg);

            tvPointCardFreeRemainingDesc = v.findViewById(R.id.tvPointCardFreeRemainingDesc);

            tvPointCardGiftLimitTimeDesc = v.findViewById(R.id.tvPointCardGiftLimitTimeDesc);
            tvPointCardGiftExchangeDesc = v.findViewById(R.id.tvPointCardGiftExchangeDesc);
            tvPointCardGiftRemainingDesc = v.findViewById(R.id.tvPointCardGiftRemainingDesc);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHoler holder, int position) {
        if (list.get(position) instanceof StorePointCardList) {
        //店家列表
            StorePointCardList parent = (StorePointCardList) list.get(position);

            holder.groupPointCardStore.setVisibility(View.VISIBLE);
            holder.tvPointCardStoreName.setText(parent.getStoreName());
            holder.groupPointCardMainItem.setVisibility(View.GONE);
            holder.groupPointCardFreeItem.setVisibility(View.GONE);
            holder.groupPointCardGiftItem.setVisibility(View.GONE);
            holder.groupPointCardRedeemItem.setVisibility(View.GONE);

            new GlideImageUtil(context,
                    parent.getStorePhoto1(),
                    holder.ivPointCardStoreMainImg,
                    R.drawable.img_store_sml_default).LoadImageWithGlide();
        } else {
        //店家的集點列表
            StorePointCardList.StoreOrder child = (StorePointCardList.StoreOrder) list.get(position);

            holder.groupPointCardStore.setVisibility(View.GONE);
            holder.groupPointCardMainItem.setVisibility(View.VISIBLE);
            holder.groupPointCardFreeItem.setVisibility(View.GONE);
            holder.groupPointCardGiftItem.setVisibility(View.GONE);
            holder.groupPointCardRedeemItem.setVisibility(View.GONE);

            new GlideImageUtil(context,
                    child.getProdImage1(),
                    holder.rivPointCardStoreProductImg,
                    R.drawable.img_product_sml_default).LoadImageWithGlide();

            holder.tvPointCardProductName.setText(child.getProdTitle());

            switch (PointCardFragment.strPointCardTag) {
                //使用者購買寄杯資料
                case "redeem":
                    holder.groupPointCardRedeemItem.setVisibility(View.VISIBLE);
                    holder.tvPointCardRedeemExchangeSum.setText(child.getRedeemQty());
                    holder.tvPointCardRedeemShareSum.setText(child.getSharedQty());
                    holder.tvPointCardRedeemRemainingSum.setText(child.getRemianingQty());
                    break;
                //店家免費寄杯資料
                    case "free":
                    holder.groupPointCardFreeItem.setVisibility(View.VISIBLE);
                    holder.tvPointCardFreeRemainingDesc.setText(child.remianingQty);
                    holder.rbPointCardFreeRatingBar.setProgress(7);
                    holder.rbPointCardFreeRatingBar.setEnabled(false);
                    break;
                //使用者禮物寄杯資料
                case "gift":
                    holder.groupPointCardGiftItem.setVisibility(View.VISIBLE);
                    new GlideImageUtil(context,
                            child.getFriendImage()
                            ,holder.rivPointCardGiftOwnerImg
                            ,R.drawable.img_friend_default).LoadImageWithGlide();

                    holder.tvPointCardGiftLimitTimeDesc.setText(child.getExpireDate());
                    holder.tvPointCardGiftExchangeDesc.setText(child.getRedeemQty());
                    holder.tvPointCardGiftRemainingDesc.setText(child.getRemianingQty());

                    break;
                default:
                    break;
            }

//            StorePointCardList.StoreOrder child = (StorePointCardList.StoreOrder) list.get(position);
//            holder.child_name.setText(child.getStrChindId());
        }

        if (onItemClickListener != null) {
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos = holder.getLayoutPosition();
                    onItemClickListener.onItemClick(holder.itemView, pos);
                }
            });
        }
    }

    @NonNull
    @Override
    public ViewHoler onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View rootView = LayoutInflater.from(context).inflate(R.layout.item_pointcard_expan, null, false);
        RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rootView.setLayoutParams(lp);
        return new ViewHoler(rootView);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    //展開子類別
    public void addAllChild(List<?> lists, int position) {
        list.addAll(position, lists);
        notifyItemRangeInserted(position, lists.size());
    }

    public void deleteAllChild(int position, int itemnum) {
        for (int i = 0; i < itemnum; i++) {
            list.remove(position);
        }
        notifyItemRangeRemoved(position, itemnum);
    }


}
