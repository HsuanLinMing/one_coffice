package gameball.com.tw.onecupcafe.utils;

public interface FragmentSwitchCallback {
    void setTargetFragment(String strTargetFragment);
}
