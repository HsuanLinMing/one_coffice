package gameball.com.tw.onecupcafe;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public class ActivityManagerDetacher implements Application.ActivityLifecycleCallbacks {
    @Override
    public void onActivityDestroyed(Activity activity) {
        try {
            detachActivityFromActivityManager(activity);
        } catch (NoSuchFieldException e) {
//            Assert.fail("Samsung activity leak fix has to be removed as ActivityManager field has changed", e);
        } catch (IllegalAccessException e) {
//            Assert.fail("Samsung activity leak fix did not work, probably activity has leaked", e);
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Build.MANUFACTURER.equals("samsung")) {
                Object systemService = App.getInstance().getSystemService(Class.forName("com.samsung.android.content.clipboard.SemClipboardManager"));
                Field mContext = systemService.getClass().getDeclaredField("mContext");
                mContext.setAccessible(true);
                mContext.set(systemService, null);
            }
        } catch (ClassNotFoundException | NoSuchFieldException | IllegalAccessException e) { //ignored }
        }
    }

    /**
     * On Samsung, Activity reference is stored into static mContext field of ActivityManager
     * resulting in activity leak.
     */
    private void detachActivityFromActivityManager(Activity activity) throws
            NoSuchFieldException, IllegalAccessException {
        ActivityManager activityManager = (ActivityManager) activity.
                getSystemService(Context.ACTIVITY_SERVICE);

        Field contextField = activityManager.getClass().getDeclaredField("mContext");

        int modifiers = contextField.getModifiers();
        if ((modifiers | Modifier.STATIC) == modifiers) {
            // field is static on Samsung devices only
            contextField.setAccessible(true);

            if (contextField.get(null) == activity) {
                contextField.set(null, null);
            }
        }
    }

    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
    }

    @Override
    public void onActivityStarted(Activity activity) {
    }

    @Override
    public void onActivityResumed(Activity activity) {
    }

    @Override
    public void onActivityPaused(Activity activity) {
    }

    @Override
    public void onActivityStopped(Activity activity) {
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
    }
}