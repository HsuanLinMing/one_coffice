package gameball.com.tw.onecupcafe.activities;

import com.journeyapps.barcodescanner.CaptureActivity;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;

import gameball.com.tw.onecupcafe.R;

    //Qr Code 掃描客製畫面

public class ScannerActivity extends CaptureActivity {
    @Override
    protected DecoratedBarcodeView initializeContent() {
        setContentView(R.layout.activity_scanner);
        return (DecoratedBarcodeView)findViewById(R.id.zxing_barcode_scanner);
    }
}
