package gameball.com.tw.onecupcafe.items.NotificationPojo;

import java.io.Serializable;
import java.util.Date;

public class ResGetAllNotifications implements Serializable {
    String code;
    String message;
    ReturnData retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ReturnData getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(ReturnData retnObject) {
        this.retnObject = retnObject;
    }

    class ReturnData{
        String notifyAccess;
        NotifyData notifyData;

        public String getNotifyAccess() {
            return notifyAccess;
        }

        public void setNotifyAccess(String notifyAccess) {
            this.notifyAccess = notifyAccess;
        }

        public NotifyData getNotifyData() {
            return notifyData;
        }

        public void setNotifyData(NotifyData notifyData) {
            this.notifyData = notifyData;
        }

        class NotifyData{
            String notifyID;
            String subject;
            String message;
            int read;
            String time;
            String url_schema;

            public String getNotifyID() {
                return notifyID;
            }

            public void setNotifyID(String notifyID) {
                this.notifyID = notifyID;
            }

            public String getSubject() {
                return subject;
            }

            public void setSubject(String subject) {
                this.subject = subject;
            }

            public String getMessage() {
                return message;
            }

            public void setMessage(String message) {
                this.message = message;
            }

            public int getRead() {
                return read;
            }

            public void setRead(int read) {
                this.read = read;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getUrl_schema() {
                return url_schema;
            }

            public void setUrl_schema(String url_schema) {
                this.url_schema = url_schema;
            }
        }
    }
}
