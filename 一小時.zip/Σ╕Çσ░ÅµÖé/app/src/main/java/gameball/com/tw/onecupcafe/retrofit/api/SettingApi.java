package gameball.com.tw.onecupcafe.retrofit.api;

import java.util.Map;

import gameball.com.tw.onecupcafe.items.SettingPojo.ResGetServiceContentAndAppVersion;
import gameball.com.tw.onecupcafe.items.SettingPojo.ResGetUserOrderHistory;
import gameball.com.tw.onecupcafe.items.SettingPojo.ResUpdateUserInfo;
import gameball.com.tw.onecupcafe.items.SettingPojo.UserInfoPojo;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.PartMap;
import retrofit2.http.Query;

/**
 * Created by sofasoso on 2018/3/31.
 */

public interface SettingApi {

    //取得使用者歷史訂單詳細資料。（咖啡旅程）
    //1. token: string, api_002回傳的accToken。
    //2. pageSize: int, 每頁回傳資料筆數，預設:30. 傳0則回傳所有資料
    //3. pageNo: int, 第幾頁資料從1開始計算
    //4. keyStr: string, 介面存取驗證字串md5(salt + accToken + timestamp)
    //5. timestamp: long, 呼叫API當下 timestamp
    @POST("api_501.php")
    Call<ResGetUserOrderHistory> postGetUserOrderHistory(
            @Query("token") String token,
            @Query("pageSize") String pageSize,
            @Query("pageNo") String pageNo,
            @Query("timestamp") String timestamp,
            @Query("keyStr") String keyStr
    );

    //取得服務說明以及版本編號資料
    //1. token: string, api_002回傳的accToken。
    //2. keyStr: string, 介面存取驗證字串md5(salt + accToken + timestamp)
    //3. timestamp: long, 呼叫API當下 timestamp
    @POST("api_502.php")
    Call<ResGetServiceContentAndAppVersion> postGetServiceContentAndAppVersion(
            @Query("token") String token,
            @Query("type") String type,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    //更新使用者基本資料
    //1. token: string, api_002回傳的accToken。
    //2. userEmail: string, 已經設定備用email。(暫時不給改)
    //3. nickName: string, 暱稱。
    //4. photoBase64: string, 照片內容(Base64)。
    //5. phone: string, 手機號碼。(暫時不給改)
    //6. keyStr: string, 介面存取驗證字串md5(salt + accToken + timestamp)
    //7. timestamp: long, 呼叫API當下 timestamp

    @Multipart
    @POST("api_503.php")
    Call<ResUpdateUserInfo> postUpdateUserInfo(
            @Query("token") String token,
            @Query("userEmail") String userEmail,
            @Query("nickName") String nickName,
            @Query("phone") String phone,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp,
            @Part MultipartBody.Part photo
            );

//    @POST("api_503.php")
//    Call<ResUpdateUserInfo> postUpdateUserInfo(
//         @Body RequestBody body
//    );
}
