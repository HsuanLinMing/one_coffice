package gameball.com.tw.onecupcafe.utils;

import android.widget.Toast;

import gameball.com.tw.onecupcafe.App;

public class ToastUtil {
    public static void showToastMsg(String strMsg) {
        Toast.makeText(App.getInstance(), strMsg, Toast.LENGTH_SHORT).show();
    }
}
