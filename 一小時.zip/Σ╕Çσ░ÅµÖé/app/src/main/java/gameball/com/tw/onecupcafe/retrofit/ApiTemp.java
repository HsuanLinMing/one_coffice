package gameball.com.tw.onecupcafe.retrofit;

import android.util.Log;

import com.orhanobut.hawk.Hawk;

import org.json.JSONObject;

import java.util.LinkedHashMap;

import gameball.com.tw.onecupcafe.adapters.StoreListAdatper;
import gameball.com.tw.onecupcafe.items.NotificationPojo.ResCleanAllNotifications;
import gameball.com.tw.onecupcafe.items.NotificationPojo.ResGetAllNotifications;
import gameball.com.tw.onecupcafe.items.NotificationPojo.ResSetAllNotificationsRead;
import gameball.com.tw.onecupcafe.items.NotificationPojo.ResSetSingleNotificationRead;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResExchangeOrderCancel;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResExchangeOrderGift;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResExchangeOrderRedeem;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResExchangeOrderRefund;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResExchangeOrderRefundCancel;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResGetAllPointCardList;
import gameball.com.tw.onecupcafe.items.SettingPojo.ResGetServiceContentAndAppVersion;
import gameball.com.tw.onecupcafe.items.SettingPojo.ResGetUserOrderHistory;
import gameball.com.tw.onecupcafe.items.SettingPojo.ResUpdateUserInfo;
import gameball.com.tw.onecupcafe.items.StorePojo.ResAddRemoveStoreBookMark;
import gameball.com.tw.onecupcafe.items.StorePojo.ResGetStoreDetail;
import gameball.com.tw.onecupcafe.items.StorePojo.ResGetStoreList;
import gameball.com.tw.onecupcafe.items.StorePojo.ResGetStoreMoreActivities;
import gameball.com.tw.onecupcafe.items.StorePojo.ResGetStoreMoreArticles;
import gameball.com.tw.onecupcafe.items.StorePojo.ResGetStoreProductCancel;
import gameball.com.tw.onecupcafe.items.StorePojo.ResGetStoreProductConfirm;
import gameball.com.tw.onecupcafe.items.StorePojo.StoreData;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResCleanMainBubble;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResGetUserInfo;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResUserCertified;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResUserEmailBind;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResUserFBLogin;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResUserInputInfo;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResUserTokenRenew;
import gameball.com.tw.onecupcafe.retrofit.api.NotificationApi;
import gameball.com.tw.onecupcafe.retrofit.api.PointCardApi;
import gameball.com.tw.onecupcafe.retrofit.api.SettingApi;
import gameball.com.tw.onecupcafe.retrofit.api.StoreApi;
import gameball.com.tw.onecupcafe.retrofit.api.UserSignInSignUpApi;
import gameball.com.tw.onecupcafe.utils.CalculateStoreDistance;
import gameball.com.tw.onecupcafe.utils.Constants;
import gameball.com.tw.onecupcafe.utils.ToastUtil;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ApiTemp {
    public static final String TAG = "TEST";

    //檔名：api_001.php
    private void apiSendSMS(String strCountryCode , String strLang , String strTimeZone,String strMetohd,
                            String strPhone ) {
        Call<ResUserInputInfo> getPhoneVerify =
                ApiBase.instance().
                        create(UserSignInSignUpApi.class).
                        postUserInputInfo("886", "zh-TW", "+8"
                                , "sms", "921961748", "1524639397",
                                "7f8484fefdda7c5bb1f753ef8bc5d4eb");
        getPhoneVerify.enqueue(new Callback<ResUserInputInfo>() {
            @Override
            public void onResponse(Call<ResUserInputInfo> call, Response<ResUserInputInfo> response) {
            }

            @Override
            public void onFailure(Call<ResUserInputInfo> call, Throwable t) {

            }
        });
    }

    //檔名：api_002.php
    private void apiCertifiedSMS(String strToken , String strLang , String strVerifyCode , String strSenderId , String strSenderOS) {
        Call<ResUserCertified> getSmsCertified =
                ApiBase.instance().
                        create(UserSignInSignUpApi.class).postUserCertified("testregtoken", "zh-TW",
                        "+8", "1000", "testid", "ios",
                        "7972a7c7711abb9325af403b1c9a92f3", "1524639397");

        getSmsCertified.enqueue(new Callback<ResUserCertified>() {
            @Override
            public void onResponse(Call<ResUserCertified> call, Response<ResUserCertified> response) {

                if (!response.body().getCode().equals("000")) {
                    ToastUtil.showToastMsg(response.body().getMessage());
                } else {
                }
            }

            @Override
            public void onFailure(Call<ResUserCertified> call, Throwable t) {

            }
        });
    }

    //檔名：api_003.php
    private void apiBindEmail(String strEmail) {
        Call<ResUserEmailBind> getBindEmail =
                ApiBase.instance().
                        create(UserSignInSignUpApi.class).postUserEmailBind("testregtoken",
                        "test@gameball.com.tw", "7972a7c7711abb9325af403b1c9a92f3", "1524639397");

        getBindEmail.enqueue(new Callback<ResUserEmailBind>() {
            @Override
            public void onResponse(Call<ResUserEmailBind> call, Response<ResUserEmailBind> response) {

                if (!response.body().getCode().equals("000")) {
                } else {

                }
            }

            @Override
            public void onFailure(Call<ResUserEmailBind> call, Throwable t) {

            }
        });
    }

    //todo
    //檔名：api_004.php 功能：第三方註冊/登入
    private void apiUserFBLogin(final String strEmail, final long numId, String strToken) {
//        Call<ResUserFBLogin> getSmsCertified =
//                ApiBase.instance().
//                        create(UserSignInSignUpApi.class).postUserFBLogin(
//                        "FB", "1409988776633",
//                        "zh-TW", "+8", "test@gameball.com.tw",
//                        "886", "921961748", "test01", "ios",
//                        "86e505aa91f0cb2af0b704bea7684b95", "1524639397"
//
//                );
//
//        getSmsCertified.enqueue(new Callback<ResUserFBLogin>() {
//            @Override
//            public void onResponse(Call<ResUserFBLogin> call, Response<ResUserFBLogin> response) {
//                try {
//                    Log.e(TAG, "Success:" + response.body().getMessage() + ":" + response.body().getCode());
//
//                    if (response.body().getCode().trim().equals("000")) {
//
//
//                    } else {
//                        ToastUtil.showToastMsg(response.body().getMessage().toString());
//                    }
//
//                } catch (Exception e) {
//                    Log.e(TAG, "ResExc:" + e.toString());
//
//                }
//
//            }
//
//            @Override
//            public void onFailure(Call<ResUserFBLogin> call, Throwable t) {
//                Log.e(TAG, "Error:" + t.toString());
//            }
//        });
    }

    //todo
    //檔名：api_005.php 功能：更新會員Token
    private void apiTokenRenew() {
        Call<ResUserTokenRenew> getTokenRenew =
                ApiBase.instance().
                        create(UserSignInSignUpApi.class).postUserTokenRenew("testtoken123", "", "",
                        "9b99da3758eda01f19a29fc2a2f4680a", "1524639397", "1.0", "ios", "test001");

        getTokenRenew.enqueue(new Callback<ResUserTokenRenew>() {
            @Override
            public void onResponse(Call<ResUserTokenRenew> call, Response<ResUserTokenRenew> response) {

                if (!response.body().getCode().equals("000")) {
                } else {

                }
            }

            @Override
            public void onFailure(Call<ResUserTokenRenew> call, Throwable t) {

            }
        });
    }

    //檔名：api_006.php 功能：消除主選單泡泡提示
    private void apiCleanMainBubble() {
        Call<ResCleanMainBubble> getCleanMainBubble =
                ApiBase.instance().
                        create(UserSignInSignUpApi.class).postCleanMainBubble("testtoken123", "storeList",
                        "9b99da3758eda01f19a29fc2a2f4680a", "1524639397");

        getCleanMainBubble.enqueue(new Callback<ResCleanMainBubble>() {
            @Override
            public void onResponse(Call<ResCleanMainBubble> call, Response<ResCleanMainBubble> response) {

                if (!response.body().getCode().equals("000")) {
                } else {

                }
            }

            @Override
            public void onFailure(Call<ResCleanMainBubble> call, Throwable t) {

            }
        });
    }

    //檔名：api_007.php 功能：取得會員資料
    private void apiGetUserInfo() {
        Call<ResGetUserInfo> getGetUserInfo =
                ApiBase.instance().
                        create(UserSignInSignUpApi.class).postGetUserInfo("testtoken123", "9b99da3758eda01f19a29fc2a2f4680a", "1524639397");

        getGetUserInfo.enqueue(new Callback<ResGetUserInfo>() {
            @Override
            public void onResponse(Call<ResGetUserInfo> call, Response<ResGetUserInfo> response) {

                if (!response.body().getCode().equals("000")) {
                } else {

                }
            }

            @Override
            public void onFailure(Call<ResGetUserInfo> call, Throwable t) {

            }
        });
    }


    //檔名：api_101.php 功能：取得所有店家列表資料
    private void apiStoreList() {
//        Call<ResGetStoreList> getStoreList = ApiBase.instance().create(StoreApi.class).postGetStoreList("testtoken123", "9b99da3758eda01f19a29fc2a2f4680a", "1524639397");
//        getStoreList.enqueue(new Callback<ResGetStoreList>() {
//            @Override
//            public void onResponse(Call<ResGetStoreList> call, Response<ResGetStoreList> response) {
//
//            }
//
//            @Override
//            public void onFailure(Call<ResGetStoreList> call, Throwable t) {
//            }
//        });
    }

    //檔名：api_102.php 功能：取得單一店家詳細資料
    private void apiStoreDetail() {
//        Call<ResGetStoreDetail> getStoreDetail =
//                ApiBase.instance().create(StoreApi.class).postGetStoreDetail("testtoken123","1","9b99da3758eda01f19a29fc2a2f4680a","1524639397");
//        getStoreDetail.enqueue(new Callback<ResGetStoreDetail>() {
//            @Override
//            public void onResponse(Call<ResGetStoreDetail> call, Response<ResGetStoreDetail> response) {
//
//            }
//
//            @Override
//            public void onFailure(Call<ResGetStoreDetail> call, Throwable t) {
//            }
//        });
    }

    //檔名：api_103.php 功能：取得單一店家更多活動
    private void apiStoreMoreActivities() {
        Call<ResGetStoreMoreActivities> getStoreMoreActivities =
                ApiBase.instance().create(StoreApi.class).postGetStoreMoreActivities("testtoken123","1",
                        "1524639397","9b99da3758eda01f19a29fc2a2f4680a");

        getStoreMoreActivities.enqueue(new Callback<ResGetStoreMoreActivities>() {
            @Override
            public void onResponse(Call<ResGetStoreMoreActivities> call, Response<ResGetStoreMoreActivities> response) {

            }

            @Override
            public void onFailure(Call<ResGetStoreMoreActivities> call, Throwable t) {
            }
        });
    }

    //檔名：api_104.php 功能：取得單一店家更多文章資料
    private void apiGetStoreMoreArticles() {
        Call<ResGetStoreMoreArticles> getStoreMoreArticles =
                ApiBase.instance().create(StoreApi.class).postGetStoreMoreArticles("testtoken123","1"
                        ,"9b99da3758eda01f19a29fc2a2f4680a","1524639397");


        getStoreMoreArticles.enqueue(new Callback<ResGetStoreMoreArticles>() {
            @Override
            public void onResponse(Call<ResGetStoreMoreArticles> call, Response<ResGetStoreMoreArticles> response) {

            }

            @Override
            public void onFailure(Call<ResGetStoreMoreArticles> call, Throwable t) {
            }
        });
    }

    //檔名：api_105.php 功能：提出商品寄杯需求(申請付款QRcode)
    private void apiGetStoreProductConfirm() {
        Call<ResGetStoreProductConfirm> getStoreMoreArticles =
                ApiBase.instance().create(StoreApi.class).postGetStoreProductConfirm("testtoken123","P0012A221002",
                        1,"319dc375b549b3a14c52abbdfe2ac023","1524639397");


        getStoreMoreArticles.enqueue(new Callback<ResGetStoreProductConfirm>() {
            @Override
            public void onResponse(Call<ResGetStoreProductConfirm> call, Response<ResGetStoreProductConfirm> response) {

            }

            @Override
            public void onFailure(Call<ResGetStoreProductConfirm> call, Throwable t) {
            }
        });
    }

    //檔名：api_106.php 功能：取消商品寄杯需求(取消付款QRcode)
    private void apiGetStoreProductCancel() {
//        Call<ResGetStoreProductCancel> getStoreMoreArticles =
//                ApiBase.instance().create(StoreApi.class).postGetStoreProductCancel("testtoken123","A8861804007388",
//                        1,"267ed5cb5d332f46cfbb8ee1c122fb13","1524639397");
//
//
//        getStoreMoreArticles.enqueue(new Callback<ResGetStoreProductCancel>() {
//            @Override
//            public void onResponse(Call<ResGetStoreProductCancel> call, Response<ResGetStoreProductCancel> response) {
//
//            }
//
//            @Override
//            public void onFailure(Call<ResGetStoreProductCancel> call, Throwable t) {
//            }
//        });
    }

    //檔名：api_107.php 功能：將店家加入/移除我的最愛
    private void apiAddRemoveStoreBookMark() {
        Call<ResAddRemoveStoreBookMark> getStoreMoreArticles =
                ApiBase.instance().create(StoreApi.class).postAddRemoveStoreBookMark("testtoken123","011",
                        "1524639397","9b99da3758eda01f19a29fc2a2f4680a");


        getStoreMoreArticles.enqueue(new Callback<ResAddRemoveStoreBookMark>() {
            @Override
            public void onResponse(Call<ResAddRemoveStoreBookMark> call, Response<ResAddRemoveStoreBookMark> response) {

            }

            @Override
            public void onFailure(Call<ResAddRemoveStoreBookMark> call, Throwable t) {
            }
        });
    }

    //檔名：api_201.php 功能：取得使用者寄杯資料(訂單列表)
    private void apiGetAllPointCardList(){
        Call<ResGetAllPointCardList> getStoreMoreArticles =
                ApiBase.instance().create(PointCardApi.class).postGetAllPointCardList("testtoken123","9b99da3758eda01f19a29fc2a2f4680a"
                        ,"1524639397","order");


        getStoreMoreArticles.enqueue(new Callback<ResGetAllPointCardList>() {
            @Override
            public void onResponse(Call<ResGetAllPointCardList> call, Response<ResGetAllPointCardList> response) {

            }

            @Override
            public void onFailure(Call<ResGetAllPointCardList> call, Throwable t) {
            }
        });
    }

    //檔名：api_202.php 功能：提出寄杯商品兌換需求(申請兌換QRcode)
    private void apiExchangeOrderRedeem(){
        Call<ResExchangeOrderRedeem> getExchangeOrderRedeem =
                ApiBase.instance().create(PointCardApi.class).postExchangeOrderRedeem("testtoken123","F8861804000010"
                        ,1,"5b99cb79eb766c8f523756804737ed3d","1524639397");


        getExchangeOrderRedeem.enqueue(new Callback<ResExchangeOrderRedeem>() {
            @Override
            public void onResponse(Call<ResExchangeOrderRedeem> call, Response<ResExchangeOrderRedeem> response) {

            }

            @Override
            public void onFailure(Call<ResExchangeOrderRedeem> call, Throwable t) {
            }
        });
    }

    //檔名：api_203.php 功能：取消商品兌換需求(取消兌換QRcode)
    private void apiExchangeOrderCancel(){
//        Call<ResExchangeOrderCancel> getExchangeOrderCancel =
//                ApiBase.instance().create(PointCardApi.class).postExchangeOrderCancel("testtoken123",
//                        "116867501",1,"37330081c0b1bebdd1d523e55517f6ae","1524639397");
//
//
//        getExchangeOrderCancel.enqueue(new Callback<ResExchangeOrderCancel>() {
//            @Override
//            public void onResponse(Call<ResExchangeOrderCancel> call, Response<ResExchangeOrderCancel> response) {
//
//            }
//
//            @Override
//            public void onFailure(Call<ResExchangeOrderCancel> call, Throwable t) {
//            }
//        });
    }

    //檔名：api_204.php 功能：贈送寄杯商品（分享字串至其他App）
    private void apiExchangeOrderGift(){
        Call<ResExchangeOrderGift> getExchangeOrderGift =
                ApiBase.instance().create(PointCardApi.class).postExchangeOrderGift("testtoken123","116867501",
                        1,"37330081c0b1bebdd1d523e55517f6ae","1524639397");
        getExchangeOrderGift.enqueue(new Callback<ResExchangeOrderGift>() {
            @Override
            public void onResponse(Call<ResExchangeOrderGift> call, Response<ResExchangeOrderGift> response) {

            }

            @Override
            public void onFailure(Call<ResExchangeOrderGift> call, Throwable t) {
            }
        });
    }

    //檔名：api_205.php 功能：寄杯商品退貨（申請退貨QRcode）
    private void apiExchangeOrderRefund(){
        Call<ResExchangeOrderRefund> getExchangeOrderRefund =
                ApiBase.instance().create(PointCardApi.class).postExchangeOrderRefund("testtoken123","116867501",
                        "37330081c0b1bebdd1d523e55517f6ae","1524639397");
        getExchangeOrderRefund.enqueue(new Callback<ResExchangeOrderRefund>() {
            @Override
            public void onResponse(Call<ResExchangeOrderRefund> call, Response<ResExchangeOrderRefund> response) {

            }

            @Override
            public void onFailure(Call<ResExchangeOrderRefund> call, Throwable t) {
            }
        });
    }

    //檔名：api_206.php 功能：取消商品退貨（取消退貨QRcode）
    private void apiExchangeOrderRefundCancel(){
        Call<ResExchangeOrderRefundCancel> getExchangeOrderRefundCancel =
                ApiBase.instance().create(PointCardApi.class).postExchangeOrderRefundCancel(
                        "","","","");
        getExchangeOrderRefundCancel.enqueue(new Callback<ResExchangeOrderRefundCancel>() {
            @Override
            public void onResponse(Call<ResExchangeOrderRefundCancel> call, Response<ResExchangeOrderRefundCancel> response) {

            }

            @Override
            public void onFailure(Call<ResExchangeOrderRefundCancel> call, Throwable t) {
            }
        });
    }

    //檔名：api_401.php 功能：取得所有訊息中心的資訊
    private void apiGetAllNotifications(){
        Call<ResGetAllNotifications> getGetAllNotifications =
                ApiBase.instance().create(NotificationApi.class).postGetAllNotifications(
                        "testtoken123","9b99da3758eda01f19a29fc2a2f4680a","1524639397"
                );
        getGetAllNotifications.enqueue(new Callback<ResGetAllNotifications>() {
            @Override
            public void onResponse(Call<ResGetAllNotifications> call, Response<ResGetAllNotifications> response) {

            }

            @Override
            public void onFailure(Call<ResGetAllNotifications> call, Throwable t) {
            }
        });
    }

    //檔名：api_402.php 功能：清除會員所有的推播訊息
    private void apiCleanAllNotifications(){
        Call<ResCleanAllNotifications> getCleanAllNotifications =
                ApiBase.instance().create(NotificationApi.class).postCleanAllNotifications(
                        "testtoken123","9b99da3758eda01f19a29fc2a2f4680a","1524639397"
                );
        getCleanAllNotifications.enqueue(new Callback<ResCleanAllNotifications>() {
            @Override
            public void onResponse(Call<ResCleanAllNotifications> call, Response<ResCleanAllNotifications> response) {

            }

            @Override
            public void onFailure(Call<ResCleanAllNotifications> call, Throwable t) {
            }
        });
    }

    //檔名：api_403.php 功能：將會員所有推播設定為已讀
    private void apiSetAllNotificationsRead(){
        Call<ResSetAllNotificationsRead> getCleanAllNotifications =
                ApiBase.instance().create(NotificationApi.class).postSetAllNotificationsRead(
                        "testtoken123","9b99da3758eda01f19a29fc2a2f4680a","1524639397"
                );
        getCleanAllNotifications.enqueue(new Callback<ResSetAllNotificationsRead>() {
            @Override
            public void onResponse(Call<ResSetAllNotificationsRead> call, Response<ResSetAllNotificationsRead> response) {

            }

            @Override
            public void onFailure(Call<ResSetAllNotificationsRead> call, Throwable t) {
            }
        });
    }

    //檔名：api_404.php 功能：將會員單一指定推播設定為已讀
    private void apiSetSingleNotificationRead(){
        Call<ResSetSingleNotificationRead> getSetSingleNotificationRead =
                ApiBase.instance().create(NotificationApi.class).postSetSingleNotificationRead("testtoken123"
                ,"1","afe64a9dc21da4bac6f49e5e8ac12ad6","1524639397");
        getSetSingleNotificationRead.enqueue(new Callback<ResSetSingleNotificationRead>() {
            @Override
            public void onResponse(Call<ResSetSingleNotificationRead> call, Response<ResSetSingleNotificationRead> response) {

            }

            @Override
            public void onFailure(Call<ResSetSingleNotificationRead> call, Throwable t) {
            }
        });
    }

    //檔名：api_501.php 功能：寄杯歷史記錄
    private void apiGetUserOrderHistory(){
//        Call<ResGetUserOrderHistory> getSetSingleNotificationRead =
//                ApiBase.instance().create(SettingApi.class).postGetUserOrderHistory(
//                        "testtoken123","order","1524639397","9b99da3758eda01f19a29fc2a2f4680a"
//                );
//        getSetSingleNotificationRead.enqueue(new Callback<ResGetUserOrderHistory>() {
//            @Override
//            public void onResponse(Call<ResGetUserOrderHistory> call, Response<ResGetUserOrderHistory> response) {
//
//            }
//
//            @Override
//            public void onFailure(Call<ResGetUserOrderHistory> call, Throwable t) {
//            }
//        });
    }

    //檔名：api_502.php 功能：條款頁
    private void apiGetServiceContentAndAppVersion(){
        Call<ResGetServiceContentAndAppVersion> getGetServiceContentAndAppVersion =
                ApiBase.instance().create(SettingApi.class).postGetServiceContentAndAppVersion(
                        "testtoken123","order","9b99da3758eda01f19a29fc2a2f4680a","1524639397"
                );
        getGetServiceContentAndAppVersion.enqueue(new Callback<ResGetServiceContentAndAppVersion>() {
            @Override
            public void onResponse(Call<ResGetServiceContentAndAppVersion> call, Response<ResGetServiceContentAndAppVersion> response) {

            }

            @Override
            public void onFailure(Call<ResGetServiceContentAndAppVersion> call, Throwable t) {
            }
        });
    }

    //檔名：api_503.php 功能：更新會員更新
    private void apiUpdateUserInfo(){
//        Call<ResUpdateUserInfo> getUpdateUserInfo =
//                ApiBase.instance().create(SettingApi.class).postUpdateUserInfo(
//                        "","","","","","",""
////                        "testtoken123","aaa","9b99da3758eda01f19a29fc2a2f4680a","1524639397"
//                );
//        getUpdateUserInfo.enqueue(new Callback<ResUpdateUserInfo>() {
//            @Override
//            public void onResponse(Call<ResUpdateUserInfo> call, Response<ResUpdateUserInfo> response) {
//
//            }
//
//            @Override
//            public void onFailure(Call<ResUpdateUserInfo> call, Throwable t) {
//            }
//        });
    }
}


