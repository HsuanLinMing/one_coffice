package gameball.com.tw.onecupcafe.utils;

import android.graphics.Bitmap;

import com.google.zxing.BarcodeFormat;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class QrCodeGenUtil {

    public static Bitmap createQrCodeBitmap(String strEncodeContent) {
        Bitmap bitmap = null;
        BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
        try {
            bitmap = barcodeEncoder.encodeBitmap(strEncodeContent, BarcodeFormat.QR_CODE, 450, 450);
        } catch (Exception e) {
        }
        return bitmap;
    }
}
