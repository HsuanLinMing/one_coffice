package gameball.com.tw.onecupcafe.items.PointCardPojo;

import java.io.Serializable;

public class ResExchangeOrderCancel implements Serializable {
    String code;
    String message;
    ReturnData retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ReturnData getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(ReturnData retnObject) {
        this.retnObject = retnObject;
    }

    class ReturnData{
        String redeemID;

        public String getRedeemID() {
            return redeemID;
        }

        public void setRedeemID(String redeemID) {
            this.redeemID = redeemID;
        }
    }
}
