package gameball.com.tw.onecupcafe.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.orhanobut.hawk.Hawk;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.fragments.login.SignUpFragment;
import gameball.com.tw.onecupcafe.fragments.mainpage.SettingPageFragment;
import gameball.com.tw.onecupcafe.fragments.setting.BindEmailFragment;
import gameball.com.tw.onecupcafe.fragments.setting.OrderHistoryFragment;
import gameball.com.tw.onecupcafe.fragments.setting.ProfileFragment;
import gameball.com.tw.onecupcafe.fragments.setting.ServiceNoteFragment;
import gameball.com.tw.onecupcafe.fragments.setting.SettingSignUpFragment;
import gameball.com.tw.onecupcafe.utils.ApiErrorMsgCallback;
import gameball.com.tw.onecupcafe.utils.Constants;
import gameball.com.tw.onecupcafe.utils.ProgressBarCallBack;
import gameball.com.tw.onecupcafe.utils.ProgressBarUtil;
import me.yokeyword.fragmentation.SupportActivity;

//設定頁面

public class SettingPageActivity extends SupportActivity implements View.OnClickListener, ProgressBarCallBack,
        ApiErrorMsgCallback {

    private TextView tvSettingPagePrev, tvSettingActiviyTitle;
    public String strFromTag = "";

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        initView();
    }

    private void initView() {
        progressBar = new ProgressBarUtil(this);
        tvSettingPagePrev = (TextView) findViewById(R.id.tvSettingPagePrev);
        tvSettingActiviyTitle = (TextView) findViewById(R.id.tvSettingActiviyTitle);
        tvSettingPagePrev.setOnClickListener(this);
        initSettingFragment();
    }


    private void initSettingFragment() {
        String strSettingCategory = getIntent().getExtras().getString("ServiceCategory");
        strFromTag = getIntent().getExtras().getString("From", "");
        switch (strSettingCategory) {
            //購買紀錄
            case "OrderHistory":
                tvSettingActiviyTitle.setText(getString(R.string.setting_order_title));
                if (findFragment(OrderHistoryFragment.class) == null) {
                    loadRootFragment(R.id.flSettingPageContent, OrderHistoryFragment.newInstance());
                }
                break;
            //Privacy
            case "ServiceNote":
                tvSettingActiviyTitle.setText(getString(R.string.setting_privacy_title));
                if (findFragment(ServiceNoteFragment.class) == null) {
                    loadRootFragment(R.id.flSettingPageContent, ServiceNoteFragment.newInstance());
                }
                break;
            //使用者基本資料
            case "Profile":
                if (Hawk.get(Constants.USER_ACCTOKEN, Constants.USER_DEF_DATA).equals(Constants.USER_DEF_DATA)) {
                    showErrorAlertDialog("請先登入");
                } else {
                    tvSettingActiviyTitle.setText(getString(R.string.setting_profile_title));
                    if (findFragment(ProfileFragment.class) == null) {
                        loadRootFragment(R.id.flSettingPageContent, ProfileFragment.newInstance());
                    }
                }
                break;
            //服務中心
            case "HelpCenter":
//                tvSettingActiviyTitle.setText(getString(R.string.setting_service_title));
//                if (findFragment(OrderHistoryFragment.class) == null) {
//                    loadRootFragment(R.id.flSettingPageContent, HelpCenterFragment.newInstance());
//                }
                startActivity(new Intent(SettingPageActivity.this, HelpCenterActivity.class));
                break;
            //手機驗證
            case "PhoneCertified":
                String strToken = Hawk.get(Constants.USER_ACCTOKEN, Constants.USER_DEF_DATA);
                if (strToken.equals(Constants.USER_DEF_DATA)) {
                    tvSettingActiviyTitle.setText(R.string.sign_up_member);
                    if (findFragment(SettingPageFragment.class) == null) {
                        loadRootFragment(R.id.flSettingPageContent, SignUpFragment.newInstance());
                    }
                } else {
                    String strLoginType = Hawk.get(Constants.USER_LOGIN_TYPE, Constants.USER_DEF_DATA);
                    if (!strLoginType.equals("FB")) {
                        tvSettingActiviyTitle.setText(getString(R.string.setting_phone_title));
                        if (findFragment(SettingPageFragment.class) == null) {
                            loadRootFragment(R.id.flSettingPageContent, SettingSignUpFragment.newInstance());
                        }
                    }
                }

                break;
            //Email綁定
            case "BindEmail":
                tvSettingActiviyTitle.setText(getString(R.string.setting_mail_title));
                if (findFragment(BindEmailFragment.class) == null) {
                    loadRootFragment(R.id.flSettingPageContent, BindEmailFragment.newInstance());
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tvSettingPagePrev:
                SettingPageActivity.this.finish();
                break;
            default:
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private ProgressBarUtil progressBar;

    @Override
    public void showProgressBar() {
        progressBar.show();
    }

    @Override
    public void hideProgressBar() {
        progressBar.hide();
    }

    @Override
    public void showErrorMsg(String strErrorCode) {
//        String strErrorMsg = "";
//        switch (strErrorCode) {
//            case "101":
//                strErrorMsg = getString(R.string.error_msg_101);
//                break;
//            case "102":
//                strErrorMsg = getString(R.string.error_msg_102);
//                break;
//            case "103":
//                strErrorMsg = getString(R.string.error_msg_103);
//                break;
//            case "104":
//                strErrorMsg = getString(R.string.error_msg_104);
//                break;
//            case "105":
//                strErrorMsg = getString(R.string.error_msg_105);
//                break;
//            case "106":
//                strErrorMsg = getString(R.string.error_msg_106);
//                break;
//            case "107":
//                strErrorMsg = getString(R.string.error_msg_107);
//                break;
//            case "109":
//                strErrorMsg = getString(R.string.error_msg_109);
//                break;
//        }
        showErrorAlertDialog(strErrorCode);
    }

    private AlertDialog.Builder builder;
    private void showErrorAlertDialog(String strMsgInfo) {
        Log.e("API ERROR", "MSG:" + strMsgInfo);
        if (builder == null) {
            builder = new AlertDialog.Builder(SettingPageActivity.this);
            builder.setTitle("發生錯誤");
            builder.setMessage(strMsgInfo);
            builder.setCancelable(false);
            builder.setPositiveButton("確認", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    builder = null;
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }
}
