package gameball.com.tw.onecupcafe.items.PointCardPojo;

import java.io.Serializable;

public class ResExchangeOrderRedeem implements Serializable {
    String code;
    String message;
    ReturnData retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ReturnData getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(ReturnData retnObject) {
        this.retnObject = retnObject;
    }

    public class ReturnData{
        String redeemID;
        String transCode;
        int quantity;
        String transExpireDate;
        int transExpireSecond;

        public String getRedeemID() {
            return redeemID;
        }

        public void setRedeemID(String redeemID) {
            this.redeemID = redeemID;
        }

        public String getTransCode() {
            return transCode;
        }

        public void setTransCode(String transCode) {
            this.transCode = transCode;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }

        public String getTransExpireDate() {
            return transExpireDate;
        }

        public void setTransExpireDate(String transExpireDate) {
            this.transExpireDate = transExpireDate;
        }

        public int getTransExpireSecond() {
            return transExpireSecond;
        }

        public void setTransExpireSecond(int transExpireSecond) {
            this.transExpireSecond = transExpireSecond;
        }
    }
}
