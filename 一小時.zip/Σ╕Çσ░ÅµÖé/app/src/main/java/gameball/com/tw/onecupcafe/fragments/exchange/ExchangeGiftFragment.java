package gameball.com.tw.onecupcafe.fragments.exchange;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.eralp.circleprogressview.CircleProgressView;
import com.makeramen.roundedimageview.RoundedImageView;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.activities.ExchangeActivity;
import gameball.com.tw.onecupcafe.core.base.BaseFragment;
import gameball.com.tw.onecupcafe.utils.FragmentSwitchCallback;
import gameball.com.tw.onecupcafe.utils.GlideImageUtil;

public class ExchangeGiftFragment extends BaseFragment {


    public static ExchangeGiftFragment newInstance() {
        Bundle args = new Bundle();

        ExchangeGiftFragment fragment = new ExchangeGiftFragment();
        fragment.setArguments(args);
        return fragment;
    }

    public static final String TAG = "ExchangeGift";
    private Button btnExchangeGiftConfirm;
    private FragmentSwitchCallback callback;
    private CircleProgressView cpvExchangeGiftPercent;
    private RoundedImageView rivExchangeGiftImg;
    private TextView tvExchangeGiftExchangeDesc,tvExchangeGiftShareDesc,tvExchangeGiftRemainingDesc;
    private ExchangeActivity exchangeActivity;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_exchange_gift,container,false);
        callback = (FragmentSwitchCallback) getActivity();
        initView(view);
        return view;
    }


    private void initView(View v) {
        exchangeActivity = (ExchangeActivity)getActivity();

        btnExchangeGiftConfirm = (Button) v.findViewById(R.id.btnExchangeGiftConfirm);
        btnExchangeGiftConfirm.setOnClickListener(this);

        cpvExchangeGiftPercent = (CircleProgressView) v.findViewById(R.id.cpvExchangeGiftPercent);
        rivExchangeGiftImg = (RoundedImageView) v.findViewById(R.id.rivExchangeGiftImg);

        tvExchangeGiftExchangeDesc = (TextView) v.findViewById(R.id.tvExchangeGiftExchangeDesc);
        tvExchangeGiftShareDesc = (TextView) v.findViewById(R.id.tvExchangeGiftShareDesc);
        tvExchangeGiftRemainingDesc = (TextView) v.findViewById(R.id.tvExchangeGiftRemainingDesc);
        initDataView();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnExchangeGiftConfirm:
                callback.setTargetFragment("GiftExchange");
                break;
            default:
                break;
        }
    }

    private void initDataView(){
        new GlideImageUtil(getActivity(),
                exchangeActivity.orderData.prodImage1,
                rivExchangeGiftImg,
                R.drawable.img_product_big_default).LoadImageWithGlide();

        tvExchangeGiftExchangeDesc.setText(exchangeActivity.orderData.getRedeemQty());
        tvExchangeGiftShareDesc.setText(exchangeActivity.orderData.getSharedQty());
        tvExchangeGiftRemainingDesc.setText(exchangeActivity.orderData.getRemianingQty());

        float cpvPercent = (Integer.parseInt(exchangeActivity.orderData.getRedeemQty()) *Integer.parseInt(exchangeActivity.orderData.getTotalQty())/Integer.parseInt(exchangeActivity.orderData.getTotalQty()) );
        Log.e(TAG,"CpvPercent:"+cpvPercent+";+RedeemQty:"+exchangeActivity.orderData.getRedeemQty()+
                "TotalQty:"+Integer.parseInt(exchangeActivity.orderData.getTotalQty()));
        cpvExchangeGiftPercent.setStartAngle(270);
        cpvExchangeGiftPercent.setProgressWithAnimation(cpvPercent, 1000);
    }

}
