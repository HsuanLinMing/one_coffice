package gameball.com.tw.onecupcafe.retrofit.api;

import gameball.com.tw.onecupcafe.items.StorePojo.ResAddRemoveStoreBookMark;
import gameball.com.tw.onecupcafe.items.StorePojo.ResGetStoreDetail;
import gameball.com.tw.onecupcafe.items.StorePojo.ResGetStoreList;
import gameball.com.tw.onecupcafe.items.StorePojo.ResGetStoreMoreActivities;
import gameball.com.tw.onecupcafe.items.StorePojo.ResGetStoreMoreArticles;
import gameball.com.tw.onecupcafe.items.StorePojo.ResGetStoreProductCancel;
import gameball.com.tw.onecupcafe.items.StorePojo.ResGetStoreProductConfirm;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * Created by sofasoso on 2018/3/31.
 */

public interface StoreApi {

    //取得所有店家列表資料。
    //1. token: string, api_002回傳的accToken。
    //2. keyStr: string, 介面存取驗證字串md5(salt + accToken + timestamp)
    //3. timestamp: long, 呼叫API當下 timestamp
    @POST("api_101.php")
    Call<ResGetStoreList> postGetStoreList(
            @Query("keyStr") String keyStr,
            @Query("token") String token,
            @Query("timestamp") String timestamp,
            @Query("longitude") String longitude,
            @Query("latitude") String latitude
    );

    //取得單一店家詳細資料。
    //1. token: string, api_002回傳的accToken。
    //2. store: string, store PK值。
    //3. keyStr: string, 介面存取驗證字串md5(salt + accToken + timestamp)
    //4. timestamp: long, 呼叫API當下 timestamp
    @POST("api_102.php")
    Call<ResGetStoreDetail> postGetStoreDetail(
            @Query("token") String token,
            @Query("store") String store,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    //取得單一店家更多活動(v1無此功能)
    //1. token: string, api_002回傳的accToken。
    //2. store: string, store PK值。
    //3. keyStr: string, 介面存取驗證字串md5(salt + accToken + timestamp)
    //4. timestamp: long, 呼叫API當下 timestamp
    @POST("api_103.php")
    Call<ResGetStoreMoreActivities> postGetStoreMoreActivities(
            @Query("token") String token,
            @Query("store") String store,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    //取得單一店家更多文章資料。(第一版不做)
    //1. token: string, api_002回傳的accToken。
    //2. store: string, store PK值。
    //3. keyStr: string, 介面存取驗證字串md5(salt + accToken + timestamp)
    //4. timestamp: long, 呼叫API當下 timestamp
    @POST("api_104.php")
    Call<ResGetStoreMoreArticles> postGetStoreMoreArticles(
            @Query("token") String token,
            @Query("store") String store,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    //提出商品寄杯需求
    //1. token: string, api_002回傳的accToken。
    //2. prodID : string, 商品編號。
    //3. quantity : int, 購買份數，預設帶1
    //4. keyStr : string, 介面存取驗證字串md5(salt + accToken + prodID + quantity + timestamp)
    //5. timestamp : long, 呼叫API當下 timestamp
    @POST("api_105.php")
    Call<ResGetStoreProductConfirm> postGetStoreProductConfirm(
            @Query("token") String token,
            @Query("prodID") String prodID,
            @Query("quantity") int quantity,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    //取消商品寄杯需求
    //1. token: string, api_002回傳的accToken。
    //2. orderID: string, 訂單編號
    //3. keyStr : string, 介面存取驗證字串md5(salt + accToken + orderID + timestamp)
    //4. timestamp : long, 呼叫API當下 timestamp
    @POST("api_106.php")
    Call<ResGetStoreProductCancel> postGetStoreProductCancel(
            @Query("token") String token,
            @Query("transCode") String transCode,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    //將店家加入/移除我的最愛
    //1. token: string, api_002回傳的accToken。
    //2. store: string, store PK值。
    //3. keyStr: string, 介面存取驗證字串md5(salt + accToken + timestamp)
    //4. timestamp: long, 呼叫API當下 timestamp
    @POST("api_107.php")
    Call<ResAddRemoveStoreBookMark> postAddRemoveStoreBookMark(
            @Query("token") String token,
            @Query("store") String store,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

}
