package gameball.com.tw.onecupcafe.activities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.TextView;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.fragments.HelpCenter.HelpCenterFragment;
import gameball.com.tw.onecupcafe.fragments.setting.OrderHistoryFragment;
import me.yokeyword.fragmentation.SupportActivity;

//服務中心

public class HelpCenterActivity extends SupportActivity implements View.OnClickListener {

    private TextView tvSettingPagePrev, tvSettingActiviyTitle;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        initView();
    }

    private void initView() {
        tvSettingPagePrev = (TextView) findViewById(R.id.tvSettingPagePrev);
        tvSettingActiviyTitle = (TextView) findViewById(R.id.tvSettingActiviyTitle);
        tvSettingActiviyTitle.setText(getString(R.string.setting_service_title));
        tvSettingPagePrev.setOnClickListener(this);
        initFragment();
    }

    //用fragment原因是因為之前寫在SettingActivity中
    //後來流程重構決定拉出來但是又要不影響畫面
    //所以才會有種多此一舉的寫法
    private void initFragment() {
        if (findFragment(OrderHistoryFragment.class) == null) {
            loadRootFragment(R.id.flSettingPageContent, HelpCenterFragment.newInstance());
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tvSettingPagePrev:
                HelpCenterActivity.this.finish();
                break;
            default:
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
