package gameball.com.tw.onecupcafe.items.PointCardPojo;

import java.io.Serializable;
import java.util.ArrayList;

public class ResGetAllPointCardList implements Serializable {
    String code;
    String message;
    ReturnData retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ReturnData getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(ReturnData retnObject) {
        this.retnObject = retnObject;
    }

    public class ReturnData{
        String type;
        ArrayList<StorePointCardList> storeList;

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public ArrayList<StorePointCardList> getStoreList() {
            return storeList;
        }

        public void setStoreList(ArrayList<StorePointCardList> storeList) {
            this.storeList = storeList;
        }

    }
}
