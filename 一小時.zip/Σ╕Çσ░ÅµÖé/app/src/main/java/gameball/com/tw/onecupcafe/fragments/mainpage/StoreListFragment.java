package gameball.com.tw.onecupcafe.fragments.mainpage;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.orhanobut.hawk.Hawk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.activities.HomeActivity;
import gameball.com.tw.onecupcafe.adapters.StoreListAdatper;
import gameball.com.tw.onecupcafe.core.base.BaseFragment;
import gameball.com.tw.onecupcafe.core.etc.RecycleViewLayoutManager;
import gameball.com.tw.onecupcafe.items.StorePojo.ResGetStoreList;
import gameball.com.tw.onecupcafe.items.StorePojo.StoreData;
import gameball.com.tw.onecupcafe.retrofit.ApiBase;
import gameball.com.tw.onecupcafe.retrofit.api.StoreApi;
import gameball.com.tw.onecupcafe.utils.ApiErrorMsgCallback;
import gameball.com.tw.onecupcafe.utils.CalculateStoreDistance;
import gameball.com.tw.onecupcafe.utils.Constants;
import gameball.com.tw.onecupcafe.utils.MD5Util;
import gameball.com.tw.onecupcafe.utils.ProgressBarCallBack;
import gameball.com.tw.onecupcafe.utils.ResStatusReturn;
import gameball.com.tw.onecupcafe.utils.TimeStampUtil;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by sofasoso on 2018/3/31.
 */

public class StoreListFragment extends BaseFragment {
    public static final String TAG = "StoreListFragment";
    private RecyclerView rvStoreList;
    private StoreListAdatper storeListAdatper;


    private static final String ARG_POSITION = "position";

    public static StoreListFragment newInstance(int position) {
        Bundle args = new Bundle();
        StoreListFragment fragment = new StoreListFragment();
        fragment.setArguments(args);
        args.putInt(ARG_POSITION,position);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_store_list, container, false);
        initView(view);
        return view;
    }

    @Override
    public void onClick(View v) {

    }

    private void initView(View view) {
        storeListAdatper = new StoreListAdatper(getContext(), ((StoreListMainFragment)getParentFragment()).arrStoredData);
        rvStoreList = view.findViewById(R.id.rvStoreList);
        rvStoreList.setAdapter(storeListAdatper);
        new RecycleViewLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, rvStoreList);
    }

    @Override
    public void onResume() {
        super.onResume();
    }




}
