package gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo;

import java.io.Serializable;

public class ResUserEmailBind implements Serializable {
    String code;
    String message;
    String retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(String retnObject) {
        this.retnObject = retnObject;
    }
}
