package gameball.com.tw.onecupcafe.fragments.login;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.constraint.Group;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.Profile;
import com.facebook.login.LoginBehavior;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.orhanobut.hawk.Hawk;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import gameball.com.tw.onecupcafe.App;
import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.activities.HomeActivity;
import gameball.com.tw.onecupcafe.activities.SettingPageActivity;
import gameball.com.tw.onecupcafe.core.base.BaseFragment;
import gameball.com.tw.onecupcafe.items.SettingPojo.ResUpdateUserInfo;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResGetUserInfo;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResUserFBLogin;
import gameball.com.tw.onecupcafe.retrofit.ApiBase;
import gameball.com.tw.onecupcafe.retrofit.api.SettingApi;
import gameball.com.tw.onecupcafe.retrofit.api.UserSignInSignUpApi;
import gameball.com.tw.onecupcafe.utils.ApiErrorMsgCallback;
import gameball.com.tw.onecupcafe.utils.Constants;
import gameball.com.tw.onecupcafe.utils.GlideImageUtil;
import gameball.com.tw.onecupcafe.utils.MD5Util;
import gameball.com.tw.onecupcafe.utils.ProgressBarCallBack;
import gameball.com.tw.onecupcafe.utils.ResStatusReturn;
import gameball.com.tw.onecupcafe.utils.TimeStampUtil;
import gameball.com.tw.onecupcafe.utils.ToastUtil;
import me.yokeyword.fragmentation.ISupportFragment;
import me.yokeyword.fragmentation.SupportFragment;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignUpFragment extends BaseFragment {
    public static final String TAG = "SignUpFragment";

    public static SignUpFragment newInstance() {
        Bundle args = new Bundle();

        SignUpFragment fragment = new SignUpFragment();
        fragment.setArguments(args);
        return fragment;
    }

    private TextView tvSignUpLater, tvSignUpForgetDesc;

    private Button btnSignUp;

    // FB
    private LoginManager loginManager;
    private CallbackManager callbackManager;
    private ApiErrorMsgCallback apiErrorMsgCallback;
    private Button btnFacebookLogin;
    private Group groupSignUpStep1, groupSignUpFbSuccess;

    private ProgressBarCallBack progressBarCallBack;

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_sign_up_main, container, false);
        initView(v);
        return v;

    }

    private void initView(View v) {
        progressBarCallBack = (ProgressBarCallBack) getActivity();
        apiErrorMsgCallback = (ApiErrorMsgCallback) getActivity();

        tvSignUpLater = v.findViewById(R.id.tvSignUpLater);
        tvSignUpForgetDesc = v.findViewById(R.id.tvSignUpForgetDesc);
//        String text = getString(R.string.sign_up_forget_desc1);
//        tvSignUpForgetDesc.setText(Html.fromHtml(text), TextView.BufferType.SPANNABLE);
//        tvSignUpForgetDesc.setOnClickListener(this);

        tvSignUpLater.setOnClickListener(this);
        btnFacebookLogin = (Button) v.findViewById(R.id.btnFacebookLogin);
        btnFacebookLogin.setOnClickListener(this);
        loginManager = LoginManager.getInstance();
        callbackManager = CallbackManager.Factory.create();

        btnSignUp = (Button) v.findViewById(R.id.btnSignUp);
        btnSignUp.setOnClickListener(this);

        groupSignUpStep1 = (Group) v.findViewById(R.id.groupSignUpStep1);
        groupSignUpFbSuccess = (Group) v.findViewById(R.id.groupSignUpFbSuccess);
    }

    private void initFacebookLogin() {
        // init LoginManager & CallbackManager
        List<String> permissions = new ArrayList<>();
        loginManager.setLoginBehavior(LoginBehavior.NATIVE_WITH_FALLBACK);
        permissions.add("public_profile");
        permissions.add("email");
        permissions.add("user_friends");
        loginManager.logInWithReadPermissions(this, permissions);
        loginManager.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(final LoginResult loginResult) {
                // 登入成功
//         可以取得相關資訊，這裡就請各位自行打印出來
                Log.e(TAG, "Facebook getApplicationId: " + loginResult.getAccessToken().getApplicationId());
                Log.e(TAG, "Facebook getUserId: " + loginResult.getAccessToken().getUserId());
                Log.e(TAG, "Facebook getExpires: " + loginResult.getAccessToken().getExpires());
                Log.e(TAG, "Facebook getLastRefresh: " + loginResult.getAccessToken().getLastRefresh());
                Log.e(TAG, "Facebook getToken: " + loginResult.getAccessToken().getToken());
                Log.e(TAG, "Facebook getSource: " + loginResult.getAccessToken().getSource());
                Log.e(TAG, "Facebook getRecentlyGrantedPermissions: " + loginResult.getRecentlyGrantedPermissions());
                Log.e(TAG, "Facebook getRecentlyDeniedPermissions: " + loginResult.getRecentlyDeniedPermissions());
//                 透過GraphRequest來取得用戶的Facebook資訊
                GraphRequest graphRequest = GraphRequest.newMeRequest(loginResult.getAccessToken(), new GraphRequest.GraphJSONObjectCallback() {
                    @Override
                    public void onCompleted(JSONObject object, GraphResponse response) {
                        try {
                            if (response.getConnection().getResponseCode() == 200) {
                                long id = object.getLong("id");
                                String name = object.getString("name");
                                String email = object.getString("email");
                                Log.d(TAG, "Facebook id:" + id);
                                Log.d(TAG, "Facebook name:" + name);
                                Log.d(TAG, "Facebook email:" + email);
                                // 此時如果登入成功，就可以順便取得用戶大頭照


                                Hawk.put(Constants.USER_NAME, name);
                                Profile profile = Profile.getCurrentProfile();
                                // 設定大頭照大小
                                try {
                                    Uri userPhoto = profile.getProfilePictureUri(200, 200);
                                    Log.e(TAG, "Facebook User Img:" + userPhoto);

//                                    Hawk.put(Constants.USER_PHOTO_URL , "http://graph.facebook.com/"+id+"/picture?type=large");
                                } catch (Exception e) {
                                    Log.e(TAG, "Facebook Error:" + e.toString());
                                }
                                apiUserFBLogin(email, loginResult.getAccessToken().getUserId(), loginResult.getAccessToken().getToken());
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
                // https://developers.facebook.com/docs/android/graph?locale=zh_TW
                // 如果要取得email，需透過添加參數的方式來獲取(如下)
                // 不添加只能取得id & name
                Bundle parameters = new Bundle();
                parameters.putString("fields", "id,name,email");
                graphRequest.setParameters(parameters);
                graphRequest.executeAsync();
            }

            @Override
            public void onCancel() {
                // 用戶取消
                Log.d(TAG, "Facebook onCancel");
            }

            @Override
            public void onError(FacebookException error) {
                // 登入失敗
                Log.d(TAG, "Facebook onError:" + error.toString());
            }
        });

    }

    @Override
    public void onClick(View v) {
        ISupportFragment topFragment = getTopFragment();
        SupportFragment baseFragment = (SupportFragment) topFragment;
        switch (v.getId()) {
            case R.id.tvSignUpForgetDesc://忘記帳密
                ForgetAccountFragment forgetAccountFragment = findFragment(ForgetAccountFragment.class);
                if (forgetAccountFragment == null) {
                    baseFragment.startWithPopTo(ForgetAccountFragment.newInstance(), SignUpFragment.class, false);
                } else {
                    baseFragment.start(forgetAccountFragment, SupportFragment.SINGLETASK);
                }
                break;
            case R.id.tvSignUpLater://晚點登入
                Hawk.put("isFirst", false);
                getActivity().startActivity(new Intent(getActivity(), HomeActivity.class));
                getActivity().finish();
                break;
            case R.id.btnFacebookLogin://FB登入
                initFacebookLogin();
                break;
            case R.id.btnSignUp://註冊
                EmailLoginFragment emailLoginFragment = findFragment(EmailLoginFragment.class);
                if (emailLoginFragment == null) {
                    baseFragment.startWithPopTo(EmailLoginFragment.newInstance(), SignUpFragment.class, false);
                } else {
                    baseFragment.start(emailLoginFragment, SupportFragment.SINGLETASK);
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        callbackManager.onActivityResult(requestCode, resultCode, data);
    }

    //todo
    //檔名：api_004.php 功能：第三方註冊/登入
    private void apiUserFBLogin(final String strEmail, final String strUserId, String strThirdPartToken) {
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeyStr = MD5Util.MD5(Constants.SALT + "FB", strUserId, strTimeStamp);
//        Log.e(TAG,"SignUpParams-3rdToken:"+strThirdPartToken+";Lang:"+App.locale+
//        ";TimeZone:"+ App.timezone+";UserEmail:"+strEmail+";SenderId:"+Constants.strSenderId+
//        ";TimeStamp:"+strTimeStamp+";KeyStr:"+strKeyStr);
        Log.e(TAG, "SignUpParams-3rdToken:" + strThirdPartToken);
        Log.e(TAG, "SignUpParams-Lang:" + App.locale);
        Log.e(TAG, "SignUpParams-TimeZone:" + App.timezone);
        Log.e(TAG, "SignUpParams-UserEmail:" + strEmail);
        Log.e(TAG, "SignUpParams-SenderId:" + Constants.strSenderId);
        Log.e(TAG, "SignUpParams-TimeStamp:" + strTimeStamp);
        Log.e(TAG, "SignUpParams-KeyStr:" + strKeyStr);
//        Log.e(TAG,"KeyStr2-"+Constants.SALT+"FB"+str)
//        keyStr: string, 介面存取驗證字串md5(salt + regType + reg3rdPartyID +timestamp)
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                progressBarCallBack.showProgressBar();

            }
        });



        Call<ResUserFBLogin> getUserFBLogin =
                ApiBase.instance().
                        create(UserSignInSignUpApi.class).
                        postUserFBLogin(
                                "FB",
                                strUserId,
                                App.locale,
                                App.timezone,
                                strThirdPartToken,
                                strEmail,
                                "",
                                "",
                                Constants.strSenderId,
                                "android",
                                strKeyStr,
                                strTimeStamp
                        );

        getUserFBLogin.enqueue(new Callback<ResUserFBLogin>() {
            @Override
            public void onResponse(Call<ResUserFBLogin> call, Response<ResUserFBLogin> response) {
                try {
                    Log.e(TAG, "Success:" + response.body().getMessage() + ":" + response.body().getCode());
                    String strApiRtnCode = response.body().getCode();
                    if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {
                        Log.e(TAG, "onResponse: " + response.body().getRetnObject().getUserEmail());
                        final String strUserEmail = response.body().getRetnObject().getUserEmail();
                        String strUserAccToken = response.body().getRetnObject().getAccToken();
                        Hawk.put(Constants.USER_EMAIL, strUserEmail);
                        Hawk.put(Constants.USER_ACCTOKEN, strUserAccToken);
                        Hawk.put(Constants.USER_TOKEN_EXPIRE_TIME, response.body().getRetnObject().getExpireTime());
                        Hawk.put(Constants.USER_LOGIN_TYPE, "FB");
                        new AsyncTask(){
                            @Override
                            protected Object doInBackground(Object[] objects) {
                                FbUserImageToBitmap(strUserId);
                                return null;
                            }

                            @Override
                            protected void onPostExecute(Object o) {
                                apiUpdateUserInfo("", Hawk.get(Constants.USER_NAME, ""), strUserEmail);
                                super.onPostExecute(o);
                            }
                        }.execute();
                        progressBarCallBack.hideProgressBar();
                    } else {
                        progressBarCallBack.hideProgressBar();
                        apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                    }

                } catch (Exception e) {
                    Log.e(TAG, "ResExc:" + e.toString());
                    progressBarCallBack.hideProgressBar();
                }


            }

            @Override
            public void onFailure(Call<ResUserFBLogin> call, Throwable t) {
                Log.e(TAG, "Error:" + t.toString());
                progressBarCallBack.hideProgressBar();
            }
        });


    }

    private void goHomeAcitvity() {
        new CountDownTimer(2000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                getActivity().startActivity(new Intent(getActivity(), HomeActivity.class));
                getActivity().finish();
            }
        }.start();
    }

    private Bitmap bmpUserImage;
    private void FbUserImageToBitmap(String numFacebookUserId) {
        try {
            URL imageURL = new URL("https://graph.facebook.com/" + numFacebookUserId + "/picture?type=large");
            URLConnection conn = imageURL.openConnection();
            conn.connect();
            InputStream in;
            in = conn.getInputStream();
            bmpUserImage = BitmapFactory.decodeStream(in);
            //Convert bitmap to byte array
        } catch (Exception e) {
            Log.e(TAG,"FbImageExc:"+e.toString());
        }
    }

    //檔名：api_007.php 功能：取得會員資料
    private void apiGetUserInfo() {
        progressBarCallBack.showProgressBar();
        String strToken = Hawk.get(Constants.USER_ACCTOKEN);
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken, strTimeStamp);
        Call<ResGetUserInfo> getGetUserInfo =
                ApiBase.instance().
                        create(UserSignInSignUpApi.class)
                        .postGetUserInfo(strToken
                                , strKeyStr
                                , strTimeStamp);

        getGetUserInfo.enqueue(new Callback<ResGetUserInfo>() {
            @Override
            public void onResponse(Call<ResGetUserInfo> call, Response<ResGetUserInfo> response) {
                try {
                    String strApiRtnCode = response.body().getCode();
                    if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {

                        ResGetUserInfo.ReturnData userData = response.body().getRetnObject();
                        String userEmail = userData.getUserEmail();
                        String nickName = userData.getNickName();
                        String photoURL = userData.getPhotoURL();
                        String phone = userData.getPhone();
                        Log.e(TAG, "Email" + userEmail);
                        Log.e(TAG, "Name" + nickName);
                        Log.e(TAG, "PhotoUrl" + photoURL);
                        Log.e(TAG, "Phone" + phone);
                        Hawk.put(Constants.USER_NAME, nickName);
                        Hawk.put(Constants.USER_PHOTO_URL, photoURL);
                        progressBarCallBack.hideProgressBar();
                        if (((SettingPageActivity) getActivity()).strFromTag.equals("RecieveGift")) {
                            getActivity().finish();
                        } else {
                            goHomeAcitvity();
                        }
                    } else {
                        progressBarCallBack.hideProgressBar();
                        apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                    }

                } catch (Exception e) {
                    progressBarCallBack.hideProgressBar();
                    Log.e(TAG, "ApiError:" + e.toString());
                }
            }

            @Override
            public void onFailure(Call<ResGetUserInfo> call, Throwable t) {
                progressBarCallBack.hideProgressBar();
                Log.e(TAG, "GetUserInfo:" + t.toString());
            }
        });
    }

    //    //檔名：api_503.php 功能：更新會員更新
    private void apiUpdateUserInfo(String strUserPhone, String strUserName, String strUserMail) {
        progressBarCallBack.showProgressBar();
        String strToken = Hawk.get(Constants.USER_ACCTOKEN);
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken, strTimeStamp);

        RequestBody requestFile = null;
        MultipartBody.Part imgPart = null;

        if (bmpUserImage != null && bmpUserImage.getByteCount() > 0) {
            File file = new File(getActivity().getCacheDir(), "userImg.jpeg");
            try {
                file.createNewFile();
                //Convert bitmap to byte array
                Bitmap bitmap = bmpUserImage;
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100 /*ignored for PNG*/, bos);
                byte[] bitmapdata = bos.toByteArray();

                //write the bytes in file
                FileOutputStream fos = new FileOutputStream(file);
                fos.write(bitmapdata);
                fos.flush();
                fos.close();
            } catch (Exception e) {
            }
            requestFile = RequestBody.create(MediaType.parse("image/*"), file);
            imgPart =
                    MultipartBody.Part.createFormData("photo", file.getName(), requestFile);
            Log.e(TAG, "ImgFileSize:" + file.length());
        } else {
            requestFile = RequestBody.create(MultipartBody.FORM, "");
            imgPart = MultipartBody.Part.createFormData("file", "", requestFile);
        }

        Call<ResUpdateUserInfo> getUpdateUserInfo =
                ApiBase.instance().create(SettingApi.class).
                        postUpdateUserInfo(
                                strToken,
                                strUserMail,
                                strUserName,
                                strUserPhone,
                                strKeyStr,
                                strTimeStamp,
                                imgPart
                        );

        getUpdateUserInfo.enqueue(new Callback<ResUpdateUserInfo>() {
            @Override
            public void onResponse(Call<ResUpdateUserInfo> call, Response<ResUpdateUserInfo> response) {
                try {
                    String strApiRtnCode = response.body().getCode();
                    if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {
                        Log.e(TAG, "UploadSuccessStep1");
                        Log.e(TAG, "UploadSuccess:" + response.body().getRetnObject().getUid());
                        progressBarCallBack.hideProgressBar();
                        apiGetUserInfo();
                    } else {
                        apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                        progressBarCallBack.hideProgressBar();
                    }

                } catch (Exception e) {
                    Log.e(TAG, "ApiError:" + e.toString());
                    progressBarCallBack.hideProgressBar();
                }
            }

            @Override
            public void onFailure(Call<ResUpdateUserInfo> call, Throwable t) {
                Log.e(TAG, t.toString());
                progressBarCallBack.hideProgressBar();
            }
        });

    }

}
