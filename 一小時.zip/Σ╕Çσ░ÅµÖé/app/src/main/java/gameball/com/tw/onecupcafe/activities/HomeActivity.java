package gameball.com.tw.onecupcafe.activities;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;

import android.support.v7.app.AlertDialog;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.orhanobut.hawk.Hawk;

import java.util.ArrayList;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.core.base.BaseFragment;
import gameball.com.tw.onecupcafe.fragments.mainpage.PointCardFragment;
import gameball.com.tw.onecupcafe.fragments.mainpage.SettingPageFragment;
import gameball.com.tw.onecupcafe.fragments.mainpage.StoreListFragment;
import gameball.com.tw.onecupcafe.fragments.mainpage.StoreListMainFragment;
import gameball.com.tw.onecupcafe.fragments.mainpage.StoreMapFragment;
import gameball.com.tw.onecupcafe.items.StorePojo.StoreData;
import gameball.com.tw.onecupcafe.utils.ApiErrorMsgCallback;
import gameball.com.tw.onecupcafe.utils.Constants;
import gameball.com.tw.onecupcafe.utils.PermissionCallBack;
import gameball.com.tw.onecupcafe.utils.PermissionHelper;
import gameball.com.tw.onecupcafe.utils.ProgressBarCallBack;
import gameball.com.tw.onecupcafe.utils.ProgressBarUtil;
import gameball.com.tw.onecupcafe.utils.ToolBarChange;
import me.yokeyword.fragmentation.ISupportFragment;
import me.yokeyword.fragmentation.SupportActivity;
import me.yokeyword.fragmentation.SupportFragment;

//主頁面功能

public class HomeActivity extends SupportActivity implements View.OnClickListener, ToolBarChange, ProgressBarCallBack,ApiErrorMsgCallback {

    public static final String TAG = "Home";
    private Toolbar tbToolBar;
    private PermissionHelper permissionHelper;
    public ImageView ivToolBarQrCode;
    public ImageView ivToolBarMap;
    private BottomNavigationView navigation;
    private boolean isMapMode = false;
    public ArrayList<StoreData> arrHomeStoredData = new ArrayList<>();
    public double numUserLng = 0, numUserLat = 0;
//    public View viewPlzLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        initBottomNavigation();
        permissionCheck();
        getUserLatLng();
        initToolBar();
        initView();
        initStoreListFragment();
    }

    //下方navigationbar
    //可能會抽掉重寫
    private void initBottomNavigation() {
        navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        navigation.setItemIconTintList(null);

        String strUserToken = Hawk.get(Constants.USER_ACCTOKEN, Constants.USER_DEF_DATA);
        String strUserName = Hawk.get(Constants.USER_NAME, Constants.USER_DEF_DATA);
        String strUserFbToken = Hawk.get(Constants.USER_FB_ACCTOKEN, Constants.USER_DEF_DATA);
        String strUserPhone = Hawk.get(Constants.USER_PHONE, Constants.USER_DEF_DATA);
        String strUserId = Hawk.get(Constants.USER_ID, Constants.USER_DEF_DATA);
        String strUserEmail = Hawk.get(Constants.USER_EMAIL, Constants.USER_DEF_DATA);
        String strUserLoginType = Hawk.get(Constants.USER_LOGIN_TYPE, Constants.USER_DEF_DATA);

        Log.e(TAG, "UserToken:" + strUserToken +
                ";UserName:" + strUserName +
                ";UserFbToken:" + strUserFbToken +
                "UserPhone:" + strUserPhone +
                "UserId:" + strUserId +
                "UserEmail:" + strUserEmail +
                "UserLoginType:" + strUserLoginType);
    }

    //上方客製tool bar
    private void initToolBar() {
        tbToolBar = findViewById(R.id.tbToolBar);
        View logo = getLayoutInflater().inflate(R.layout.item_toolbar, null);
        tbToolBar.addView(logo);
        tbToolBar.setNavigationIcon(null);
        setSupportActionBar(tbToolBar);
    }

    //android 6.0 check permission
    private void permissionCheck() {
        permissionHelper = new PermissionHelper();
        permissionHelper.request(this, new String[]{
                        Manifest.permission.CAMERA,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.CALL_PHONE,
                        Manifest.permission_group.STORAGE},
                new PermissionCallBack() {
                    @Override
                    public void onRequestPermissionsResult(boolean grant) {
                    }
                });
    }

    private void initView() {
//        viewPlzLogin = (View) findViewById(R.id.viewPlzLogin);
        ivToolBarQrCode = findViewById(R.id.ivToolBarQrCode);
        ivToolBarMap = findViewById(R.id.ivToolBarMap);

        ivToolBarQrCode.setOnClickListener(this);
        ivToolBarMap.setOnClickListener(this);

        progressBar = new ProgressBarUtil(this);

    }

    //設店家列表為主頁
    private void initStoreListFragment() {
//        if (isSignUp == false) {
//            if (findFragment(SignUpFragment.class) == null) {
//                loadRootFragment(R.id.flFragCotainer, SignUpFragment.newInstance());
//            }
//        } else {
        progressBar.show();
        if (findFragment(StoreListMainFragment.class) == null) {
            loadRootFragment(R.id.flFragCotainer, StoreListMainFragment.newInstance());
        }

//        }
    }

    //bottom navigation功能
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//            if (isSignUp == true) {
            final ISupportFragment topFragment = getTopFragment();
            BaseFragment baseFragment = (BaseFragment) topFragment;
            switch (item.getItemId()) {
                //店家主頁
                case R.id.navigation_home:
                    customBottonNavigationClickAction(0);
                    StoreListMainFragment storeListMainFragment = findFragment(StoreListMainFragment.class);
                    Bundle newBundle = new Bundle();
                    newBundle.putString("from", "From:" + topFragment.getClass().getSimpleName());
                    storeListMainFragment.putNewBundle(newBundle);
                    baseFragment.start(storeListMainFragment, SupportFragment.SINGLETASK);

                    return true;
                //集點卡
                case R.id.navigation_point_card:
                    customBottonNavigationClickAction(1);
                    PointCardFragment pointCardFragment = findFragment(PointCardFragment.class);
                    if (pointCardFragment == null) {
                        baseFragment.startWithPopTo(PointCardFragment.newInstance(), StoreListMainFragment.class, false);
//                        loadRootFragment(R.id.flFragCotainer, PointCardFragment.newInstance(), true, true);
                    } else {
                        baseFragment.start(pointCardFragment, SupportFragment.SINGLETASK);
                    }
                    return true;
                //todo
//                case R.id.navigation_story:
//                    customBottonNavigationClickAction(2);
//                    return true;
                //todo
//                case R.id.navigation_notification:
//                    customBottonNavigationClickAction(3);
//                    return true;
                //其他設定
                case R.id.navigation_others:
                    customBottonNavigationClickAction(2);
                    SettingPageFragment settingPageFragment = findFragment(SettingPageFragment.class);
                    if (settingPageFragment == null) {
                        baseFragment.startWithPopTo(SettingPageFragment.newInstance(), StoreListMainFragment.class, false);
                    } else {
                        baseFragment.start(settingPageFragment, SupportFragment.SINGLETASK);
                    }

                    return true;
            }
//            }
            return false;
        }
    };


    private void customBottonNavigationClickAction(int position) {

        navigation.getMenu().getItem(0).setIcon(R.drawable.ico_menu_01_off);
        navigation.getMenu().getItem(1).setIcon(R.drawable.ico_menu_02_off);
//        navigation.getMenu().getItem(2).setIcon(R.drawable.ico_menu_03_off);
//        navigation.getMenu().getItem(3).setIcon(R.drawable.ico_menu_04_off);
        navigation.getMenu().getItem(2).setIcon(R.drawable.ico_menu_05_off);

        switch (position) {
            case 0:
                navigation.getMenu().getItem(0).setIcon(R.drawable.ico_menu_01_on);
                isMapMode = false;
                ivToolBarMap.setImageResource(R.drawable.ico_base_map);
                break;
            case 1:
                navigation.getMenu().getItem(1).setIcon(R.drawable.ico_menu_02_on);
                break;
//            case 2:
//                navigation.getMenu().getItem(2).setIcon(R.drawable.ico_menu_03_on);
//                break;
//            case 3:
//                navigation.getMenu().getItem(3).setIcon(R.drawable.ico_menu_04_on);
//                break;
            case 2:
                navigation.getMenu().getItem(2).setIcon(R.drawable.ico_menu_05_on);
                break;
            default:
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Log.e(TAG, "RequestCode:" + requestCode + ";" + "Permission:" + permissions.length + ";grantResult" + grantResults.length);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            //掃描qrcode
            case R.id.ivToolBarQrCode:
//                if (isSignUp == true) {
                IntentIntegrator integrator = new IntentIntegrator(this);
                integrator.setCaptureActivity(ScannerActivity.class);
                integrator.initiateScan();
//                }
                break;
            //地圖
            case R.id.ivToolBarMap:
//                Uri gmmIntentUri = Uri.parse("geo:25.053335,121.508973");
//                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
//                mapIntent.setPackage("com.google.android.apps.maps");
//                if (mapIntent.resolveActivity(getPackageManager()) != null) {
//                    startActivity(mapIntent);
//                }

//                if (isSignUp == true) {
                final ISupportFragment topFragment = getTopFragment();
                BaseFragment baseFragment = (BaseFragment) topFragment;
                if (isMapMode == false) {

                    StoreMapFragment storeMapFragment = findFragment(StoreMapFragment.class);
                    if (storeMapFragment == null) {
                        Log.e(TAG, "New Fragment3");
                        baseFragment.startWithPopTo(StoreMapFragment.newInstance(), StoreListMainFragment.class, false);
                    } else {
                        Log.e(TAG, "Pop Fragment3");
                        baseFragment.start(storeMapFragment, SupportFragment.SINGLETASK);
                    }
                    isMapMode = true;
                    ivToolBarMap.setImageResource(R.drawable.ico_base_list);
                } else {
                    customBottonNavigationClickAction(0);
                    StoreListMainFragment storeListMainFragment = findFragment(StoreListMainFragment.class);
                    Bundle newBundle = new Bundle();
                    storeListMainFragment.putNewBundle(newBundle);
                    baseFragment.start(storeListMainFragment, SupportFragment.SINGLETASK);
                    isMapMode = false;
                    ivToolBarMap.setImageResource(R.drawable.ico_base_map);
                }
//                }
                break;
            default:
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        //掃描qrcode result
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() == null) {
//                Toast.makeText(this, "Cancelled", Toast.LENGTH_LONG).show();
            } else {
//                Toast.makeText(this, "Scanned: " + result.getContents(), Toast.LENGTH_LONG).show();
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    //切換店家地圖 店家列表
    @Override
    public void setToolBarView(String strToolBarTag) {
        switch (strToolBarTag) {
            case "HideMap":
                ivToolBarMap.setVisibility(View.GONE);
                break;
            case "ShowMap":
//                viewPlzLogin.setVisibility(View.GONE);
                ivToolBarMap.setVisibility(View.VISIBLE);
                break;
            default:
                break;
        }
    }

    //取得使用者location
    private void getUserLatLng() {
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            String provider = lm.getBestProvider(new Criteria(), true);
            Location location = lm.getLastKnownLocation(provider);
            numUserLng = location.getLongitude();
            numUserLat = location.getLatitude();
        } catch (Exception e) {
            Log.e(TAG, "GpsError:" + e.toString());
        }
    }


    //動態產生ProcgressBar
    private ProgressBarUtil progressBar;

    @Override
    public void showProgressBar() {
        progressBar.show();
    }

    @Override
    public void hideProgressBar() {
        progressBar.hide();
    }

    @Override
    public void showErrorMsg(String strErrorCode) {
//        String strErrorMsg = "";
//        switch (strErrorCode){
//                case "101":
//                    strErrorMsg = getString(R.string.error_msg_101);
//                    break;
//                case "102":
//                    strErrorMsg = getString(R.string.error_msg_102);
//                    break;
//                case "103":
//                    strErrorMsg = getString(R.string.error_msg_103);
//                    break;
//                case "104":
//                    strErrorMsg = getString(R.string.error_msg_104);
//                    break;
//                case "105":
//                    strErrorMsg = getString(R.string.error_msg_105);
//                    break;
//                case "106":
//                    strErrorMsg = getString(R.string.error_msg_106);
//                    break;
//                case "107":
//                    strErrorMsg = getString(R.string.error_msg_107);
//                    break;
//                case "109":
//                    strErrorMsg = getString(R.string.error_msg_109);
//                    break;
//        }
        showErrorAlertDialog(strErrorCode);
    }

    private AlertDialog.Builder builder;
    private void showErrorAlertDialog(String strMsgInfo) {
        Log.e("API ERROR", "MSG:" + strMsgInfo);
        if (builder == null) {
            builder = new AlertDialog.Builder(HomeActivity.this);
            builder.setTitle("發生錯誤");
            builder.setMessage(strMsgInfo);
            builder.setCancelable(false);
            builder.setPositiveButton("確認", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    builder = null;
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }
}
