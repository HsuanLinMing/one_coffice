package gameball.com.tw.onecupcafe.items.PointCardPojo;

public class ResShareGiftWithFriend {
    public String code;
    public String message;
    public ShareGiftWithFriendReturn retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ShareGiftWithFriendReturn getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(ShareGiftWithFriendReturn retnObject) {
        this.retnObject = retnObject;
    }

    public class ShareGiftWithFriendReturn {
        public String giftCode;
        public String owner;
        public String message;
        public String transToken;
        public Gift gift;

        public String getGiftCode() {
            return giftCode;
        }

        public void setGiftCode(String giftCode) {
            this.giftCode = giftCode;
        }

        public String getOwner() {
            return owner;
        }

        public void setOwner(String owner) {
            this.owner = owner;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String getTransToken() {
            return transToken;
        }

        public void setTransToken(String transToken) {
            this.transToken = transToken;
        }

        public Gift getGift() {
            return gift;
        }

        public void setGift(Gift gift) {
            this.gift = gift;
        }

        public class Gift {
            public String storeID;
            public String storeName;
            public String giftName;
            public int quantity;
            public String giftUnit;
            public String giftImage;
            public String redeemExpire;
            public int reciveExpireSec;

            public String getStoreID() {
                return storeID;
            }

            public void setStoreID(String storeID) {
                this.storeID = storeID;
            }

            public String getStoreName() {
                return storeName;
            }

            public void setStoreName(String storeName) {
                this.storeName = storeName;
            }

            public String getGiftName() {
                return giftName;
            }

            public void setGiftName(String giftName) {
                this.giftName = giftName;
            }

            public int getQuantity() {
                return quantity;
            }

            public void setQuantity(int quantity) {
                this.quantity = quantity;
            }

            public String getGiftUnit() {
                return giftUnit;
            }

            public void setGiftUnit(String giftUnit) {
                this.giftUnit = giftUnit;
            }

            public String getGiftImage() {
                return giftImage;
            }

            public void setGiftImage(String giftImage) {
                this.giftImage = giftImage;
            }

            public String getRedeemExpire() {
                return redeemExpire;
            }

            public void setRedeemExpire(String redeemExpire) {
                this.redeemExpire = redeemExpire;
            }

            public int getReciveExpireSec() {
                return reciveExpireSec;
            }

            public void setReciveExpireSec(int reciveExpireSec) {
                this.reciveExpireSec = reciveExpireSec;
            }
        }
    }
}