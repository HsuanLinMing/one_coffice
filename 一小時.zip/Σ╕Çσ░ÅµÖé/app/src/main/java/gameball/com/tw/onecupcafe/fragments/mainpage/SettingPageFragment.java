package gameball.com.tw.onecupcafe.fragments.mainpage;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.constraint.Group;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.orhanobut.hawk.Hawk;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.activities.HelpCenterActivity;
import gameball.com.tw.onecupcafe.activities.HomeActivity;
import gameball.com.tw.onecupcafe.activities.SettingPageActivity;
import gameball.com.tw.onecupcafe.core.base.BaseFragment;
import gameball.com.tw.onecupcafe.utils.Constants;
import gameball.com.tw.onecupcafe.utils.ToolBarChange;

public class SettingPageFragment extends BaseFragment {

    public static SettingPageFragment newInstance() {
        Bundle args = new Bundle();

        SettingPageFragment fragment = new SettingPageFragment();
        fragment.setArguments(args);
        return fragment;
    }

    private LinearLayout llSettingPhone, llSettingMail, llSettingOrder, llSettingPrivacy, llSettingProfile, llSettingService;
    private Button btnGoToSignUp, btnGoToSignUpLater;
    private ToolBarChange callback;
    private Group viewSettingSignUp, viewSettingCertifiedMail;
    private TextView tvSettingPhoneTitle;
    private View viewPlzLogin;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_setting, container, false);
        callback = (ToolBarChange) getActivity();
        callback.setToolBarView("HideMap");
        initView(view);
        return view;
    }

    @Override
    public void onClick(View v) {
        String strToken = Hawk.get(Constants.USER_ACCTOKEN, Constants.USER_DEF_DATA);
        switch (v.getId()) {
            case R.id.btnGoToSignUp:
                getActivity().startActivity(new Intent(getActivity(), SettingPageActivity.class)
                        .putExtra("ServiceCategory", "PhoneCertified"));
                break;
            case R.id.btnGoToSignUpLater:
                getActivity().onBackPressed();
                break;
            case R.id.llSettingPhone:
                startActivity(new Intent(getActivity(), SettingPageActivity.class).putExtra("ServiceCategory", "PhoneCertified"));
                break;
            case R.id.llSettingMail:
                startActivity(new Intent(getActivity(), SettingPageActivity.class).putExtra("ServiceCategory", "BindEmail"));
                break;
            case R.id.llSettingOrder:
                if (!strToken.equals(Constants.USER_DEF_DATA)) {
                    startActivity(new Intent(getActivity(), SettingPageActivity.class).putExtra("ServiceCategory", "OrderHistory"));
                } else {
                    viewPlzLogin.setVisibility(View.VISIBLE);
                }
                break;
            case R.id.llSettingPrivacy:
                startActivity(new Intent(getActivity(), SettingPageActivity.class).putExtra("ServiceCategory", "ServiceNote"));
                break;
            case R.id.llSettingProfile:

                if (!strToken.equals(Constants.USER_DEF_DATA)) {
                    startActivity(new Intent(getActivity(), SettingPageActivity.class).putExtra("ServiceCategory", "Profile"));
                } else {
                    viewPlzLogin.setVisibility(View.VISIBLE);
                }

                break;
            case R.id.llSettingService:
//                startActivity(new Intent(getActivity(), SettingPageActivity.class).putExtra("ServiceCategory", "HelpCenter"));
                startActivity(new Intent(getActivity(), HelpCenterActivity.class));
                break;
            default:
                break;
        }
    }

    private void initView(View v) {
        llSettingPhone = (LinearLayout) v.findViewById(R.id.llSettingPhone);
        llSettingMail = (LinearLayout) v.findViewById(R.id.llSettingMail);
        llSettingOrder = (LinearLayout) v.findViewById(R.id.llSettingOrder);
        llSettingPrivacy = (LinearLayout) v.findViewById(R.id.llSettingPrivacy);
        llSettingProfile = (LinearLayout) v.findViewById(R.id.llSettingProfile);
        llSettingService = (LinearLayout) v.findViewById(R.id.llSettingService);
        llSettingPhone.setOnClickListener(this);
        llSettingMail.setOnClickListener(this);
        llSettingOrder.setOnClickListener(this);
        llSettingPrivacy.setOnClickListener(this);
        llSettingProfile.setOnClickListener(this);
        llSettingService.setOnClickListener(this);


        viewSettingSignUp = (Group) v.findViewById(R.id.viewSettingSignUp);
        viewSettingCertifiedMail = (Group) v.findViewById(R.id.viewSettingCertifiedMail);

        viewPlzLogin = (View) v.findViewById(R.id.viewPlzLogin);

        btnGoToSignUp = (Button) v.findViewById(R.id.btnGoToSignUp);
        btnGoToSignUp.setOnClickListener(this);
        btnGoToSignUpLater = (Button) v.findViewById(R.id.btnGoToSignUpLater);
        btnGoToSignUpLater.setOnClickListener(this);

        tvSettingPhoneTitle = (TextView) v.findViewById(R.id.tvSettingPhoneTitle);

        switchView();
    }

    private void switchView() {
        String strToken = Hawk.get(Constants.USER_ACCTOKEN, Constants.USER_DEF_DATA);

        if (!strToken.equals(Constants.USER_DEF_DATA) && viewPlzLogin.getVisibility() == View.VISIBLE) {
            viewPlzLogin.setVisibility(View.GONE);
        }

        if (strToken.equals(Constants.USER_DEF_DATA)) {
            viewSettingSignUp.setVisibility(View.VISIBLE);
            viewSettingCertifiedMail.setVisibility(View.GONE);
        } else {
            String strSignUpType = Hawk.get(Constants.USER_LOGIN_TYPE, Constants.USER_DEF_DATA);
            if (strSignUpType.equals("FB")) {
                viewSettingSignUp.setVisibility(View.GONE);
                viewSettingCertifiedMail.setVisibility(View.GONE);
            } else {
                String strUserEmail = Hawk.get(Constants.USER_EMAIL, Constants.USER_DEF_DATA);
                if (strUserEmail.equals(Constants.USER_DEF_DATA)) {
                    tvSettingPhoneTitle.setText(getString(R.string.setting_phone_title));
                    viewSettingSignUp.setVisibility(View.VISIBLE);
                    viewSettingCertifiedMail.setVisibility(View.VISIBLE);
                }
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        switchView();
    }

    @Override
    public void onStop() {
        super.onStop();
        callback.setToolBarView("ShowMap");
    }
}
