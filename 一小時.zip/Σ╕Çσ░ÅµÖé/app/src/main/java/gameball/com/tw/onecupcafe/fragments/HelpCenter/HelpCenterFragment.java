package gameball.com.tw.onecupcafe.fragments.HelpCenter;

import android.Manifest;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.core.base.BaseFragment;
import gameball.com.tw.onecupcafe.utils.IntentActionUtil;
import gameball.com.tw.onecupcafe.utils.PermissionCallBack;
import gameball.com.tw.onecupcafe.utils.PermissionHelper;
import gameball.com.tw.onecupcafe.utils.ToastUtil;

public class HelpCenterFragment extends BaseFragment {

    public static HelpCenterFragment newInstance() {
        Bundle args = new Bundle();

        HelpCenterFragment fragment = new HelpCenterFragment();
        fragment.setArguments(args);
        return fragment;
    }

    public static final String TAG = "HelpCenterFragment";
    private TextView tvSettingHelpCenterDesc2;
    private PermissionHelper permissionHelper;
    private ImageView ivSettingHelpCenterLineAt;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_setting_help_center, container, false);
        initView(view);
        return view;
    }

    private void initView(View v) {
        tvSettingHelpCenterDesc2 = (TextView) v.findViewById(R.id.tvSettingHelpCenterDesc2);
        tvSettingHelpCenterDesc2.setOnClickListener(this);
        ivSettingHelpCenterLineAt = (ImageView) v.findViewById(R.id.ivSettingHelpCenterLineAt);
        ivSettingHelpCenterLineAt.setOnClickListener(this);
    }

    private void permissionCheck() {
        permissionHelper = new PermissionHelper();
        permissionHelper.request(this, new String[]{
                        Manifest.permission.CALL_PHONE},
                new PermissionCallBack() {
                    @Override
                    public void onRequestPermissionsResult(boolean grant) {
                    }
                });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Log.e(TAG, "RequestCode:" + requestCode + ";" + "Permission:" + permissions.length + ";grantResult" + grantResults.length);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tvSettingHelpCenterDesc2:
                IntentActionUtil.phoneCall("02-2550-9196");
                break;
            case R.id.ivSettingHelpCenterLineAt:
                IntentActionUtil.lineChanel("@1cup.cafe");
                break;
            default:
                break;
        }
    }
}
