package gameball.com.tw.onecupcafe.activities;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;

public class SchemeSwitchActivity extends Activity {
    public static final String TAG = "SchemeSwitch";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initSchemeData();
    }

    private void initSchemeData() {
        if (getIntent() != null || getIntent().getData() != null) {
            try {
                Intent intent = getIntent();
                Uri uri = intent.getData();
                Log.e(TAG, "scheme: " + uri.getScheme());
                Log.e(TAG, "host: " + uri.getHost());
                Log.e(TAG, "port: " + uri.getPort());
                Log.e(TAG, "path: " + uri.getPath());
                String strPath = uri.getPath();
                String[] patharr = strPath.split("/");
                Log.e(TAG, "initSchemeData: " + patharr[1]);
                Log.e(TAG, "queryString: " + uri.getQuery());
                Log.e(TAG, "queryParameter: " + uri.getQueryParameter("key"));

                String strParams = "";
                if(patharr.length>1){
                    strParams = patharr[1];
                }
                switchDeepLinkScheme(uri.getHost(), strParams);
            } catch (Exception e) {
                Log.e(TAG, "initSchemeDataError: " + e.toString());
            }
        } else {
            SchemeSwitchActivity.this.finish();
        }

    }

    private void switchDeepLinkScheme(String strDeepLinkType, String strParams) {
        switch (strDeepLinkType) {
            case "shopList":
                break;
            case "shopDetail":
                if(strParams.equals("")){

                }else {
                    String strShopId = strParams;
                }
                break;
            case "prodBuy":
                if(strParams.equals("")){

                }else {
                    String strProdId = strParams;
                }
                break;
            case "orderList":
                if(strParams.equals("")){

                }else {
                    String strStoreId = strParams;
                }
                break;
            case "freeList":
                if(strParams.equals("")){

                }else {
                    String strProdId = strParams;
                }
                break;
            case "giftList":
                if(strParams.equals("")){

                }else {
                    String strProdId = strParams;
                }
                break;
            case "transCode":
                receiveGift(strParams);
                break;
            case "photos":
                break;
            case "notify":
                break;
            case "setting":
                break;
            default:
                break;
        }
    }

    private void receiveGift(String strTrasnCode) {
        Bundle bundle = new Bundle();
        bundle.putString("GiftTransCode",strTrasnCode);
        startActivity(new Intent(SchemeSwitchActivity.this, ReceiveGiftActivity.class)
                .putExtras(bundle));
        SchemeSwitchActivity.this.finish();
    }
}
