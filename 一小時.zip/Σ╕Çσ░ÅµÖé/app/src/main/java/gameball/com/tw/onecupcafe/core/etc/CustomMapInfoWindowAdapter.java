package gameball.com.tw.onecupcafe.core.etc;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.activities.StoreDetailActivity;

public class CustomMapInfoWindowAdapter implements GoogleMap.InfoWindowAdapter {
    private Activity context;

    public CustomMapInfoWindowAdapter(Activity context) {
        this.context = context;
    }

    @Override
    public View getInfoWindow(Marker marker) {
        return null;
    }

    @Override
    public View getInfoContents(Marker marker) {
        View view = context.getLayoutInflater().inflate(R.layout.item_cust_map_info_window, null);

        TextView tvMapMarkerTitle = (TextView) view.findViewById(R.id.tvMapMarkerTitle);
        TextView tvMapMarkerDesc = (TextView) view.findViewById(R.id.tvMapMarkerDesc);

        tvMapMarkerTitle.setText(marker.getTitle());
        tvMapMarkerDesc.setText(marker.getSnippet());
        tvMapMarkerDesc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.startActivity(new Intent(context, StoreDetailActivity.class));
            }
        });
        return view;
    }

}
