package gameball.com.tw.onecupcafe.fragments.setting;

import android.content.Context;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.constraint.Group;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.orhanobut.hawk.Hawk;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.core.base.BaseFragment;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResUserEmailBind;
import gameball.com.tw.onecupcafe.retrofit.ApiBase;
import gameball.com.tw.onecupcafe.retrofit.api.UserSignInSignUpApi;
import gameball.com.tw.onecupcafe.utils.ApiErrorMsgCallback;
import gameball.com.tw.onecupcafe.utils.Constants;
import gameball.com.tw.onecupcafe.utils.EmailValidUtil;
import gameball.com.tw.onecupcafe.utils.MD5Util;
import gameball.com.tw.onecupcafe.utils.ProgressBarCallBack;
import gameball.com.tw.onecupcafe.utils.ResStatusReturn;
import gameball.com.tw.onecupcafe.utils.TimeStampUtil;
import gameball.com.tw.onecupcafe.utils.ToastUtil;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BindEmailFragment extends BaseFragment {

    public static BindEmailFragment newInstance() {
        Bundle args = new Bundle();

        BindEmailFragment fragment = new BindEmailFragment();
        fragment.setArguments(args);
        return fragment;
    }

    private EditText etSettingBindEmail;
    private Button btnSettingBindEmail,btnBindEmailLater;
    private Group groupSettingBindEmail1;
    private View viewBindEmailCompelete;
    private CountDownTimer countDownTimer;
    private ProgressBarCallBack progressBarCallBack;
    private ApiErrorMsgCallback apiErrorMsgCallback;
    private TextView tvSignUpPhoneBindEmailUserMail;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_setting_bind_email, container, false);
        initView(view);
        return view;
    }

    private void initView(View v) {
        progressBarCallBack = (ProgressBarCallBack)getActivity();
        apiErrorMsgCallback = (ApiErrorMsgCallback)getActivity();

        groupSettingBindEmail1 = v.findViewById(R.id.groupSettingBindEmail1);
        viewBindEmailCompelete = v.findViewById(R.id.viewBindEmailCompelete);
        etSettingBindEmail = v.findViewById(R.id.etSettingBindEmail);

        btnSettingBindEmail = v.findViewById(R.id.btnSettingBindEmail);
        btnBindEmailLater = v.findViewById(R.id.btnBindEmailLater);

        tvSignUpPhoneBindEmailUserMail = v.findViewById(R.id.tvSignUpPhoneBindEmailUserMail);

        btnSettingBindEmail.setOnClickListener(this);
        btnBindEmailLater.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSettingBindEmail:
                String strEmail = etSettingBindEmail.getText().toString().trim();
                if(EmailValidUtil.isEmailValid(strEmail)){
                    apiBindEmail(strEmail);
                }else {
                    ToastUtil.showToastMsg(getString(R.string.sign_up_phone_complete_email_not_correct));
                }
                break;
            case R.id.btnBindEmailLater:
                getActivity().onBackPressed();
                break;
            default:
                break;
        }
    }

    @Override
    public void onStop() {
        super.onStop();
    }


    //todo
    //檔名：api_003.php 功能：設定信箱(登入流程 & 會員管理皆可引用)
    private void apiBindEmail(final String strEmail) {
        progressBarCallBack.showProgressBar();

        String strToken = Hawk.get(Constants.USER_ACCTOKEN);
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeyStr = MD5Util.MD5(Constants.SALT,strToken,strTimeStamp);

        Call<ResUserEmailBind> getBindEmail =
                ApiBase.instance().
                        create(UserSignInSignUpApi.class).
                        postUserEmailBind(
                                strToken,
                                strEmail,
                                strKeyStr,
                                strTimeStamp);

        getBindEmail.enqueue(new Callback<ResUserEmailBind>() {
            @Override
            public void onResponse(Call<ResUserEmailBind> call, Response<ResUserEmailBind> response) {

                String strApiRtnCode = response.body().getCode();

                if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {
                    groupSettingBindEmail1.setVisibility(View.GONE);
                    viewBindEmailCompelete.setVisibility(View.VISIBLE);
                    Hawk.put(Constants.USER_EMAIL,strEmail);
                    tvSignUpPhoneBindEmailUserMail.setText(strEmail);
                    closeSoftKeyboard(((ViewGroup) getView()).getFocusedChild());

                    countDownTimer = new CountDownTimer(3000,1000) {
                        @Override
                        public void onTick(long millisUntilFinished) {

                        }

                        @Override
                        public void onFinish() {
                            getActivity().onBackPressed();
                        }
                    }.start();
                }else{
                    apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                }

            }

            @Override
            public void onFailure(Call<ResUserEmailBind> call, Throwable t) {

            }
        });
        progressBarCallBack.hideProgressBar();
    }

    @Override
    public void onDestroy() {
        if(countDownTimer!=null){
            countDownTimer.cancel();
            countDownTimer = null;
        }
        super.onDestroy();
    }

    private void closeSoftKeyboard(View view) {
        if (getActivity() == null || view == null) {
            return;
        }
        int times = 0;
        boolean isClosed = false;
        InputMethodManager manager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        while (!isClosed && times <= 5) {
            times++;
            isClosed = manager.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
}
