package gameball.com.tw.onecupcafe.fragments.setting;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.orhanobut.hawk.Hawk;

import java.util.ArrayList;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.adapters.SettingOrderHistoryAdatper;
import gameball.com.tw.onecupcafe.core.base.BaseFragment;
import gameball.com.tw.onecupcafe.core.etc.RecycleViewLayoutManager;
import gameball.com.tw.onecupcafe.items.SettingPojo.OrderHistory;
import gameball.com.tw.onecupcafe.items.SettingPojo.ResGetUserOrderHistory;
import gameball.com.tw.onecupcafe.retrofit.ApiBase;
import gameball.com.tw.onecupcafe.retrofit.api.SettingApi;
import gameball.com.tw.onecupcafe.utils.ApiErrorMsgCallback;
import gameball.com.tw.onecupcafe.utils.Constants;
import gameball.com.tw.onecupcafe.utils.MD5Util;
import gameball.com.tw.onecupcafe.utils.ProgressBarCallBack;
import gameball.com.tw.onecupcafe.utils.ResStatusReturn;
import gameball.com.tw.onecupcafe.utils.TimeStampUtil;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OrderHistoryFragment extends BaseFragment {

    public static OrderHistoryFragment newInstance() {
        Bundle args = new Bundle();

        OrderHistoryFragment fragment = new OrderHistoryFragment();
        fragment.setArguments(args);
        return fragment;
    }

    public static final String TAG = "OrderHistory";
    private RecyclerView rvSettingOrderHistory;
    private SettingOrderHistoryAdatper settingOrderHistoryAdatper;
    private ArrayList<OrderHistory> arrOrderHistories = new ArrayList<>();
    private ProgressBarCallBack progressBarCallBack;
    private ApiErrorMsgCallback apiErrorMsgCallback;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_setting_order_history,container,false);
        initView(view);
        return view;
    }

    private void initView(View v){
        progressBarCallBack = (ProgressBarCallBack)getActivity();
        apiErrorMsgCallback = (ApiErrorMsgCallback)getActivity();

        rvSettingOrderHistory = (RecyclerView)v.findViewById(R.id.rvSettingOrderHistory);

        apiGetUserOrderHistory();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            default:
                break;
        }

    }

    //todo
    //檔名：api_501.php 功能：寄杯歷史記錄
    private void apiGetUserOrderHistory(){
        progressBarCallBack.showProgressBar();
        String strToken = Hawk.get(Constants.USER_ACCTOKEN);
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeystr = MD5Util.MD5(Constants.SALT,strToken,strTimeStamp);
        Call<ResGetUserOrderHistory> getSetSingleNotificationRead =
                ApiBase.instance().create(SettingApi.class).
                        postGetUserOrderHistory(
                                strToken,
                                "30",
                                "0",
                                strTimeStamp,
                                strKeystr
                );
        getSetSingleNotificationRead.enqueue(new Callback<ResGetUserOrderHistory>() {
            @Override
            public void onResponse(Call<ResGetUserOrderHistory> call, Response<ResGetUserOrderHistory> response) {
                String strApiRtnCode = response.body().getCode();
                if(ResStatusReturn.apiStatus(strApiRtnCode) == true){
                    Log.e(TAG, "onResponse: "+response.body().getCode()+";"+response.body().getMessage() +";"+response.body().getRetnObject());
                    if(response.body().getRetnObject()!=null){
                        arrOrderHistories = response.body().getRetnObject();
                        for (int i = 0 ; i <arrOrderHistories.size() ; i++){
                        }
                    }
                    setDataView();
                }else {
                    apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                }
            }

            @Override
            public void onFailure(Call<ResGetUserOrderHistory> call, Throwable t) {
                Log.e(TAG,t.toString());
            }
        });
        progressBarCallBack.hideProgressBar();
    }

    private void setDataView(){
        new RecycleViewLayoutManager(getActivity(), LinearLayoutManager.VERTICAL,rvSettingOrderHistory);
        settingOrderHistoryAdatper = new SettingOrderHistoryAdatper(getActivity(),arrOrderHistories);
        rvSettingOrderHistory.setAdapter(settingOrderHistoryAdatper);
    }


}
