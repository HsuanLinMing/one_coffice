package gameball.com.tw.onecupcafe.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.orhanobut.hawk.Hawk;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.fragments.login.SignUpFragment;
import gameball.com.tw.onecupcafe.utils.Constants;
import gameball.com.tw.onecupcafe.utils.FragmentSwitchCallback;
import gameball.com.tw.onecupcafe.utils.GlideImageUtil;
import gameball.com.tw.onecupcafe.utils.ProgressBarCallBack;
import gameball.com.tw.onecupcafe.utils.ProgressBarUtil;
import me.yokeyword.fragmentation.SupportActivity;

//LandingPage 與 註冊畫面

public class LandingSignUpActivity extends SupportActivity implements FragmentSwitchCallback, ProgressBarCallBack {
    private CountDownTimer countDownTimer;
    private ImageView ivLandingImage;
    private FrameLayout flSingUpConatiner;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing_sign_up_activity);
        ivLandingImage = (ImageView) findViewById(R.id.ivLandingImage);
        Glide.with(this).load(getResources().getDrawable(R.drawable.openning_background)).into(ivLandingImage);
        initCountDownTimer();
    }

    private void initCountDownTimer() {
        countDownTimer = new CountDownTimer(3000, 1500) {

            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
//                boolean isFirst = Hawk.get("isFirst",true);
//                if (isFirst == false || checkUserIsSignUp() == true ) {
                //如果有註冊進入主頁
                startActivity(new Intent(LandingSignUpActivity.this, HomeActivity.class));
                LandingSignUpActivity.this.finish();
//                } else {
//                    //如果沒有註冊進入註冊頁面
//                    initSignUpFragment();
//                }
            }

        };
        countDownTimer.start();
    }

    //註冊主頁
    private void initSignUpFragment() {
        progressBar = new ProgressBarUtil(this);
        ivLandingImage = findViewById(R.id.ivLandingImage);
        flSingUpConatiner = findViewById(R.id.flSingUpConatiner);
        ivLandingImage.setVisibility(View.GONE);
        flSingUpConatiner.setVisibility(View.VISIBLE);

        if (findFragment(SignUpFragment.class) == null) {
            loadRootFragment(R.id.flSingUpConatiner, SignUpFragment.newInstance());
        }
    }

    //判斷有無註冊
    private boolean checkUserIsSignUp() {
        String strUserEmail = Hawk.get(Constants.USER_EMAIL, Constants.USER_DEF_DATA);
        String strUserPhone = Hawk.get(Constants.USER_PHONE, Constants.USER_DEF_DATA);
        Log.e("Landing", strUserEmail + ":" + strUserPhone);
        //若兩者都為Default值就前往註冊頁面
        if (strUserEmail.equals(Constants.USER_DEF_DATA) && strUserPhone.equals(Constants.USER_DEF_DATA)) {
            return false;
        } else {
            return true;
        }
    }

    //為了facebook login , parent需取得存在的fragment並將result轉送至fragment
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //for facebook login call back
        for (Fragment fragment : getSupportFragmentManager().getFragments()) {
            fragment.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void setTargetFragment(String strTargetFragment) {
        switch (strTargetFragment) {
            case "HelpCenter"://客服中心
//                loadRootFragment(R.id.flSingUpConatiner, HelpCenterFragment.newInstance(), true, true);
                startActivity(new Intent(LandingSignUpActivity.this, HelpCenterActivity.class));

                break;
            default:
                break;
        }
    }

    private ProgressBarUtil progressBar;

    @Override
    public void showProgressBar() {
        progressBar.show();
    }

    @Override
    public void hideProgressBar() {
        progressBar.hide();
    }

}
