package gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo;

public class ResUserTokenRenew {
    String code;
    String message;
    ReturnData retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ReturnData getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(ReturnData retnObject) {
        this.retnObject = retnObject;
    }

    class ReturnData {
        String accToken;
        String expireTime;
        String newest_version;
        String upgrate;
        Bubble bubble;

        public String getAccToken() {
            return accToken;
        }

        public void setAccToken(String accToken) {
            this.accToken = accToken;
        }

        public String getExpireTime() {
            return expireTime;
        }

        public void setExpireTime(String expireTime) {
            this.expireTime = expireTime;
        }

        public String getNewest_version() {
            return newest_version;
        }

        public void setNewest_version(String newest_version) {
            this.newest_version = newest_version;
        }

        public String getUpgrate() {
            return upgrate;
        }

        public void setUpgrate(String upgrate) {
            this.upgrate = upgrate;
        }

        public Bubble getBubble() {
            return bubble;
        }

        public void setBubble(Bubble bubble) {
            this.bubble = bubble;
        }

        class Bubble {
            String storeList;
            String myOrderList;
            String photoList;
            String notify;
            String more;

            public String getStoreList() {
                return storeList;
            }

            public void setStoreList(String storeList) {
                this.storeList = storeList;
            }

            public String getMyOrderList() {
                return myOrderList;
            }

            public void setMyOrderList(String myOrderList) {
                this.myOrderList = myOrderList;
            }

            public String getPhotoList() {
                return photoList;
            }

            public void setPhotoList(String photoList) {
                this.photoList = photoList;
            }

            public String getNotify() {
                return notify;
            }

            public void setNotify(String notify) {
                this.notify = notify;
            }

            public String getMore() {
                return more;
            }

            public void setMore(String more) {
                this.more = more;
            }
        }
    }
}
