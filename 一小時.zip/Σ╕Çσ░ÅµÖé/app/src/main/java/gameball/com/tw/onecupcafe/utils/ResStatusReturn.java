package gameball.com.tw.onecupcafe.utils;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.design.widget.Snackbar;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import gameball.com.tw.onecupcafe.App;
import gameball.com.tw.onecupcafe.R;

public class ResStatusReturn {

    public static boolean apiStatus(String strApiReturnCode) {
//        showErrorAlertDialog(strApiReturnCode);
        boolean isCorrect = false;
        switch (strApiReturnCode) {
            case "000":
                isCorrect = true;
                break;
            default:
                isCorrect = false;
                break;
        }
        return isCorrect;
    }

//    public static String showErrorMessage(String strErrorCode) {
//        Log.e("API ERROR", "MSG:" + strErrorCode);
//        String strErrorMsg = "";
//        switch (strErrorCode){
//            case "101":
//                strErrorMsg = App.getInstance().getString(R.string.error_msg_101);
//                break;
//            case "102":
//                strErrorMsg = App.getInstance().getString(R.string.error_msg_102);
//                break;
//            case "103":
//                strErrorMsg = App.getInstance().getString(R.string.error_msg_103);
//                break;
//            case "104":
//                strErrorMsg = App.getInstance().getString(R.string.error_msg_104);
//                break;
//            case "105":
//                strErrorMsg = App.getInstance().getString(R.string.error_msg_105);
//                break;
//            case "106":
//                strErrorMsg = App.getInstance().getString(R.string.error_msg_106);
//                break;
//            case "107":
//                strErrorMsg = App.getInstance().getString(R.string.error_msg_107);
//                break;
//            case "109":
//                strErrorMsg = App.getInstance().getString(R.string.error_msg_109);
//                break;
//        }
//        return strErrorMsg;
//    }
}
