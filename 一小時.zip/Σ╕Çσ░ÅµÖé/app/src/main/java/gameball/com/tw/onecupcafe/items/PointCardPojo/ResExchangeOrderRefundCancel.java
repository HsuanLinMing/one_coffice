package gameball.com.tw.onecupcafe.items.PointCardPojo;

import java.io.Serializable;

public class ResExchangeOrderRefundCancel implements Serializable {
    String code;
    String message;
    ReturnData retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ReturnData getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(ReturnData retnObject) {
        this.retnObject = retnObject;
    }

    class ReturnData{
        String refundID;

        public String getRefundID() {
            return refundID;
        }

        public void setRefundID(String refundID) {
            this.refundID = refundID;
        }
    }
}
