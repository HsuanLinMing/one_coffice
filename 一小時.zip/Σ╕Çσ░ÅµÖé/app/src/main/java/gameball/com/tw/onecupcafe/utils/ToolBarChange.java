package gameball.com.tw.onecupcafe.utils;

public interface ToolBarChange {
    void setToolBarView(String strToolBarTag);
}
