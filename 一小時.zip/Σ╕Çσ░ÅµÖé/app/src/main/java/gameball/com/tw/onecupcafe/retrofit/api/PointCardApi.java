package gameball.com.tw.onecupcafe.retrofit.api;

import gameball.com.tw.onecupcafe.items.PointCardPojo.ResExchangeOrderCancel;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResExchangeOrderCheckStatus;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResExchangeOrderGift;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResExchangeOrderRedeem;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResExchangeOrderRefund;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResExchangeOrderRefundCancel;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResGetAllPointCardList;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResReceiveRejectGift;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResShareCancelFromOwner;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResShareGiftWithFriend;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * Created by sofasoso on 2018/3/31.
 */

public interface PointCardApi {

    //取得使用者寄杯資料
    //1. token: string, api_002回傳的accToken。
    //2. keyStr: string, 介面存取驗證字串md5(salt + accToken + timestamp)
    //3. timestamp: long, 呼叫API當下 timestamp
    //4. type: string, 訂單類型{ order, free, gift }
    //5. longitude: string, 使用者座標經度(非必填)
    //6. latitude: string, 使用者座標緯度(非必填)
    @POST("api_201.php")
    Call<ResGetAllPointCardList> postGetAllPointCardList(
            @Query("token") String token,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp,
            @Query("type") String type
//            @Query("longitude") String longitude,
//            @Query("latitude") String latitude
    );

    //提出寄杯商品兌換需求
    //1. token: string, api_002回傳的accToken。
    //2. orderID: string, 訂單編號
    //3. quantity : int, 兌換數量
    //4. keyStr : string, 介面存取驗證字串md5(salt + accToken + orderID + quantity +timestamp)
    //5. timestamp : long, 呼叫API當下 timestamp
    @POST("api_202.php")
    Call<ResExchangeOrderRedeem> postExchangeOrderRedeem(
            @Query("token") String token,
            @Query("redeemID") String redeemID,
            @Query("quantity") int quantity,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    //取消商品兌換需求
    //1. token: string, api_002回傳的accToken。
    //2. redeemID: string, 兌換編號
    //3. keyStr : string, 介面存取驗證字串md5(salt + accToken + redeemID + timestamp)
    //4. timestamp : long, 呼叫API當下 timestamp
    @POST("api_203.php")
    Call<ResExchangeOrderCancel> postExchangeOrderCancel(
            @Query("token") String token,
            @Query("transCode") String transCode,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    //贈送寄杯商品（分享字串至其他App)
    //1. token: string, api_002回傳的accToken。
    //2. orderID: string, 訂單編號
    //3. quantity : int, 贈送數量
    //4. keyStr : string, 介面存取驗證字串md5(salt + accToken + orderID + quantity + timestamp)
    //5. timestamp : long, 呼叫API當下 timestamp
    @POST("api_204.php")
    Call<ResExchangeOrderGift> postExchangeOrderGift(
            @Query("token") String token,
            @Query("orderID") String orderID,
            @Query("quantity") int quantity,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    //寄杯商品退貨
    //1. token: string, api_002回傳的accToken。
    //2. orderID: string, 訂單編號。
    //3. keyStr : string, 介面存取驗證字串md5(salt + accToken + orderID + timestamp)
    //4. timestamp : long, 呼叫API當下 timestamp
    @POST("api_205.php")
    Call<ResExchangeOrderRefund> postExchangeOrderRefund(
            @Query("token") String token,
            @Query("orderID") String orderID,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    //取消退貨
    //1. token: string, api_002回傳的accToken。
    //2. refundID: string, 取消訂單編號
    //3. keyStr : string, 介面存取驗證字串md5(salt + accToken + refundID + timestamp)
    //4. timestamp : long, 呼叫API當下 timestamp
    @POST("api_206.php")
    Call<ResExchangeOrderRefundCancel> postExchangeOrderRefundCancel(
            @Query("token") String token,
            @Query("transCode") String transCode,
            @Query("timestamp") String timestamp,
            @Query("keyStr") String keyStr
    );

//    狀態確認[api_207]
//    說明 顯示QR-code之後的狀態確認，每隔10秒鐘呼叫一次
//    API api_207.php
//    傳送參數 1. token: string, api_002回傳的accToken。
//            2. transCode: string,交易代碼
//            3. keyStr : string, 介面存取驗證字串md5(salt + accToken + transCode +timestamp)
//            4. timestamp : long, 呼叫API當下 timestamp
//    備註 transStatus為Y時，關閉QR-code顯示畫面並停止呼叫api_207，否則繼續顯示每隔10秒鐘呼叫一次api_207
    @POST("api_207.php")
    Call<ResExchangeOrderCheckStatus> postExchangeOrderCheckStatus(
            @Query("token") String token,
            @Query("transCode") String transCode,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    /*
    好友分享，分享序號確認[api_208]
    token: string, api_002回傳的accToken。
    giftCode: string,  禮物代碼
    keyStr : string, 介面存取驗證字串md5(salt + token + giftCode + timestamp)
    timestamp : long, 呼叫API當下 timestamp
     */
    @POST("api_208.php")
    Call<ResShareGiftWithFriend> postShareGiftWithFriend(
            @Query("token") String token,
            @Query("giftCode") String giftCode,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    /*
    好友分享，接收or婉拒 [api_209]
    token: string, api_002回傳的accToken。
    action: string,  執行動作 recive=接收 | return=婉拒(退還)
    transToken: string,  api_208回傳的transToken
    keyStr : string, 介面存取驗證字串md5(salt + token + timestamp)
    timestamp : long, 呼叫API當下 timestamp
     */
    @POST("api_209.php")
    Call<ResReceiveRejectGift> postReceiveRejectGift(
            @Query("token") String token,
            @Query("action") String action,
            @Query("transToken") String transToken,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    /*
    好友分享，自行收回 [api_210]
    token: string, api_002回傳的accToken。
    giftCode: string,
    keyStr : string, 介面存取驗證字串md5(salt + token + giftCode + timestamp)
    timestamp : long, 呼叫API當下 timestamp
     */
    @POST("api_210.php")
    Call<ResShareCancelFromOwner> postShareCancelFromOwner(
            @Query("token") String token,
            @Query("giftCode") String giftCode,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );
}
