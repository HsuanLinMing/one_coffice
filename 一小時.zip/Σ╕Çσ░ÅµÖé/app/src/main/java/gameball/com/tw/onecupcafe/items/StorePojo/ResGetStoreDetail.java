package gameball.com.tw.onecupcafe.items.StorePojo;

import java.io.Serializable;
import java.util.ArrayList;

public class ResGetStoreDetail implements Serializable {
    String code;
    String message;
    StoreDetailData retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public StoreDetailData getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(StoreDetailData retnObject) {
        this.retnObject = retnObject;
    }


}
