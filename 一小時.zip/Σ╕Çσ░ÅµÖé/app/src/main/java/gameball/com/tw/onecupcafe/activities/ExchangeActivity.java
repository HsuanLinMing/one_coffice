package gameball.com.tw.onecupcafe.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bigkoo.alertview.AlertView;
import com.bigkoo.alertview.OnDismissListener;
import com.bigkoo.alertview.OnItemClickListener;
import com.orhanobut.hawk.Hawk;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.fragments.exchange.ExchangeFreeFragment;
import gameball.com.tw.onecupcafe.fragments.exchange.ExchangeGiftFragment;
import gameball.com.tw.onecupcafe.fragments.exchange.ExchangeOrderFragment;
import gameball.com.tw.onecupcafe.fragments.exchange.ExchangeQrCodeFragment;
import gameball.com.tw.onecupcafe.fragments.exchange.ExchangeRefundFragment;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResExchangeOrderGift;
import gameball.com.tw.onecupcafe.items.PointCardPojo.StorePointCardList;
import gameball.com.tw.onecupcafe.items.StorePojo.StoreDetailData;
import gameball.com.tw.onecupcafe.retrofit.ApiBase;
import gameball.com.tw.onecupcafe.retrofit.api.PointCardApi;
import gameball.com.tw.onecupcafe.utils.ApiErrorMsgCallback;
import gameball.com.tw.onecupcafe.utils.Constants;
import gameball.com.tw.onecupcafe.utils.FragmentSwitchCallback;
import gameball.com.tw.onecupcafe.utils.GlideImageUtil;
import gameball.com.tw.onecupcafe.utils.MD5Util;
import gameball.com.tw.onecupcafe.utils.ProgressBarCallBack;
import gameball.com.tw.onecupcafe.utils.ProgressBarUtil;
import gameball.com.tw.onecupcafe.utils.ResStatusReturn;
import gameball.com.tw.onecupcafe.utils.TimeStampUtil;
import me.yokeyword.fragmentation.SupportActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

//負責各種QrCode畫面處理

public class ExchangeActivity extends SupportActivity implements View.OnClickListener, FragmentSwitchCallback, ProgressBarCallBack
        , ApiErrorMsgCallback {
    public static final String TAG = "ExchangeActivity";
    public String strPointCardTag, strStoreName, strQrCodeTag = "", strProdId, strOrderId = "",
            strPordTitle = "", strRedeemID = "", strRedeemCount = "1", strRemianQty;
    private TextView tvExchangePrev, tvExchangeStoreName;
    public StorePointCardList.StoreOrder orderData;
    public StoreDetailData.StoreProduct prodData;
    public int intGiftAmount;
    private ImageView ivExchangeStoreImg;
    private String strStoreMainImgUrl = "";


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitivity_exchange);
        Bundle getExtras = getIntent().getExtras();
        strPointCardTag = getExtras.getString("PointCardType");
        orderData = (StorePointCardList.StoreOrder) getExtras.getSerializable("OrderData");
        if (orderData != null) {
            Log.e(TAG, "OrderDataNotNull");
            strOrderId = orderData.getOrderID();
            strRedeemID = orderData.getRedeemID();
            strRemianQty = orderData.getRemianingQty();
            strPordTitle = orderData.getProdTitle();
        } else {
            Log.e(TAG, "OrderDataNull");
        }
        strStoreName = getExtras.getString("StoreName");
        try {
            strStoreMainImgUrl = getExtras.getString("StoreMainImgUrl");
        } catch (Exception e) {
            Log.e(TAG, "Image:"+strStoreMainImgUrl );
        }
        Log.e(TAG, strPointCardTag);
        switchPointCardDetailView();
        initView();
    }

    private void initView() {
        tvExchangePrev = (TextView) findViewById(R.id.tvExchangePrev);
        tvExchangeStoreName = (TextView) findViewById(R.id.tvExchangeStoreName);
        tvExchangePrev.setOnClickListener(this);
        tvExchangeStoreName.setText(strStoreName);
        progressBar = new ProgressBarUtil(this);
        ivExchangeStoreImg = (ImageView) findViewById(R.id.ivExchangeStoreImg);
        Log.e(TAG, "FromStoreDetail:" + strStoreMainImgUrl);
        new GlideImageUtil(ExchangeActivity.this, strStoreMainImgUrl, ivExchangeStoreImg, R.drawable.img_store_mid_default).LoadImageWithGlide();
    }

    //不同的QrCode類別會有不同的畫面處例
    private void switchPointCardDetailView() {
        switch (strPointCardTag) {
            //自己購買
            case "redeem":
                if (findFragment(ExchangeOrderFragment.class) == null) {
                    loadRootFragment(R.id.flExchangeContainer, ExchangeOrderFragment.newInstance());
                }
                break;
            //禮物
            case "gift":
                if (findFragment(ExchangeGiftFragment.class) == null) {
                    loadRootFragment(R.id.flExchangeContainer, ExchangeGiftFragment.newInstance());
                }
                break;
            //店家免費
            case "free":
                if (findFragment(ExchangeFreeFragment.class) == null) {
                    loadRootFragment(R.id.flExchangeContainer, ExchangeFreeFragment.newInstance());
                }
                break;
            //從店家詳細資料點擊進qr code
            case "storeOrder":
                prodData = (StoreDetailData.StoreProduct) getIntent().getExtras().getSerializable("ProdData");
//                strProdId = getIntent().getExtras().getString("ProdId");
                strProdId = prodData.getProdID();
                Log.e(TAG,"ProdId:"+strProdId);
                if (findFragment(ExchangeQrCodeFragment.class) == null) {
                    loadRootFragment(R.id.flExchangeContainer, ExchangeQrCodeFragment.newInstance(), true, true);
                }
                break;
            //從購買記錄中再次購買
            case "HistoryBuy":
                if (findFragment(ExchangeOrderFragment.class) == null) {
                    Bundle getExtras = getIntent().getExtras();
                    strOrderId = getExtras.getString("OrderId");
                    loadRootFragment(R.id.flExchangeContainer, ExchangeQrCodeFragment.newInstance());
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tvExchangePrev:
                onBackPressed();
                break;
            default:
                break;
        }
    }

    @Override
    public void setTargetFragment(String strFragmentTag) {
        switch (strFragmentTag) {
            case "OrderShare":
                apiExchangeOrderGift(strOrderId, intGiftAmount);
                break;
            case "OrderExchange":
                if (findFragment(ExchangeQrCodeFragment.class) == null) {
                    strQrCodeTag = "OrderExchange";
                    loadRootFragment(R.id.flExchangeContainer, ExchangeQrCodeFragment.newInstance(), true, true);
                }
                break;
            case "OrderRefund":
                if (findFragment(ExchangeRefundFragment.class) == null) {
                    loadRootFragment(R.id.flExchangeContainer, ExchangeRefundFragment.newInstance(), true, true);
                }
                break;
            case "FreeExchange":
                if (findFragment(ExchangeQrCodeFragment.class) == null) {
                    strQrCodeTag = "FreeExchange";
                    loadRootFragment(R.id.flExchangeContainer, ExchangeQrCodeFragment.newInstance(), true, true);
                }
                break;
            case "GiftExchange":
                if (findFragment(ExchangeQrCodeFragment.class) == null) {
                    strQrCodeTag = "GiftExchange";
                    loadRootFragment(R.id.flExchangeContainer, ExchangeQrCodeFragment.newInstance(), true, true);
                }
                break;
            case "RefundExchange":
                if (findFragment(ExchangeQrCodeFragment.class) == null) {
                    strQrCodeTag = "RefundExchange";
                    loadRootFragment(R.id.flExchangeContainer, ExchangeQrCodeFragment.newInstance(), true, true);
                }
                break;
            default:
                break;
        }
    }


    //todo
    //檔名：api_204.php 功能：贈送寄杯商品（分享字串至其他App）
    private void apiExchangeOrderGift(String strOrderId, int intQuantity) {

//        4. keyStr : string, 介面存取驗證字串md5(salt + accToken + orderID + quantity +
//                timestamp)
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strToken = Hawk.get(Constants.USER_ACCTOKEN);
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken + strOrderId + intQuantity, strTimeStamp);
        progressBar.show();
        Call<ResExchangeOrderGift> getExchangeOrderGift =
                ApiBase.instance().create(PointCardApi.class).
                        postExchangeOrderGift(
                                strToken,
                                strOrderId,
                                intQuantity,
                                strKeyStr,
                                strTimeStamp);

        Log.e(TAG, "GiftToken:" + strToken);
        Log.e(TAG, "GiftOrderId:" + strOrderId);
        Log.e(TAG, "GiftQuan:" + intQuantity);
        Log.e(TAG, "GiftKeyStr:" + strKeyStr);
        Log.e(TAG, "GiftTimestamp:" + strTimeStamp);
        getExchangeOrderGift.enqueue(new Callback<ResExchangeOrderGift>() {
            @Override
            public void onResponse(Call<ResExchangeOrderGift> call, Response<ResExchangeOrderGift> response) {

                if (ResStatusReturn.apiStatus(response.body().getCode()) == true) {
                    String strShareContent = response.body().getRetnObject().getGiftCode() + "\n" +
                            response.body().getRetnObject().getMessage() + "\n" +
                            response.body().getRetnObject().getUrl();
                    setShareDialog(strShareContent);
                }
            }

            @Override
            public void onFailure(Call<ResExchangeOrderGift> call, Throwable t) {
            }
        });
        progressBar.hide();
    }

    private void setShareDialog(final String strShareContent) {
        new AlertView("分享須知"
                , "分享期間商品所有權仍歸屬您(原購買人)，當您辦理退貨時，將連同好友未兌換的數量一併退貨。"
                , "取消"
                , new String[]{"確定"}
                , null
                , this
                , AlertView.Style.Alert,
                new OnItemClickListener() {
                    @Override
                    public void onItemClick(Object o, int position) {
                        if (position == 0) {
//                            if (findFragment(ExchangeQrCodeFragment.class) == null) {
//                                loadRootFragment(R.id.flExchangeContainer, ExchangeQrCodeFragment.newInstance());
//                            }
                            sendShareContent(strShareContent);
                        }
                    }
                })
                .setCancelable(true)
                .setOnDismissListener(new OnDismissListener() {
                    @Override
                    public void onDismiss(Object o) {

                    }
                }).show();
    }

    //分享給朋友的內容
    private void sendShareContent(String strPointCardTag) {
        Intent sendIntent = new Intent();
        sendIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
        sendIntent.setFlags(Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, strPointCardTag);
        sendIntent.setType("text/plain");
        // startActivity(Intent.createChooser(sendIntent,
        // retnObject.get("info").getAsString() + "\n" +
        // "註：" + retnObject.get("remark").getAsString()));
        startActivity(sendIntent);
    }

    private ProgressBarUtil progressBar;

    @Override
    public void showProgressBar() {
        progressBar.show();
    }

    @Override
    public void hideProgressBar() {
        progressBar.hide();
    }


    @Override
    public void showErrorMsg(String strErrorCode) {
//        String strErrorMsg = "";
//        switch (strErrorCode) {
//            case "101":
//                strErrorMsg = getString(R.string.error_msg_101);
//                break;
//            case "102":
//                strErrorMsg = getString(R.string.error_msg_102);
//                break;
//            case "103":
//                strErrorMsg = getString(R.string.error_msg_103);
//                break;
//            case "104":
//                strErrorMsg = getString(R.string.error_msg_104);
//                break;
//            case "105":
//                strErrorMsg = getString(R.string.error_msg_105);
//                break;
//            case "106":
//                strErrorMsg = getString(R.string.error_msg_106);
//                break;
//            case "107":
//                strErrorMsg = getString(R.string.error_msg_107);
//                break;
//            case "109":
//                strErrorMsg = getString(R.string.error_msg_109);
//                break;
//        }
//        showErrorAlertDialog(strErrorMsg);
        showErrorAlertDialog(strErrorCode);
    }

    private AlertDialog.Builder builder;
    private void showErrorAlertDialog(final String strMsgInfo) {
        Log.e("API ERROR", "MSG:" + strMsgInfo);
        if (builder == null) {
            builder = new AlertDialog.Builder(ExchangeActivity.this);
            builder.setTitle("發生錯誤");
            builder.setMessage(strMsgInfo);
            builder.setCancelable(false);
            builder.setPositiveButton("確認", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    builder = null;
                    if(strMsgInfo.equals("商品數量不足")){
                        ExchangeActivity.this.finish();
                    }
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }
}
