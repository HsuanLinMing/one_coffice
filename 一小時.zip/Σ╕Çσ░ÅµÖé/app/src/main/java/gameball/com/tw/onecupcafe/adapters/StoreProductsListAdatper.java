package gameball.com.tw.onecupcafe.adapters;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.makeramen.roundedimageview.RoundedImageView;
import com.orhanobut.hawk.Hawk;

import java.io.Serializable;
import java.util.ArrayList;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.activities.ExchangeActivity;
import gameball.com.tw.onecupcafe.activities.StoreDetailActivity;
import gameball.com.tw.onecupcafe.items.PointCardPojo.StorePointCardList;
import gameball.com.tw.onecupcafe.items.StorePojo.StoreDetailData;
import gameball.com.tw.onecupcafe.utils.Constants;
import gameball.com.tw.onecupcafe.utils.GlideImageUtil;

/**
 * Created by sofasoso on 2018/4/1.
 */

public class StoreProductsListAdatper extends RecyclerView.Adapter<StoreProductsListAdatper.ViewHoler> {
    private Context context;
    private ArrayList<StoreDetailData.StoreProduct> data;

    public StoreProductsListAdatper(Context context, ArrayList<StoreDetailData.StoreProduct> data) {
        this.context = context;
        this.data = data;
    }

    public class ViewHoler extends RecyclerView.ViewHolder {
        private TextView tvStoreDetailProductTitle,tvStoreDetailProductDesc,tvStoreDetailProductPrice,tvStoreDetailProductTimeLimit,tvStoreDetailProductAmountDesc;
        private RoundedImageView rivStoreDetailProductImg;
        private Button btnStoreDetailProductBuy;
        private ImageView ivPlatformReturn , ivStoreReturn;
        public ViewHoler(View v) {
            super(v);
            tvStoreDetailProductTitle = (TextView) v.findViewById(R.id.tvStoreDetailProductTitle);
            tvStoreDetailProductDesc = (TextView) v.findViewById(R.id.tvStoreDetailProductDesc);
            tvStoreDetailProductPrice = (TextView) v.findViewById(R.id.tvStoreDetailProductPrice);
            tvStoreDetailProductTimeLimit = (TextView) v.findViewById(R.id.tvStoreDetailProductTimeLimit);
            tvStoreDetailProductAmountDesc = (TextView) v.findViewById(R.id.tvStoreDetailProductAmountDesc);
            btnStoreDetailProductBuy = (Button) v.findViewById(R.id.btnStoreDetailProductBuy);

            rivStoreDetailProductImg = (RoundedImageView) v.findViewById(R.id.rivStoreDetailProductImg);

            ivPlatformReturn = (ImageView) v.findViewById(R.id.ivPlatformReturn);
            ivStoreReturn = (ImageView) v.findViewById(R.id.ivStoreReturn);
        }
    }

    @NonNull
    @Override
    public ViewHoler onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_store_detail_products, parent, false);
        ViewHoler viewHoler = new ViewHoler(v);
        return viewHoler;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHoler holder, int position) {
        final StoreDetailData.StoreProduct productData = data.get(position);
        Log.e("StoreDetailProductList", "position"+position+":"+
                productData.getProdTitle()+";"+
                productData.getQtyPerSet()+";"+
                productData.getSalePrice()+";"+
                productData.getExpDate()+";"+
                productData.getSubTitle()
        );
        holder.tvStoreDetailProductTitle.setText(productData.getProdTitle());
        holder.tvStoreDetailProductAmountDesc.setText(productData.getQtyPerSet());
        holder.tvStoreDetailProductPrice.setText(productData.getSalePrice());
        holder.tvStoreDetailProductTimeLimit.setText(productData.getExpDate());
        holder.tvStoreDetailProductDesc.setText(productData.getSubTitle());

        new GlideImageUtil(context,
                productData.getProdImage(),
                holder.rivStoreDetailProductImg,
                R.drawable.img_product_sml_default).LoadImageWithGlide();

        holder.btnStoreDetailProductBuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!Hawk.get(Constants.USER_ACCTOKEN, Constants.USER_DEF_DATA).equals(Constants.USER_DEF_DATA)) {
                    Bundle bundle = new Bundle();
                    bundle.putString("PointCardType", "storeOrder");
                    bundle.putString("StoreName", ((StoreDetailActivity) context).strStoreName);
                    bundle.putString("ProdId", productData.getProdID());
                    bundle.putString("StoreMainImgUrl",((StoreDetailActivity) context).strStoreImgUrl);
                    bundle.putSerializable("ProdData", productData);
                    context.startActivity(new Intent(context, ExchangeActivity.class).putExtras(bundle));
                }else{
                    ((StoreDetailActivity)context).viewPlzLogin.setVisibility(View.VISIBLE);
                    ((StoreDetailActivity)context).groupStoreDetailMain.setVisibility(View.GONE);
                    ((StoreDetailActivity)context).groupStoreDetailProduct.setVisibility(View.GONE);
                }

            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }
}
