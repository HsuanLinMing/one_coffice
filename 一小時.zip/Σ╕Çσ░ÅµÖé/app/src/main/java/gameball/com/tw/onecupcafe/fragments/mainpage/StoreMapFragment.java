package gameball.com.tw.onecupcafe.fragments.mainpage;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.util.ArrayList;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.activities.HomeActivity;
import gameball.com.tw.onecupcafe.activities.StoreDetailActivity;
import gameball.com.tw.onecupcafe.core.base.BaseFragment;
import gameball.com.tw.onecupcafe.core.etc.CustomMapInfoWindowAdapter;
import gameball.com.tw.onecupcafe.items.StorePojo.StoreData;
import gameball.com.tw.onecupcafe.utils.PermissionCallBack;
import gameball.com.tw.onecupcafe.utils.PermissionHelper;
import gameball.com.tw.onecupcafe.utils.ProgressBarCallBack;

/**
 * Created by sofasoso on 2018/3/31.
 */

public class StoreMapFragment extends BaseFragment implements OnMapReadyCallback, GoogleMap.OnInfoWindowClickListener {


    public static StoreMapFragment newInstance() {
        Bundle args = new Bundle();

        StoreMapFragment fragment = new StoreMapFragment();
        fragment.setArguments(args);
        return fragment;
    }

    private SupportMapFragment mapFragment;
    private PermissionHelper permissionHelper;
    private HomeActivity homeActivity;
    private ArrayList<StoreData> arrStoredData = new ArrayList<>();
    public static final String TAG = "StoreMap";
    private ProgressBarCallBack progressBarCallBack;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_store_map, container, false);
        initView(view);
        return view;
    }

    GoogleMap map;

    void initView(View view) {
        homeActivity = (HomeActivity) getActivity();
        arrStoredData = homeActivity.arrHomeStoredData;
        progressBarCallBack = (ProgressBarCallBack) getActivity();
        progressBarCallBack.showProgressBar();
        //Delay加載Google Map 讓fragment變流暢 在app第一次載入google map都會比較慢 因為要check google map api的pacage
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mapFragment == null) {
                    mapFragment = SupportMapFragment.newInstance();
                    mapFragment.getMapAsync(StoreMapFragment.this);

                    // R.id.map is a FrameLayout, not a Fragment
                    getChildFragmentManager().beginTransaction().replace(R.id.mvStoreMap, mapFragment).commit();
                }
            }
        }, 400);

    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        progressBarCallBack.hideProgressBar();
        map = googleMap;
        map.getUiSettings().setZoomControlsEnabled(true);

        permissionHelper = new PermissionHelper();
        permissionHelper.request(this, new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION},
                new PermissionCallBack() {
                    @Override
                    public void onRequestPermissionsResult(boolean grant) {
                    }
                });

        //我的位置
        try {
            map.setMyLocationEnabled(true);
        } catch (Exception e) {

        }

        if (map != null) {

            addMapMarker(googleMap);
        }

    }

    void addMapMarker(GoogleMap map) {
        CustomMapInfoWindowAdapter customMapInfoWindowAdapter = new CustomMapInfoWindowAdapter(getActivity());
        map.setInfoWindowAdapter(customMapInfoWindowAdapter);
        map.setOnInfoWindowClickListener(this);

        Log.e(TAG, "StoreSize:" + arrStoredData.size());

        for (int i = 0; i < arrStoredData.size(); i++) {
            StoreData storeData = arrStoredData.get(i);
            Log.e(TAG, "StoreData" + i + ":" + storeData.getStoreName() + ";" + storeData.getLatitude() + "-" + storeData.getLongitude());
            LatLng latLng = new LatLng(Double.valueOf(storeData.getLatitude()), Double.valueOf(storeData.getLongitude()));

            Marker marker = map.addMarker(new MarkerOptions()
                    .position(latLng)
                    .title(storeData.getStoreName())
                    .snippet(storeData.getStoreAddr() + "\n" +
                            storeData.getStoreTel())
                    .icon(BitmapDescriptorFactory.fromBitmap(
                            bitmapSizeByScall(BitmapFactory.decodeResource(getResources()
                                    , R.drawable.ico_map_marker), (float) 0.5))));
            marker.setTag(i);
        }
        //移動地圖視窗
//        map.getMyLocation()
        if (homeActivity.numUserLat != 0) {
            map.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(homeActivity.numUserLat, homeActivity.numUserLng), 15));
        } else {
//            map.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(25.048869, 121.514245), 15));
            setMyLoacation(map);
        }

    }

    //客制google map marker
    public Bitmap bitmapSizeByScall(Bitmap bitmapIn, float scall_zero_to_one_f) {
        Bitmap bitmapOut = Bitmap.createScaledBitmap(bitmapIn,
                Math.round(bitmapIn.getWidth() * scall_zero_to_one_f),
                Math.round(bitmapIn.getHeight() * scall_zero_to_one_f), false);

        return bitmapOut;
    }

    @Override
    public void onInfoWindowClick(Marker marker) {
        //todo click google map marker後至店家詳細頁面
        Log.e(TAG, "onInfoWindowClick: " + marker.getTag().toString());
        Log.e(TAG, "ClickStoreData:" + arrStoredData.get(Integer.parseInt(marker.getTag().toString())).getStoreName());
        getActivity().startActivity(new Intent(getActivity(), StoreDetailActivity.class).putExtra(
                "StoreId", arrStoredData.get(Integer.parseInt(marker.getTag().toString())).getStorePK()
        ));
    }

    private void setMyLoacation(GoogleMap map) {
        if (ActivityCompat.checkSelfPermission(getActivity(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        } else {
            LocationManager lm = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
            Location myLocation = lm.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);

            if (myLocation == null) {
                Criteria criteria = new Criteria();
                criteria.setAccuracy(Criteria.ACCURACY_COARSE);
                String provider = lm.getBestProvider(criteria, true);
                myLocation = lm.getLastKnownLocation(provider);
            }

            if (myLocation != null) {
                LatLng userLocation = new LatLng(myLocation.getLatitude(), myLocation.getLongitude());
                Log.e(TAG,"Lat:"+userLocation.latitude+";Lng:"+userLocation.longitude);
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(userLocation.latitude,userLocation.longitude), 15));
            }
        }

    }
}
