package gameball.com.tw.onecupcafe.items.PointCardPojo;

public class ResExchangeOrderCheckStatus {
    public String code;
    public String message;
    public RetnObject retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public RetnObject getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(RetnObject retnObject) {
        this.retnObject = retnObject;
    }

    public class RetnObject{
        String transStatus;

        public String getTransStatus() {
            return transStatus;
        }

        public void setTransStatus(String transStatus) {
            this.transStatus = transStatus;
        }
    }
}
