package gameball.com.tw.onecupcafe.fragments.exchange;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.eralp.circleprogressview.CircleProgressView;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.activities.ExchangeActivity;
import gameball.com.tw.onecupcafe.core.base.BaseFragment;
import gameball.com.tw.onecupcafe.items.PointCardPojo.StorePointCardList;
import gameball.com.tw.onecupcafe.utils.FragmentSwitchCallback;
import gameball.com.tw.onecupcafe.utils.GlideImageUtil;

public class ExchangeOrderFragment extends BaseFragment {

    public static final String TAG = "ExchangeOrder";

    private Button btnExchangeOrderAmountSub, btnExchangeOrderAmountAdd, btnExchangeOrderGift, btnExchangeOrderConfirm, btnExchangeOrderRefund;
    public FragmentSwitchCallback callback;
    private ImageView ivExchangeOrderRefund, rivExchangeOrderImg;
    private StorePointCardList.StoreOrder orderData;
    private TextView tvExchangeOrderTitle, tvExchangeOrderAmount, tvExchangeOrderExchangeNum, tvExchangeOrderShareNum, tvExchangeOrderRemainingNum;
    private int intOrdeRemain, intCalcuRemaing = 1;
    private String strPointCardTag;
    private CircleProgressView cpvExchangeOrderPercent;
    private LinearLayout llExchangeOrderRefund;

    public static ExchangeOrderFragment newInstance() {
        Bundle args = new Bundle();
        ExchangeOrderFragment fragment = new ExchangeOrderFragment();
        fragment.setArguments(args);
        return fragment;
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_exchange_order, container, false);
        callback = (FragmentSwitchCallback) getActivity();
        initView(view);
        return view;
    }

    private void initView(View v) {
        orderData = ((ExchangeActivity) getActivity()).orderData;
        strPointCardTag = ((ExchangeActivity) getActivity()).strPointCardTag;

        btnExchangeOrderAmountSub = (Button) v.findViewById(R.id.btnExchangeOrderAmountSub);
        btnExchangeOrderAmountAdd = (Button) v.findViewById(R.id.btnExchangeOrderAmountAdd);
        btnExchangeOrderGift = (Button) v.findViewById(R.id.btnExchangeOrderGift);
        btnExchangeOrderConfirm = (Button) v.findViewById(R.id.btnExchangeOrderConfirm);

        btnExchangeOrderAmountSub.setOnClickListener(this);
        btnExchangeOrderAmountAdd.setOnClickListener(this);
        btnExchangeOrderGift.setOnClickListener(this);
        btnExchangeOrderConfirm.setOnClickListener(this);

        rivExchangeOrderImg = v.findViewById(R.id.rivExchangeOrderImg);

//        ivExchangeOrderRefund = (ImageView) v.findViewById(R.id.ivExchangeOrderRefund);
//        ivExchangeOrderRefund.setOnClickListener(this);

        cpvExchangeOrderPercent = v.findViewById(R.id.cpvExchangeOrderPercent);

        tvExchangeOrderTitle = (TextView) v.findViewById(R.id.tvExchangeOrderTitle);
        tvExchangeOrderAmount = (TextView) v.findViewById(R.id.tvExchangeOrderAmount);
        tvExchangeOrderRemainingNum = (TextView) v.findViewById(R.id.tvExchangeOrderRemainingNum);
        tvExchangeOrderExchangeNum = (TextView) v.findViewById(R.id.tvExchangeOrderExchangeNum);
        tvExchangeOrderShareNum = (TextView) v.findViewById(R.id.tvExchangeOrderShareNum);

        llExchangeOrderRefund = (LinearLayout) v.findViewById(R.id.llExchangeOrderRefund);
        llExchangeOrderRefund.setOnClickListener(this);
        setViewData();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnExchangeOrderAmountSub:
                if (intCalcuRemaing > 0) {
                    intCalcuRemaing = intCalcuRemaing - 1;
                }
                tvExchangeOrderAmount.setText("" + intCalcuRemaing);
                break;
            case R.id.btnExchangeOrderAmountAdd:
                if (intCalcuRemaing < intOrdeRemain) {
                    intCalcuRemaing = intCalcuRemaing + 1;
                }
                tvExchangeOrderAmount.setText("" + intCalcuRemaing);
                break;
            case R.id.btnExchangeOrderGift:
                ((ExchangeActivity)getActivity()).intGiftAmount = intCalcuRemaing;
                callback.setTargetFragment("OrderShare");
                break;
            case R.id.btnExchangeOrderConfirm:
                ((ExchangeActivity)getActivity()).strRedeemCount = tvExchangeOrderAmount.getText().toString();
                callback.setTargetFragment("OrderExchange");
                break;
            case R.id.llExchangeOrderRefund:
                callback.setTargetFragment("OrderRefund");
                break;
            default:
                break;
        }
    }

    private void setViewData() {
        if (!strPointCardTag.equals("HistoryBuy")) {
            intOrdeRemain = Integer.parseInt(orderData.remianingQty);
            Log.e(TAG, strPointCardTag);
//        if (strPointCardTag.equals("storeOrder")) {
            tvExchangeOrderTitle.setText(orderData.getProdTitle());
            tvExchangeOrderAmount.setText(String.valueOf(intCalcuRemaing));
            tvExchangeOrderExchangeNum.setText(orderData.redeemQty);
            tvExchangeOrderShareNum.setText(orderData.sharedQty);
            tvExchangeOrderRemainingNum.setText(orderData.remianingQty);
//        }
            new GlideImageUtil(getActivity(),
                    orderData.prodImage1,
                    rivExchangeOrderImg,
                    R.drawable.img_product_big_default).LoadImageWithGlide();
            //百分比
            float cpvPercent = ((Integer.parseInt(orderData.getTotalQty())-Integer.parseInt(orderData.getRemianingQty())) * 100 / Integer.parseInt(orderData.getTotalQty()));
            Log.e(TAG,"CpvPercent:"+cpvPercent);
            cpvExchangeOrderPercent.setStartAngle(270);
            cpvExchangeOrderPercent.setProgressWithAnimation(cpvPercent, 1000);
        }
    }
}
