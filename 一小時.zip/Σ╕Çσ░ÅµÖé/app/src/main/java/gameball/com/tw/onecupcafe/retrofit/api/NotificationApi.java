package gameball.com.tw.onecupcafe.retrofit.api;

import gameball.com.tw.onecupcafe.items.NotificationPojo.ResCleanAllNotifications;
import gameball.com.tw.onecupcafe.items.NotificationPojo.ResGetAllNotifications;
import gameball.com.tw.onecupcafe.items.NotificationPojo.ResSetAllNotificationsRead;
import gameball.com.tw.onecupcafe.items.NotificationPojo.ResSetSingleNotificationRead;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * Created by sofasoso on 2018/3/31.
 */

public interface NotificationApi {

    //取得所有訊息中心的資訊
    //1. token: string, api_002回傳的accToken。
    //2. keyStr: string, 介面存取驗證字串md5(salt + accToken + timestamp)
    //3. timestamp: long, 呼叫API當下 timestamp
    @POST("api_401.php")
    Call<ResGetAllNotifications> postGetAllNotifications(
            @Query("token") String token,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    //清除會員所有的推播訊息
    //1. token: string, api_002回傳的accToken。
    //2. keyStr: string, 介面存取驗證字串md5(salt + accToken + timestamp)
    //3. timestamp: long, 呼叫API當下 timestamp
    @POST("api_402.php")
    Call<ResCleanAllNotifications> postCleanAllNotifications(
            @Query("token") String token,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    //將會員所有推播設定為已讀
    //1. token: string, api_002回傳的accToken。
    //2. keyStr: string, 介面存取驗證字串md5(salt + accToken + timestamp)
    //3. timestamp: long, 呼叫API當下 timestamp
    @POST("api_403.php")
    Call<ResSetAllNotificationsRead> postSetAllNotificationsRead(
            @Query("token") String token,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

    //將會員單一指定推播設定為已讀
    //1. token: string, api_002回傳的accToken。
    //2. notifyID: string, api_401的訊息id
    //3. keyStr: string, 介面存取驗證字串md5(salt + accToken + notifyID + timestamp)
    //4. timestamp: long, 呼叫API當下 timestamp
    @POST("api_404.php")
    Call<ResSetSingleNotificationRead> postSetSingleNotificationRead(
            @Query("token") String token,
            @Query("notifyID") String notifyID,
            @Query("keyStr") String keyStr,
            @Query("timestamp") String timestamp
    );

}
