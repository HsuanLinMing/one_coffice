package gameball.com.tw.onecupcafe.retrofit;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

public class RedirectionInfoDeserializer implements JsonDeserializer<RedirectionInfo> {

    private static final String code = "code";
    private static final String message = "message";
    private static final String retnObject = "retnObject";

    @Override
    public RedirectionInfo deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        final JsonObject jsonObject = json.getAsJsonObject();

        // Read simple String values.
        final String uri = jsonObject.get(code).getAsString();
        final String httpMethod = jsonObject.get(message).getAsString();

        // Read the dynamic parameters object.
        final Map<String, String> parameters = readParametersMap(jsonObject);

        RedirectionInfo result = new RedirectionInfo();
        result.setCode(code);
        result.setMessage(message);
        result.setRetnObject(parameters);
        return result;
    }

    @Nullable
    private Map<String, String> readParametersMap(@NonNull final JsonObject jsonObject) {
        final JsonElement paramsElement = jsonObject.get(retnObject);
        if (paramsElement == null) {
            // value not present at all, just return null
            return null;
        }

        final JsonObject parametersObject = paramsElement.getAsJsonObject();
        final Map<String, String> parameters = new HashMap<>();
        for (Map.Entry<String, JsonElement> entry : parametersObject.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue().getAsString();
            parameters.put(key, value);
        }
        return parameters;
    }
}