package gameball.com.tw.onecupcafe.utils;

import android.content.Context;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;

import gameball.com.tw.onecupcafe.R;

public class GlideImageUtil {
    private Context imageContext;
    private String imageUrl;
    private ImageView imageView;
    private int errorImg;

    public GlideImageUtil(Context imageContext, String imageUrl, ImageView imageView, int errorImg) {
        this.imageContext = imageContext;
        this.imageUrl = imageUrl;
        this.imageView = imageView;
        this.errorImg = errorImg;
    }

    public void LoadImageWithGlide() {
        RequestOptions options = new RequestOptions()
                .placeholder(errorImg)
                .error(errorImg)
                .centerCrop()
                .fitCenter()
                .diskCacheStrategy(DiskCacheStrategy.ALL);
        Glide.with(imageContext)
                .load(imageUrl)
                .apply(options)
                .into(imageView);
    }
}
