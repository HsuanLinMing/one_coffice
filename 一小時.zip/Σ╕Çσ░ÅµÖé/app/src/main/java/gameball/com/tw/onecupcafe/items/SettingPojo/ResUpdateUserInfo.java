package gameball.com.tw.onecupcafe.items.SettingPojo;

import java.io.Serializable;

public class ResUpdateUserInfo implements Serializable {
    public String code;
    public String message;
    public RetnObject retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public RetnObject getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(RetnObject retnObject) {
        this.retnObject = retnObject;
    }

    public class RetnObject {
        public String uid;

        public String getUid() {
            return uid;
        }

        public void setUid(String uid) {
            this.uid = uid;
        }
    }
}
