package gameball.com.tw.onecupcafe.retrofit.api;

import retrofit2.Call;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * Created by sofasoso on 2018/3/31.
 */

public interface ShareImgApi {

    //POST METHOD
    @POST("api/123")
    Call<Void> postSample1(@Query("params") String params);
}
