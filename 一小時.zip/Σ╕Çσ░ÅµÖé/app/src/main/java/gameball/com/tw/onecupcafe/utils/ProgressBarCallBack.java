package gameball.com.tw.onecupcafe.utils;

public interface ProgressBarCallBack {
    void showProgressBar();

    void hideProgressBar();
}
