package gameball.com.tw.onecupcafe.fragments.login;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.heetch.countrypicker.Country;
import com.heetch.countrypicker.CountryPickerCallbacks;
import com.heetch.countrypicker.CountryPickerDialog;
import com.orhanobut.hawk.Hawk;


import java.util.Locale;

import gameball.com.tw.onecupcafe.App;
import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.activities.HelpCenterActivity;
import gameball.com.tw.onecupcafe.activities.HomeActivity;
import gameball.com.tw.onecupcafe.activities.SettingPageActivity;
import gameball.com.tw.onecupcafe.core.base.BaseFragment;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResUserCertified;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResUserEmailBind;
import gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo.ResUserInputInfo;
import gameball.com.tw.onecupcafe.retrofit.ApiBase;
import gameball.com.tw.onecupcafe.retrofit.api.UserSignInSignUpApi;
import gameball.com.tw.onecupcafe.utils.ApiErrorMsgCallback;
import gameball.com.tw.onecupcafe.utils.Constants;
import gameball.com.tw.onecupcafe.utils.EmailValidUtil;
import gameball.com.tw.onecupcafe.utils.MD5Util;
import gameball.com.tw.onecupcafe.utils.ProgressBarCallBack;
import gameball.com.tw.onecupcafe.utils.ResStatusReturn;
import gameball.com.tw.onecupcafe.utils.TimeStampUtil;
import gameball.com.tw.onecupcafe.utils.ToastUtil;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EmailLoginFragment extends BaseFragment {

    public static final String TAG = "EmailLogin";

    public static EmailLoginFragment newInstance() {
        Bundle args = new Bundle();

        EmailLoginFragment fragment = new EmailLoginFragment();
        fragment.setArguments(args);
        return fragment;
    }

    private View signUpLayoutStep1, signUpLayoutStep2, signUpLayoutStep3, signUpLayoutStep4, signUpLayoutStep5;
    private Button btnSignUpPhoneNextStep, btnBindEmail, btnSignUpNewUserPhoneCertifiedStart,
            btnSignUpNewUserPhoneCustomerService, btnSignUpNewUserPhoneCertifiedResend, btnBindEmailLater;
    private int intCountDownSec = 60;
    private CountDownTimer resendCountDownTimer = null;
    private String strSignUpTag = "step1";
    private EditText etSignUpPhoneNumberHint, etSignUpNewUserPhoneCertifiedHint;

    private TextView tvSignUpPhoneCountryCodeHint, etSignUpPhoneCompleteEmailHint;

    private String strPhoneNum, strCountryCode;
    private ProgressBarCallBack progressBarCallBack;
    private ApiErrorMsgCallback apiErrorMsgCallback;
    private String strRegToken;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_sing_up_new_user_step_main, container, false);
        initView(view);
        return view;
    }

    private void initView(View v) {
        progressBarCallBack = (ProgressBarCallBack) getActivity();
        apiErrorMsgCallback = (ApiErrorMsgCallback) getActivity();

        signUpLayoutStep1 = (View) v.findViewById(R.id.signUpLayoutStep1);
        signUpLayoutStep2 = (View) v.findViewById(R.id.signUpLayoutStep2);
        signUpLayoutStep3 = (View) v.findViewById(R.id.signUpLayoutStep3);
        signUpLayoutStep4 = (View) v.findViewById(R.id.signUpLayoutStep4);
        signUpLayoutStep5 = (View) v.findViewById(R.id.signUpLayoutStep5);

        //step1
        btnSignUpPhoneNextStep = (Button) v.findViewById(R.id.btnSignUpPhoneNextStep);
        btnSignUpPhoneNextStep.setOnClickListener(this);

        etSignUpPhoneNumberHint = (EditText) v.findViewById(R.id.etSignUpPhoneNumberHint);
        tvSignUpPhoneCountryCodeHint = (TextView) v.findViewById(R.id.tvSignUpPhoneCountryCodeHint);
        tvSignUpPhoneCountryCodeHint.setOnClickListener(this);

        //step2
        btnSignUpNewUserPhoneCertifiedStart = (Button) v.findViewById(R.id.btnSignUpNewUserPhoneCertifiedStart);
        btnSignUpNewUserPhoneCertifiedStart.setOnClickListener(this);
        btnSignUpNewUserPhoneCustomerService = (Button) v.findViewById(R.id.btnSignUpNewUserPhoneCustomerService);
        btnSignUpNewUserPhoneCustomerService.setOnClickListener(this);
        btnSignUpNewUserPhoneCertifiedResend = (Button) v.findViewById(R.id.btnSignUpNewUserPhoneCertifiedResend);
        btnSignUpNewUserPhoneCertifiedResend.setOnClickListener(this);
        etSignUpNewUserPhoneCertifiedHint = (EditText) v.findViewById(R.id.etSignUpNewUserPhoneCertifiedHint);

        //step3
        btnBindEmail = (Button) v.findViewById(R.id.btnBindEmail);
        btnBindEmail.setOnClickListener(this);

        btnBindEmailLater = (Button) v.findViewById(R.id.btnBindEmailLater);
        btnBindEmailLater.setOnClickListener(this);
        etSignUpPhoneCompleteEmailHint = (EditText) v.findViewById(R.id.etSignUpPhoneCompleteEmailHint);
    }

    private void switchViewControler() {
        String strStep = strSignUpTag;
        closeSoftKeyboard(((ViewGroup) getView()).getFocusedChild());
        switch (strStep) {
            case "step1":
                break;
            case "step2":
                signUpLayoutStep1.setVisibility(View.GONE);
                signUpLayoutStep2.setVisibility(View.VISIBLE);
                if (resendCountDownTimer == null) {
                    sendCertifiedSMS();
                }
                break;
            case "step3":
                signUpLayoutStep2.setVisibility(View.GONE);
                signUpLayoutStep3.setVisibility(View.VISIBLE);

                break;
            case "step4":
                signUpLayoutStep3.setVisibility(View.GONE);
                signUpLayoutStep4.setVisibility(View.VISIBLE);
                strSignUpTag = "step5";
//                new CountDownTimer(3000, 1000) {
//                    @Override
//                    public void onTick(long millisUntilFinished) {
//
//                    }
//
//                    @Override
//                    public void onFinish() {
                switchViewControler();
//                    }
//                }.start();
                break;
            case "step5":
//                signUpLayoutStep4.setVisibility(View.GONE);
//                signUpLayoutStep5.setVisibility(View.VISIBLE);
                new CountDownTimer(3000, 1000) {
                    @Override
                    public void onTick(long millisUntilFinished) {

                    }

                    @Override
                    public void onFinish() {
                        if(((SettingPageActivity)getActivity()).strFromTag.equals("RecieveGift")){
                            getActivity().finish();
                        }else {
                            getActivity().startActivity(new Intent(getActivity(), HomeActivity.class));
                            getActivity().finish();
                        }
                    }
                }.start();
                break;
            default:
                break;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tvSignUpPhoneCountryCodeHint:
                //國碼選擇
                new CountryPickerDialog(getActivity(), new CountryPickerCallbacks() {
                    @Override
                    public void onCountrySelected(Country country, int i) {
                        tvSignUpPhoneCountryCodeHint.setText(country.getDialingCode());
                    }
                }).show();
                break;
            case R.id.btnSignUpPhoneNextStep:
                strPhoneNum = etSignUpPhoneNumberHint.getText().toString().trim();
                //如果電話號碼開頭為0就刪掉
                if (strPhoneNum.length() <= 1) {
                    ToastUtil.showToastMsg(getString(R.string.sign_up_phone_number_error));
                } else {
                    if (String.valueOf(strPhoneNum.charAt(0)).equals("0")) {
                        strPhoneNum = strPhoneNum.substring(1);
                    }
                    Log.e(TAG,"UserPhone:"+strPhoneNum);
                    progressBarCallBack.showProgressBar();
                    strCountryCode = tvSignUpPhoneCountryCodeHint.getText().toString().trim();
                    apiSendSMS(strCountryCode, strPhoneNum);
                }
                break;
            case R.id.btnSignUpNewUserPhoneCertifiedStart:
                //傳送驗證碼
                if (etSignUpNewUserPhoneCertifiedHint.getText().toString().trim().length() != 4) {
                    ToastUtil.showToastMsg(getString(R.string.forget_account_renew_phone_certified_hint));
                } else {
                    progressBarCallBack.showProgressBar();
                    apiCertifiedSMS(strRegToken, etSignUpNewUserPhoneCertifiedHint.getText().toString().trim());
                }
                break;
            case R.id.btnSignUpNewUserPhoneCertifiedResend:
                //重新傳送驗證碼
                if (intCountDownSec == 0) {
                    progressBarCallBack.showProgressBar();
                    strCountryCode = tvSignUpPhoneCountryCodeHint.getText().toString().trim();
                    apiSendSMS(strCountryCode, strPhoneNum);
                    sendCertifiedSMS();
                }
                break;
            case R.id.btnSignUpNewUserPhoneCustomerService:
//                startActivity(new Intent(getActivity(), SettingPageActivity.class).putExtra("ServiceCategory", "HelpCenter"));
                startActivity(new Intent(getActivity(), HelpCenterActivity.class));
                break;
            case R.id.btnBindEmail:
                String strGetUserInputEmail = etSignUpPhoneCompleteEmailHint.getText().toString().trim();
                if (EmailValidUtil.isEmailValid(strGetUserInputEmail) == true) {
                    progressBarCallBack.showProgressBar();
                    apiBindEmail(strGetUserInputEmail);
                } else {
                    ToastUtil.showToastMsg(getString(R.string.sign_up_phone_complete_email_not_correct));
                }
                break;
            case R.id.btnBindEmailLater:
                strSignUpTag = "step4";
                getActivity().startActivity(new Intent(getActivity(), HomeActivity.class));
                getActivity().finish();
                break;
            default:
                break;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (resendCountDownTimer != null) {
            resendCountDownTimer.cancel();
        }
    }

    //todo
    //傳送簡訊認證碼 [api_001]
    private void apiSendSMS(String strCountryCode, String strPhoneNum) {
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeyStr = MD5Util.MD5(Constants.SALT, strPhoneNum, strTimeStamp);
        String strTimeZone = App.timezone;
        Call<ResUserInputInfo> getPhoneVerify =
                ApiBase.instance().
                        create(UserSignInSignUpApi.class).
                        postUserInputInfo(
                                strCountryCode,
                                App.locale,
                                strTimeZone,
                                "sms",
                                strPhoneNum,
                                strTimeStamp,
                                strKeyStr);
        getPhoneVerify.enqueue(new Callback<ResUserInputInfo>() {
            @Override
            public void onResponse(Call<ResUserInputInfo> call, Response<ResUserInputInfo> response) {
                String strApiRtnCode = response.body().getCode();
                if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {
                    Log.e(TAG, "RegToken:" + response.body().getRetnObject().getRegToken());
                    strRegToken = response.body().getRetnObject().getRegToken();
                    strSignUpTag = "step2";
                    switchViewControler();
                }else {
                    apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                }


            }

            @Override
            public void onFailure(Call<ResUserInputInfo> call, Throwable t) {
                Log.e(TAG, "Error:" + t.toString());
            }
        });
        progressBarCallBack.hideProgressBar();
    }

    //todo
    //認證碼認證
    private void apiCertifiedSMS(String strToken, String strVerifyCode) {

        String strTimeZone = App.timezone;
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken, strTimeStamp);
//        strVerifyCode = "1000";
        Call<ResUserCertified> getSmsCertified =
                ApiBase.instance().
                        create(UserSignInSignUpApi.class).
                        postUserCertified(
                                strToken,
                                App.locale,
                                strTimeZone,
                                strVerifyCode,
                                Constants.strSenderId,
                                "android",
                                strKeyStr,
                                strTimeStamp);

        getSmsCertified.enqueue(new Callback<ResUserCertified>() {
            @Override
            public void onResponse(Call<ResUserCertified> call, Response<ResUserCertified> response) {

                String strApiRtnCode = response.body().getCode();
                if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {
                    Hawk.put(Constants.USER_ACCTOKEN, response.body().getRetnObject().getAccToken());
                    Hawk.put(Constants.USER_TOKEN_EXPIRE_TIME, response.body().getRetnObject().getExpireTime());
                    Hawk.put(Constants.USER_PHONE,"0"+strPhoneNum);
                    strSignUpTag = "step3";
                    switchViewControler();
                }else {
                    apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                }
            }

            @Override
            public void onFailure(Call<ResUserCertified> call, Throwable t) {
                Log.e(TAG, "Error:" + t.toString());
            }
        });
        progressBarCallBack.hideProgressBar();
    }

    //todo
    //綁定Email
    private void apiBindEmail(String strBindEmail) {
        final String strMail = strBindEmail;
        String strToken = Hawk.get(Constants.USER_ACCTOKEN);
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken, strTimeStamp);
        Call<ResUserEmailBind> getBindEmail =
                ApiBase.instance().
                        create(UserSignInSignUpApi.class).
                        postUserEmailBind(
                                strToken,
                                strBindEmail,
                                strKeyStr,
                                strTimeStamp);

        getBindEmail.enqueue(new Callback<ResUserEmailBind>() {
            @Override
            public void onResponse(Call<ResUserEmailBind> call, Response<ResUserEmailBind> response) {
                String strApiRtnCode = response.body().getCode();
                if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {
                    strSignUpTag = "step4";
                    Hawk.put(Constants.USER_EMAIL, strMail);
                    switchViewControler();
                }else {
                    apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                }
            }

            @Override
            public void onFailure(Call<ResUserEmailBind> call, Throwable t) {
                Log.e(TAG, "Error:" + t.toString());
            }
        });
        progressBarCallBack.hideProgressBar();
    }

    private void closeSoftKeyboard(View view) {
//        View view = getActivity().getCurrentFocus();
//        if (view != null) {
//            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
//            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
//        }

        if (getActivity() == null || view == null) {
            return;
        }
        int times = 0;
        boolean isClosed = false;
        InputMethodManager manager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        while (!isClosed && times <= 5) {
            times++;
            isClosed = manager.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    private void sendCertifiedSMS() {
        intCountDownSec = 60;
        resendCountDownTimer = new CountDownTimer(intCountDownSec * 1000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                intCountDownSec = intCountDownSec - 1;
                btnSignUpNewUserPhoneCertifiedResend.setText(intCountDownSec + getString(R.string.forget_account_renew_phone_certified_resend));
            }

            @Override
            public void onFinish() {
                intCountDownSec = 0;
                btnSignUpNewUserPhoneCertifiedResend.setText(R.string.sign_up_phone_not_receive_resend_sms);
                resendCountDownTimer = null;
            }
        }.start();
    }


}
