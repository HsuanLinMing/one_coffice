package gameball.com.tw.onecupcafe.items.SettingPojo;

import java.io.Serializable;
import java.util.ArrayList;

public class ResGetUserOrderHistory implements Serializable {
    String code;
    String message;
    ArrayList<OrderHistory> retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


    public ArrayList<OrderHistory> getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(ArrayList<OrderHistory> retnObject) {
        this.retnObject = retnObject;
    }


}
