package gameball.com.tw.onecupcafe.fragments.exchange;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.eralp.circleprogressview.CircleProgressView;
import com.makeramen.roundedimageview.RoundedImageView;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.activities.ExchangeActivity;
import gameball.com.tw.onecupcafe.core.base.BaseFragment;
import gameball.com.tw.onecupcafe.utils.FragmentSwitchCallback;
import gameball.com.tw.onecupcafe.utils.GlideImageUtil;

public class ExchangeFreeFragment extends BaseFragment {


    public static ExchangeFreeFragment newInstance() {
        Bundle args = new Bundle();

        ExchangeFreeFragment fragment = new ExchangeFreeFragment();
        fragment.setArguments(args);
        return fragment;
    }

    public static final String TAG = "ExchangeFree";
    private FragmentSwitchCallback callback;
    private Button btnExchangeFreeConfirm;
    private CircleProgressView cpvExchangeFreePercent;
    private RoundedImageView rivExchangeFreeImg;
    private TextView tvExchangeFreeExchangeDesc,tvExchangeFreeRemainCountDesc;
    private ExchangeActivity exchangeActivity;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_exchange_free,container,false);
        callback = (FragmentSwitchCallback) getActivity();
        initView(view);
        return view;
    }

    private void initView(View v) {
        exchangeActivity = (ExchangeActivity)getActivity();

        btnExchangeFreeConfirm = (Button)v.findViewById(R.id.btnExchangeFreeConfirm);
        btnExchangeFreeConfirm.setOnClickListener(this);

        cpvExchangeFreePercent = (CircleProgressView) v.findViewById(R.id.cpvExchangeFreePercent);
        rivExchangeFreeImg = (RoundedImageView) v.findViewById(R.id.rivExchangeFreeImg);

        tvExchangeFreeExchangeDesc = (TextView) v.findViewById(R.id.tvExchangeFreeExchangeDesc);
        tvExchangeFreeRemainCountDesc = (TextView) v.findViewById(R.id.tvExchangeFreeRemainCountDesc);

        initDataView();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnExchangeFreeConfirm:
                callback.setTargetFragment("FreeExchange");
                break;
            default:
                break;
        }
    }

    private void initDataView(){
        new GlideImageUtil(getActivity(),
                exchangeActivity.orderData.prodImage1,
                rivExchangeFreeImg,
                R.drawable.img_product_big_default).LoadImageWithGlide();

        tvExchangeFreeExchangeDesc.setText(exchangeActivity.orderData.getRedeemQty());
        tvExchangeFreeRemainCountDesc.setText(exchangeActivity.orderData.getRemianingQty());
        float cpvPercent = (Integer.parseInt(exchangeActivity.orderData.getRedeemQty()) *Integer.parseInt(exchangeActivity.orderData.getTotalQty())/Integer.parseInt(exchangeActivity.orderData.getTotalQty()) );
        Log.e(TAG,"CpvPercent:"+cpvPercent+";+RedeemQty:"+exchangeActivity.orderData.getRedeemQty()+
        "TotalQty:"+Integer.parseInt(exchangeActivity.orderData.getTotalQty()));
        cpvExchangeFreePercent.setStartAngle(270);
        cpvExchangeFreePercent.setProgressWithAnimation(cpvPercent, 1000);
    }
}
