package gameball.com.tw.onecupcafe.items.PointCardPojo;

public class ResShareCancelFromOwner {
    public String code;
    public String message;
    public String retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(String retnObject) {
        this.retnObject = retnObject;
    }

    public class ShareCancelFromOwnerReturn{
        public String message;

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
}
