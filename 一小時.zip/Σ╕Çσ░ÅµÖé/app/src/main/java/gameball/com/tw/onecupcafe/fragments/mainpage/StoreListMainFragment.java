package gameball.com.tw.onecupcafe.fragments.mainpage;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.astuetz.PagerSlidingTabStrip;
import com.orhanobut.hawk.Hawk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.activities.HomeActivity;
import gameball.com.tw.onecupcafe.adapters.StoreListAdatper;
import gameball.com.tw.onecupcafe.adapters.StorePageCategoryAdapter;
import gameball.com.tw.onecupcafe.core.base.BaseFragment;
import gameball.com.tw.onecupcafe.core.base.SampleFragment;
import gameball.com.tw.onecupcafe.items.StorePojo.ResGetStoreList;
import gameball.com.tw.onecupcafe.items.StorePojo.StoreData;
import gameball.com.tw.onecupcafe.retrofit.ApiBase;
import gameball.com.tw.onecupcafe.retrofit.api.StoreApi;
import gameball.com.tw.onecupcafe.utils.ApiErrorMsgCallback;
import gameball.com.tw.onecupcafe.utils.CalculateStoreDistance;
import gameball.com.tw.onecupcafe.utils.Constants;
import gameball.com.tw.onecupcafe.utils.MD5Util;
import gameball.com.tw.onecupcafe.utils.ProgressBarCallBack;
import gameball.com.tw.onecupcafe.utils.ResStatusReturn;
import gameball.com.tw.onecupcafe.utils.TimeStampUtil;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StoreListMainFragment extends BaseFragment {
    public static final String TAG = "StoreListMainFragment";

    public static StoreListMainFragment newInstance() {
        Bundle args = new Bundle();

        StoreListMainFragment fragment = new StoreListMainFragment();
        fragment.setArguments(args);
        return fragment;
    }

    private StorePageCategoryAdapter storePageCategoryAdapter;
    private ViewPager vpStoreList;
    private PagerSlidingTabStrip pstasStoreCategory;
    private ArrayList<String> arrStoreCategory = new ArrayList<>();

    public ArrayList<StoreData> arrStoredData = new ArrayList<>();
    private HomeActivity homeActivity;
    private ProgressBarCallBack progressBarCallBack;
    private ApiErrorMsgCallback apiErrorMsgCallback;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_store_list_main, container, false);
        initView(view);
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

    }

    private void initView(View v) {
        progressBarCallBack = (ProgressBarCallBack) getActivity();
        apiErrorMsgCallback = (ApiErrorMsgCallback) getActivity();
        homeActivity = (HomeActivity)getActivity();

        pstasStoreCategory = (PagerSlidingTabStrip) v.findViewById(R.id.pstasStoreCategory);
        vpStoreList = (ViewPager) v.findViewById(R.id.vpStoreList);

        apiStoreList();
        initStoreCategoryData();

    }

    private void initStoreCategoryData() {
        arrStoreCategory.add("全部店家");
        arrStoreCategory.add("最愛店家");
        arrStoreCategory.add("拿鐵咖啡");
        arrStoreCategory.add("美式咖啡");
        arrStoreCategory.add("瑪奇朵");
    }

    @Override
    public void onClick(View v) {

    }

    //todo
    //檔名：api_101.php 功能：取得所有店家列表資料
    private void apiStoreList() {
//        progressBarCallBack.showProgressBar();
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strToken = Hawk.get(Constants.USER_ACCTOKEN,"");
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken, strTimeStamp);
        String strUserLat= null,strUserLng= null;
        if(homeActivity.numUserLat != 0){
            strUserLat = String.valueOf(homeActivity.numUserLat);
            strUserLng = String.valueOf(homeActivity.numUserLng);
        }
        Call<ResGetStoreList> getStoreList = ApiBase.instance().create(StoreApi.class)
                .postGetStoreList(strKeyStr, strToken , strTimeStamp ,strUserLat,strUserLng );
        Log.e(TAG, "StoreListApiParams:"  + ";TimeStamp:" + strTimeStamp + ";KeyStr:" + strKeyStr);
        getStoreList.enqueue(new Callback<ResGetStoreList>() {
            @Override
            public void onResponse(Call<ResGetStoreList> call, Response<ResGetStoreList> response) {
                String strApiRtnCode = response.body().getCode();
                if (ResStatusReturn.apiStatus(strApiRtnCode) == true) {
                    arrStoredData = response.body().getRetnObject();
                    for (int i = 0; i < arrStoredData.size(); i++) {
                        StoreData storeData = arrStoredData.get(i);
                        storeData.setDistance(CalculateStoreDistance.distance(homeActivity.numUserLng, storeData.getLongitude(), homeActivity.numUserLat, storeData.getLatitude()));
                    }

                    Log.e(TAG, "LatLng: " + homeActivity.numUserLat + "-" + homeActivity.numUserLng);
                    if (homeActivity.numUserLat != 0 && homeActivity.numUserLng != 0) {
                        sortStoreDistance();
                    }
                    homeActivity.arrHomeStoredData = arrStoredData;
                    initChildStoreListFragmentData();
                }else{
                    apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                }
            }

            @Override
            public void onFailure(Call<ResGetStoreList> call, Throwable t) {
                Log.e(TAG, "onFailure: " + t.toString());
            }
        });
        progressBarCallBack.hideProgressBar();
    }

    private void sortStoreDistance() {
        Collections.sort(arrStoredData, new Comparator<StoreData>() {
            @Override
            public int compare(StoreData o1, StoreData o2) {
                return Double.compare(o1.getDistance(), o2.getDistance());
            }
        });
    }

    private void initChildStoreListFragmentData(){

        pstasStoreCategory.setIndicatorColorResource(R.color.red);
        pstasStoreCategory.setIndicatorHeight(20);

        storePageCategoryAdapter = new StorePageCategoryAdapter(getChildFragmentManager(), getActivity(), arrStoreCategory);
        vpStoreList.setAdapter(storePageCategoryAdapter);
        pstasStoreCategory.setViewPager(vpStoreList);
        vpStoreList.setCurrentItem(0);
    }

}
