package gameball.com.tw.onecupcafe.utils;

import android.content.Context;

import java.sql.Timestamp;
import java.util.Calendar;

public class TimeStampUtil {
//    Context context;

    public TimeStampUtil() {
//        this.context = context;
    }

    public String TimeStampGen(){
        Calendar c = Calendar.getInstance();
        Timestamp time = new Timestamp(c.getTimeInMillis());
        return String.valueOf(time.getTime());
    }
}
