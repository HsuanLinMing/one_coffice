package gameball.com.tw.onecupcafe.items.StorePojo;

import java.io.Serializable;

public class ResGetStoreProductConfirm implements Serializable {
    String code;
    String message;
    ReturnData retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ReturnData getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(ReturnData retnObject) {
        this.retnObject = retnObject;
    }

    public class ReturnData{
        String orderID;
        String transCode;
        String transExpireDate;
        int transExpireSecond;

        public String getOrderID() {
            return orderID;
        }

        public void setOrderID(String orderID) {
            this.orderID = orderID;
        }

        public String getTransCode() {
            return transCode;
        }

        public void setTransCode(String transCode) {
            this.transCode = transCode;
        }

        public String getTransExpireDate() {
            return transExpireDate;
        }

        public void setTransExpireDate(String transExpireDate) {
            this.transExpireDate = transExpireDate;
        }

        public int getTransExpireSecond() {
            return transExpireSecond;
        }

        public void setTransExpireSecond(int transExpireSecond) {
            this.transExpireSecond = transExpireSecond;
        }
    }
}
