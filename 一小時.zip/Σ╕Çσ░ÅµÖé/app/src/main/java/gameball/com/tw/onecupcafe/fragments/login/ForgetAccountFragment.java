package gameball.com.tw.onecupcafe.fragments.login;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.activities.HomeActivity;
import gameball.com.tw.onecupcafe.core.base.BaseFragment;
import gameball.com.tw.onecupcafe.utils.EmailValidUtil;
import gameball.com.tw.onecupcafe.utils.ToastUtil;

public class ForgetAccountFragment extends BaseFragment {

    public static ForgetAccountFragment newInstance() {
        Bundle args = new Bundle();

        ForgetAccountFragment fragment = new ForgetAccountFragment();
        fragment.setArguments(args);
        return fragment;
    }

    private int intCountDownSec = 60;
    private CountDownTimer resendCountDownTimer;
    private View signUpForgetLayoutStep1, signUpForgetLayoutStep2, signUpForgetLayoutStep3;
    private Button btnForgetAccountNextStep, btnForgetAccountRenewPhoneCertifiedStart, btnForgetAccountRenewPhoneCertifiedResend, btnForgetAccountRenewPhoneCustomerService;
    private String strStepTag = "step1";
    private EditText etForgetAccountEmailHint,etForgetAccountPhoneHint;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_sign_up_forget_account_step_main,container,false);
        initView(view);
        return view;
    }

    private void initView(View v) {
        signUpForgetLayoutStep1 = (View) v.findViewById(R.id.signUpForgetLayoutStep1);
        signUpForgetLayoutStep2 = (View) v.findViewById(R.id.signUpForgetLayoutStep2);
        signUpForgetLayoutStep3 = (View) v.findViewById(R.id.signUpForgetLayoutStep3);

        //step1
        btnForgetAccountNextStep = (Button) v.findViewById(R.id.btnForgetAccountNextStep);
        btnForgetAccountNextStep.setOnClickListener(this);
        etForgetAccountEmailHint = (EditText) v.findViewById(R.id.etForgetAccountEmailHint);
        etForgetAccountPhoneHint = (EditText) v.findViewById(R.id.etForgetAccountPhoneHint);

        //stpe2
        btnForgetAccountRenewPhoneCertifiedStart = (Button) v.findViewById(R.id.btnForgetAccountRenewPhoneCertifiedStart);
        btnForgetAccountRenewPhoneCertifiedStart.setOnClickListener(this);
        btnForgetAccountRenewPhoneCertifiedResend = (Button) v.findViewById(R.id.btnForgetAccountRenewPhoneCertifiedResend);
        btnForgetAccountRenewPhoneCertifiedResend.setOnClickListener(this);
        btnForgetAccountRenewPhoneCustomerService = (Button) v.findViewById(R.id.btnForgetAccountRenewPhoneCustomerService);
        btnForgetAccountRenewPhoneCustomerService.setOnClickListener(this);

    }


    private void switchViewControl() {
        switch (strStepTag) {
            case "step1":
                break;
            case "step2":
                signUpForgetLayoutStep1.setVisibility(View.GONE);
                signUpForgetLayoutStep2.setVisibility(View.VISIBLE);
                resendCountDownTimer = new CountDownTimer(60000, 1000) {
                    @Override
                    public void onTick(long millisUntilFinished) {
                        btnForgetAccountRenewPhoneCertifiedResend.setText(intCountDownSec + getString(R.string.forget_account_renew_phone_certified_resend));
                        intCountDownSec = intCountDownSec - 1;
                    }

                    @Override
                    public void onFinish() {
                    }
                }.start();
                break;
            case "step3":
                signUpForgetLayoutStep2.setVisibility(View.GONE);
                signUpForgetLayoutStep3.setVisibility(View.VISIBLE);
                new CountDownTimer(3000, 1000) {
                    @Override
                    public void onTick(long millisUntilFinished) {

                    }

                    @Override
                    public void onFinish() {
                        getActivity().startActivity(new Intent(getActivity(),HomeActivity.class));
                    }
                }.start();
                break;
        }
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnForgetAccountNextStep:
                String strUserEmail = etForgetAccountEmailHint.getText().toString();
                String strUserPhone = etForgetAccountPhoneHint.getText().toString().trim();
                if(EmailValidUtil.isEmailValid(strUserEmail) == true && strUserPhone.length()>0){
                strStepTag = "step2";
                switchViewControl();
                }else {
                    ToastUtil.showToastMsg(getString(R.string.forget_account_input_reconfirm));
                }

                break;
            case R.id.btnForgetAccountRenewPhoneCertifiedStart:
                strStepTag = "step3";
                switchViewControl();
                break;
            case R.id.btnForgetAccountRenewPhoneCertifiedResend:

                break;
            case R.id.btnForgetAccountRenewPhoneCustomerService:
                break;
            default:
                break;
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (resendCountDownTimer != null) {
            resendCountDownTimer.cancel();
        }
    }
}
