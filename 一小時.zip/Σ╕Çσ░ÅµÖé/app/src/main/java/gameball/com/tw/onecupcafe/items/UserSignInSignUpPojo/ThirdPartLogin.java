package gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo;

import java.io.Serializable;

public class ThirdPartLogin implements Serializable{
    String userEmail;
    String accToken;
    String expireTime;

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getAccToken() {
        return accToken;
    }

    public void setAccToken(String accToken) {
        this.accToken = accToken;
    }

    public String getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(String expireTime) {
        this.expireTime = expireTime;
    }
}