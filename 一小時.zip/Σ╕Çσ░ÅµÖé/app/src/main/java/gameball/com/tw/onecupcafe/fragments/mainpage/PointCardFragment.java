package gameball.com.tw.onecupcafe.fragments.mainpage;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.constraint.Group;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.orhanobut.hawk.Hawk;

import java.util.ArrayList;
import java.util.List;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.activities.ExchangeActivity;
import gameball.com.tw.onecupcafe.activities.HomeActivity;
import gameball.com.tw.onecupcafe.activities.SettingPageActivity;
import gameball.com.tw.onecupcafe.activities.StoreDetailActivity;
import gameball.com.tw.onecupcafe.adapters.PointCardAdapter;
import gameball.com.tw.onecupcafe.core.base.BaseFragment;
import gameball.com.tw.onecupcafe.core.etc.RecycleViewLayoutManager;
import gameball.com.tw.onecupcafe.items.PointCardPojo.ResGetAllPointCardList;
import gameball.com.tw.onecupcafe.items.PointCardPojo.StorePointCardList;
import gameball.com.tw.onecupcafe.retrofit.ApiBase;
import gameball.com.tw.onecupcafe.retrofit.api.PointCardApi;
import gameball.com.tw.onecupcafe.utils.ApiErrorMsgCallback;
import gameball.com.tw.onecupcafe.utils.Constants;
import gameball.com.tw.onecupcafe.utils.MD5Util;
import gameball.com.tw.onecupcafe.utils.ProgressBarCallBack;
import gameball.com.tw.onecupcafe.utils.TimeStampUtil;
import gameball.com.tw.onecupcafe.utils.ToastUtil;
import gameball.com.tw.onecupcafe.utils.ToolBarChange;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PointCardFragment extends BaseFragment {
    public static final String TAG = "PointCardFragment";
    private RecyclerView rvPointCardList;
    private List list = new ArrayList();
    private PointCardAdapter pointCardAdapter;
    public static String strPointCardTag = "redeem";
    private Button btnPointCardRedeemProducts, btnPointCardFreeProducts, btnPointCardGiftProducts;
    private ToolBarChange callback;
    private String strStoreName , strStoreMainImg;
    private ProgressBarCallBack progressBarCallBack;
    private Group viewPointCardGroup;
    private View viewPlzLogin;
    private Button btnGoToSignUp , btnGoToSignUpLater;
    private ApiErrorMsgCallback apiErrorMsgCallback;
    public static PointCardFragment newInstance() {
        Bundle args = new Bundle();

        PointCardFragment fragment = new PointCardFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_point_card, container, false);
        callback = (ToolBarChange) getActivity();
        callback.setToolBarView("HideMap");
        initView(view);
        return view;
    }

    @Override
    public void onStop() {
        super.onStop();
        callback.setToolBarView("ShowMap");
    }

    void initView(View view) {
        progressBarCallBack = (ProgressBarCallBack) getActivity();
        apiErrorMsgCallback = (ApiErrorMsgCallback) getActivity();

        viewPointCardGroup = (Group) view.findViewById(R.id.viewPointCardGroup);
        viewPlzLogin = (View) view.findViewById(R.id.viewPlzLogin);

        btnPointCardRedeemProducts = (Button) view.findViewById(R.id.btnPointCardRedeemProducts);
        btnPointCardFreeProducts = (Button) view.findViewById(R.id.btnPointCardFreeProducts);
        btnPointCardGiftProducts = (Button) view.findViewById(R.id.btnPointCardGiftProducts);
        btnPointCardRedeemProducts.setOnClickListener(this);
        btnPointCardFreeProducts.setOnClickListener(this);
        btnPointCardGiftProducts.setOnClickListener(this);

        btnGoToSignUp = (Button) view.findViewById(R.id.btnGoToSignUp);
        btnGoToSignUp.setOnClickListener(this);
        btnGoToSignUpLater = (Button) view.findViewById(R.id.btnGoToSignUpLater);
        btnGoToSignUpLater.setOnClickListener(this);

        btnPointCardRedeemProducts.setBackgroundResource(R.drawable.poincard_tag_button2);
        btnPointCardRedeemProducts.setTextColor(Color.parseColor("#00A851"));

        rvPointCardList = view.findViewById(R.id.rvPointCardList);
        new RecycleViewLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, rvPointCardList);


    }

    @Override
    public void onResume() {
        super.onResume();
        if (Hawk.get(Constants.USER_ACCTOKEN, Constants.USER_DEF_DATA).equals(Constants.USER_DEF_DATA)) {
            viewPointCardGroup.setVisibility(View.GONE);
            viewPlzLogin.setVisibility(View.VISIBLE);
        } else {
//            if (list.size() == 0) {
                apiGetAllPointCardList("order");
                strPointCardTag = "redeem";
                viewPointCardGroup.setVisibility(View.VISIBLE);
                viewPlzLogin.setVisibility(View.GONE);
                selectTagButtonBg();
//            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnPointCardRedeemProducts:
                if (!strPointCardTag.equals("redeem")) {
                    strPointCardTag = "redeem";
                    apiGetAllPointCardList("order");
                    if (pointCardAdapter != null) {
                        pointCardAdapter.notifyDataSetChanged();
                        rvPointCardList.scrollToPosition(0);
                    }
                }
                break;
            case R.id.btnGoToSignUpLater:
                getActivity().onBackPressed();
                break;
            case R.id.btnPointCardFreeProducts:
                if (!strPointCardTag.equals("free")) {
                    strPointCardTag = "free";
                    apiGetAllPointCardList("free");
                    if (pointCardAdapter != null) {
                        pointCardAdapter.notifyDataSetChanged();
                        rvPointCardList.scrollToPosition(0);
                    }
                }
                break;
            case R.id.btnPointCardGiftProducts:
                if (!strPointCardTag.equals("gift")) {
                    strPointCardTag = "gift";
                    apiGetAllPointCardList("gift");
                    if (pointCardAdapter != null) {
                        pointCardAdapter.notifyDataSetChanged();
                        rvPointCardList.scrollToPosition(0);
                    }
                }
                break;
            case R.id.btnGoToSignUp:
                getActivity().startActivity(new Intent(getActivity(), SettingPageActivity.class)
                        .putExtra("ServiceCategory", "PhoneCertified"));
                break;
            default:
                break;
        }
        selectTagButtonBg();
    }

    //todo
    //檔名：api_201.php 功能：取得使用者寄杯資料(訂單列表)
    private void apiGetAllPointCardList(String strPointCardType) {
        progressBarCallBack.showProgressBar();
        String strToken = Hawk.get(Constants.USER_ACCTOKEN);
        String strTimeStamp = new TimeStampUtil().TimeStampGen();
        String strKeyStr = MD5Util.MD5(Constants.SALT, strToken, strTimeStamp);
        Call<ResGetAllPointCardList> getStoreMoreArticles =
                ApiBase.instance().create(PointCardApi.class).
                        postGetAllPointCardList(
                                strToken,
                                strKeyStr,
                                strTimeStamp,
                                strPointCardType);


        getStoreMoreArticles.enqueue(new Callback<ResGetAllPointCardList>() {
            @Override
            public void onResponse(Call<ResGetAllPointCardList> call, Response<ResGetAllPointCardList> response) {
                String strApiRtnCode = response.body().getCode();
                if (strApiRtnCode.equals("000")) {
                    list.clear();
                    list = response.body().getRetnObject().getStoreList();
                    Log.e(TAG, "DataSize:" + list.size());
                    setDataView();
                }else {
                    apiErrorMsgCallback.showErrorMsg(response.body().getMessage());
                }
            }

            @Override
            public void onFailure(Call<ResGetAllPointCardList> call, Throwable t) {
            }
        });

        progressBarCallBack.hideProgressBar();
    }

    private void setDataView() {
        pointCardAdapter = new PointCardAdapter(getActivity(), list);
        pointCardAdapter.setOnItemClickLitener(new PointCardAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                int datasize = 0;
                if (list.get(position) instanceof StorePointCardList) {//判断是否为父
                    StorePointCardList parent = (StorePointCardList) list.get(position);
                    if ((position + 1) == list.size()) {//判断是否为最后一个元素
                        pointCardAdapter.addAllChild(parent.getOrderList(), position + 1);
                        datasize = parent.getOrderList().size();
                    } else {
                        if (list.get(position + 1) instanceof StorePointCardList) {//如果是父则表示为折叠状态需要添加儿子
//                            strStoreName = parent.getStoreName();
                            pointCardAdapter.addAllChild(parent.getOrderList(), position + 1);
                            datasize = parent.getOrderList().size();
                        } else if (list.get(position + 1) instanceof StorePointCardList.StoreOrder) {//如果是儿子则表示为展开状态需要删除儿子
                            pointCardAdapter.deleteAllChild(position + 1, parent.getOrderList().size());
                            datasize = 0 - parent.getOrderList().size();
                        }
                    }
                    Log.e("ReturnPosition", position + ";" + list.size());
                } else {
                    //子元素
                    for (int i = position - 1; i >= 0; --i) {
                        if (list.get(i) instanceof StorePointCardList) {
                            StorePointCardList parent = (StorePointCardList) list.get(i);
                            Log.e(TAG, "ParentName" + position + ":" + parent.getStoreName());
                            strStoreName = parent.getStoreName();
                            strStoreMainImg = parent.getStorePhoto1();
                            break;
                        }
                    }

                    Log.e(TAG, "TOKEN:" + Hawk.get(Constants.USER_ACCTOKEN, Constants.USER_DEF_DATA));
                    Bundle bundle = new Bundle();
                    bundle.putString("PointCardType", strPointCardTag);
                    bundle.putString("StoreName", strStoreName);
                    bundle.putString("StoreMainImgUrl",strStoreMainImg);
                    bundle.putSerializable("OrderData", (StorePointCardList.StoreOrder) list.get(position));
                    StorePointCardList.StoreOrder data = ((StorePointCardList.StoreOrder) list.get(position));
                    Log.e(TAG, "Click" + position + ":" + data.getRemianingQty());
                    getActivity().startActivity(new Intent(getActivity(), ExchangeActivity.class).putExtras(bundle));
                }
                rvPointCardList.scrollToPosition(position + datasize);
            }
        });

        rvPointCardList.setAdapter(pointCardAdapter);
    }

    private void selectTagButtonBg() {
        btnPointCardRedeemProducts.setBackgroundResource(R.drawable.poincard_tag_button);
        btnPointCardRedeemProducts.setTextColor(Color.parseColor("#999999"));

        btnPointCardFreeProducts.setBackgroundResource(R.drawable.poincard_tag_button);
        btnPointCardFreeProducts.setTextColor(Color.parseColor("#999999"));

        btnPointCardGiftProducts.setBackgroundResource(R.drawable.poincard_tag_button);
        btnPointCardGiftProducts.setTextColor(Color.parseColor("#999999"));
        switch (strPointCardTag) {
            case "redeem":
                btnPointCardRedeemProducts.setBackgroundResource(R.drawable.poincard_tag_button2);
                btnPointCardRedeemProducts.setTextColor(Color.parseColor("#00A851"));
                break;
            case "free":
                btnPointCardFreeProducts.setBackgroundResource(R.drawable.poincard_tag_button2);
                btnPointCardFreeProducts.setTextColor(Color.parseColor("#00A851"));
                break;
            case "gift":
                btnPointCardGiftProducts.setBackgroundResource(R.drawable.poincard_tag_button2);
                btnPointCardGiftProducts.setTextColor(Color.parseColor("#00A851"));
                break;
        }


    }
}
