package gameball.com.tw.onecupcafe.adapters;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.makeramen.roundedimageview.RoundedImageView;

import java.util.ArrayList;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.activities.ExchangeActivity;
import gameball.com.tw.onecupcafe.items.SettingPojo.OrderHistory;
import gameball.com.tw.onecupcafe.utils.GlideImageUtil;

/**
 * Created by sofasoso on 2018/4/1.
 */

public class SettingOrderHistoryAdatper extends RecyclerView.Adapter<SettingOrderHistoryAdatper.ViewHoler> {
    private Context context;
    private ArrayList<OrderHistory> data;

    public SettingOrderHistoryAdatper(Context context, ArrayList<OrderHistory> data) {
        this.context = context;
        this.data = data;
    }

    public class ViewHoler extends RecyclerView.ViewHolder {
        RoundedImageView rivOrderHistoryImg;
        TextView tvOrderHistoryStoreName, tvOrderHistoryTitle, tvOrderHistoryDesc, tvOrderHistoryTimeLimit;
        Button btnOrderHistoryProductBuy;

        public ViewHoler(View v) {
            super(v);
            rivOrderHistoryImg = (RoundedImageView) v.findViewById(R.id.rivOrderHistoryImg);
            tvOrderHistoryStoreName = (TextView) v.findViewById(R.id.tvOrderHistoryStoreName);
            tvOrderHistoryTitle = (TextView) v.findViewById(R.id.tvOrderHistoryTitle);
            tvOrderHistoryDesc = (TextView) v.findViewById(R.id.tvOrderHistoryDesc);
            tvOrderHistoryTimeLimit = (TextView) v.findViewById(R.id.tvOrderHistoryTimeLimit);
            btnOrderHistoryProductBuy = (Button) v.findViewById(R.id.btnOrderHistoryProductBuy);
        }
    }

    @NonNull
    @Override
    public ViewHoler onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_order_history, parent, false);
        ViewHoler viewHoler = new ViewHoler(v);
        return viewHoler;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHoler holder, int position) {
        final OrderHistory orderHistory = data.get(position);
        new GlideImageUtil(context, orderHistory.getProdImage1(), holder.rivOrderHistoryImg, R.drawable.img_product_sml_default);
        holder.tvOrderHistoryStoreName.setText(orderHistory.getStoreName());
        holder.tvOrderHistoryTitle.setText(orderHistory.getProdTitle());
        holder.tvOrderHistoryDesc.setText(orderHistory.getSubTitle());
        holder.tvOrderHistoryTimeLimit.setText(orderHistory.getOrderDate());
        holder.btnOrderHistoryProductBuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("PointCardType", "HistoryBuy");
                bundle.putString("StoreName", orderHistory.getStoreName());
                bundle.putString("OrderId", orderHistory.getOrderID());
                Log.e("History", orderHistory.getStoreName());
                context.startActivity(new Intent(context, ExchangeActivity.class).putExtras(bundle));
            }
        });
        if (orderHistory.getAllowBuy().equals("N")) {
            holder.btnOrderHistoryProductBuy.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }
}
