package gameball.com.tw.onecupcafe.utils;

/**
 * Created by sofasoso on 2018/3/31.
 */

public interface PermissionCallBack {
    void onRequestPermissionsResult(boolean grant);
}
