package gameball.com.tw.onecupcafe.items.StorePojo;

import java.io.Serializable;
import java.util.ArrayList;

public class ResGetStoreMoreActivities implements Serializable {
    String code;
    String message;
    ReturnData retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ReturnData getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(ReturnData retnObject) {
        this.retnObject = retnObject;
    }

    class ReturnData{
        String storePK;
        ArrayList<Event> eventList;

        public String getStorePK() {
            return storePK;
        }

        public void setStorePK(String storePK) {
            this.storePK = storePK;
        }

        public ArrayList<Event> getEventList() {
            return eventList;
        }

        public void setEventList(ArrayList<Event> eventList) {
            this.eventList = eventList;
        }

        class Event {
            String eventID;
            String eventType;
            String eventDate;
            String eventMessage;
            String eventURL;

            public String getEventID() {
                return eventID;
            }

            public void setEventID(String eventID) {
                this.eventID = eventID;
            }

            public String getEventType() {
                return eventType;
            }

            public void setEventType(String eventType) {
                this.eventType = eventType;
            }

            public String getEventDate() {
                return eventDate;
            }

            public void setEventDate(String eventDate) {
                this.eventDate = eventDate;
            }

            public String getEventMessage() {
                return eventMessage;
            }

            public void setEventMessage(String eventMessage) {
                this.eventMessage = eventMessage;
            }

            public String getEventURL() {
                return eventURL;
            }

            public void setEventURL(String eventURL) {
                this.eventURL = eventURL;
            }
        }
    }
}
