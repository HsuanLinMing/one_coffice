package gameball.com.tw.onecupcafe.utils;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;

/**
 * Created by sofasoso on 2018/3/31.
 */

public class PermissionHelper {
    PermissionCallBack mPermissionCallback;

    public void request(Fragment fragment, @NonNull String[] permissions, PermissionCallBack permissionCallback){
        mPermissionCallback = permissionCallback;

        if ( Build.VERSION.SDK_INT < 23 || isPermissionGranted(fragment.getActivity(), permissions)){
            mPermissionCallback.onRequestPermissionsResult(true);
        }else{
            fragment.requestPermissions(permissions, 3 );
        }
    }

    public void request(Activity activity, @NonNull String[] permissions, PermissionCallBack permissionCallback){
        mPermissionCallback = permissionCallback;

        if ( Build.VERSION.SDK_INT < 23 || isPermissionGranted(activity, permissions)){
            mPermissionCallback.onRequestPermissionsResult(true);
        }else{
            activity.requestPermissions(permissions, 3 );
        }
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults){
        for(int grantResult : grantResults){
            if(grantResult == PackageManager.PERMISSION_DENIED){
                mPermissionCallback.onRequestPermissionsResult(false);
                return;
            }
        }
        mPermissionCallback.onRequestPermissionsResult(true);
    }

    boolean isPermissionGranted(Activity activity, String[] permissions){
        for(String permission : permissions){
            if(ContextCompat.checkSelfPermission( activity, permission ) == PackageManager.PERMISSION_DENIED){
                return false;
            }
        }
        return true;
    }
}
