package gameball.com.tw.onecupcafe.items.StorePojo;

import java.io.Serializable;

public class ResAddRemoveStoreBookMark implements Serializable {
    String code;
    String message;
    ReturnData retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ReturnData getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(ReturnData retnObject) {
        this.retnObject = retnObject;
    }

   public class ReturnData{
        String storePK;
        int storeLike;

        public String getStorePK() {
            return storePK;
        }

        public void setStorePK(String storePK) {
            this.storePK = storePK;
        }

        public int getStoreLike() {
            return storeLike;
        }

        public void setStoreLike(int storeLike) {
            this.storeLike = storeLike;
        }
    }
}
