package gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo;

import java.io.Serializable;

public class ResUserInputInfo implements Serializable {
    String code;
    String message;
    ReturnData retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ReturnData getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(ReturnData retnObject) {
        this.retnObject = retnObject;
    }

    public class ReturnData{
        public String regToken;

        public String getRegToken() {
            return regToken;
        }

        public void setRegToken(String regToken) {
            this.regToken = regToken;
        }
    }


}
