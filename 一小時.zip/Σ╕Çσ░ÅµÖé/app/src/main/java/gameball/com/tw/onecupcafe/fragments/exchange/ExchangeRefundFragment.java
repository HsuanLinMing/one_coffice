package gameball.com.tw.onecupcafe.fragments.exchange;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import gameball.com.tw.onecupcafe.R;
import gameball.com.tw.onecupcafe.activities.ExchangeActivity;
import gameball.com.tw.onecupcafe.core.base.BaseFragment;
import gameball.com.tw.onecupcafe.items.PointCardPojo.StorePointCardList;
import gameball.com.tw.onecupcafe.utils.FragmentSwitchCallback;

public class ExchangeRefundFragment extends BaseFragment {


    public static ExchangeRefundFragment newInstance() {
        Bundle args = new Bundle();
        ExchangeRefundFragment fragment = new ExchangeRefundFragment();
        fragment.setArguments(args);
        return fragment;
    }

    private Button btnExchangeRefundConfirm;
    private FragmentSwitchCallback callback;
    private StorePointCardList.StoreOrder orderData;
    private TextView tvExchangeRefundExchangeNum , tvExchangeRefundShareNum , tvExchangeRefundRemainingNum ,
            tvExchangeRefundTitle;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_exchange_refund,container,false);
        callback = (FragmentSwitchCallback) getActivity();
        initView(view);
        return view;
    }

    private void initView(View v) {
        orderData = ((ExchangeActivity)getActivity()).orderData;

        btnExchangeRefundConfirm = (Button) v.findViewById(R.id.btnExchangeRefundConfirm);
        btnExchangeRefundConfirm.setOnClickListener(this);

        tvExchangeRefundExchangeNum  = (TextView) v.findViewById(R.id.tvExchangeRefundExchangeNum);
        tvExchangeRefundShareNum = (TextView) v.findViewById(R.id.tvExchangeRefundShareNum);
        tvExchangeRefundRemainingNum = (TextView) v.findViewById(R.id.tvExchangeRefundRemainingNum);

        tvExchangeRefundTitle = (TextView) v.findViewById(R.id.tvExchangeRefundTitle);

        tvExchangeRefundTitle.setText(orderData.getProdTitle());
        tvExchangeRefundExchangeNum.setText(orderData.getRedeemQty());
        tvExchangeRefundShareNum.setText(orderData.getSharedQty());
        tvExchangeRefundRemainingNum.setText(orderData.getRemianingQty());

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnExchangeRefundConfirm:
                callback.setTargetFragment("RefundExchange");
                break;
            default:
                break;
        }
    }

}
