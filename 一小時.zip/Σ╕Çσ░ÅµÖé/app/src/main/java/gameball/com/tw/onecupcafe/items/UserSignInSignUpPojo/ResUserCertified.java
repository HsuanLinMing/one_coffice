package gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo;

import com.google.gson.JsonObject;

import java.io.Serializable;

public class ResUserCertified implements Serializable {
    String code;
    String message;
    ReturnData retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ReturnData getRetnObject() {
        return retnObject;
    }

    public void setRetnObject(ReturnData retnObject) {
        this.retnObject = retnObject;
    }

    public class ReturnData {
       String userEmail;
       String accToken;
       String expireTime;

        public String getUserEmail() {
            return userEmail;
        }

        public void setUserEmail(String userEmail) {
            this.userEmail = userEmail;
        }

        public String getAccToken() {
            return accToken;
        }

        public void setAccToken(String accToken) {
            this.accToken = accToken;
        }

        public String getExpireTime() {
            return expireTime;
        }

        public void setExpireTime(String expireTime) {
            this.expireTime = expireTime;
        }
    }
}
