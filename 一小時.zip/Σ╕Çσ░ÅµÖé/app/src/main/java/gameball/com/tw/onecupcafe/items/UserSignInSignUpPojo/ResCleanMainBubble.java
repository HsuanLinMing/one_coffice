package gameball.com.tw.onecupcafe.items.UserSignInSignUpPojo;

public class ResCleanMainBubble {
    String code;
    String message;
    boolean retnObject;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isRetnObject() {
        return retnObject;
    }

    public void setRetnObject(boolean retnObject) {
        this.retnObject = retnObject;
    }
}
